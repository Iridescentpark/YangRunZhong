#pragma once
// MESSAGE YLCX_RADAR_MESSAGE PACKING

#define MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE 54411


typedef struct __mavlink_ylcx_radar_message_t {
 float distance; /*<  obstacle distance*/
 int8_t index; /*<  which radar*/
 int8_t emergency; /*<  O: safety 1: emergency*/
} mavlink_ylcx_radar_message_t;

#define MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN 6
#define MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN 6
#define MAVLINK_MSG_ID_54411_LEN 6
#define MAVLINK_MSG_ID_54411_MIN_LEN 6

#define MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_CRC 138
#define MAVLINK_MSG_ID_54411_CRC 138



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_RADAR_MESSAGE { \
    54411, \
    "YLCX_RADAR_MESSAGE", \
    3, \
    {  { "index", NULL, MAVLINK_TYPE_INT8_T, 0, 4, offsetof(mavlink_ylcx_radar_message_t, index) }, \
         { "emergency", NULL, MAVLINK_TYPE_INT8_T, 0, 5, offsetof(mavlink_ylcx_radar_message_t, emergency) }, \
         { "distance", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ylcx_radar_message_t, distance) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_RADAR_MESSAGE { \
    "YLCX_RADAR_MESSAGE", \
    3, \
    {  { "index", NULL, MAVLINK_TYPE_INT8_T, 0, 4, offsetof(mavlink_ylcx_radar_message_t, index) }, \
         { "emergency", NULL, MAVLINK_TYPE_INT8_T, 0, 5, offsetof(mavlink_ylcx_radar_message_t, emergency) }, \
         { "distance", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ylcx_radar_message_t, distance) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_radar_message message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param index  which radar
 * @param emergency  O: safety 1: emergency
 * @param distance  obstacle distance
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_radar_message_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int8_t index, int8_t emergency, float distance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN];
    _mav_put_float(buf, 0, distance);
    _mav_put_int8_t(buf, 4, index);
    _mav_put_int8_t(buf, 5, emergency);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN);
#else
    mavlink_ylcx_radar_message_t packet;
    packet.distance = distance;
    packet.index = index;
    packet.emergency = emergency;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_CRC);
}

/**
 * @brief Pack a ylcx_radar_message message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param index  which radar
 * @param emergency  O: safety 1: emergency
 * @param distance  obstacle distance
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_radar_message_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               int8_t index, int8_t emergency, float distance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN];
    _mav_put_float(buf, 0, distance);
    _mav_put_int8_t(buf, 4, index);
    _mav_put_int8_t(buf, 5, emergency);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN);
#else
    mavlink_ylcx_radar_message_t packet;
    packet.distance = distance;
    packet.index = index;
    packet.emergency = emergency;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN);
#endif
}

/**
 * @brief Pack a ylcx_radar_message message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param index  which radar
 * @param emergency  O: safety 1: emergency
 * @param distance  obstacle distance
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_radar_message_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int8_t index,int8_t emergency,float distance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN];
    _mav_put_float(buf, 0, distance);
    _mav_put_int8_t(buf, 4, index);
    _mav_put_int8_t(buf, 5, emergency);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN);
#else
    mavlink_ylcx_radar_message_t packet;
    packet.distance = distance;
    packet.index = index;
    packet.emergency = emergency;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_CRC);
}

/**
 * @brief Encode a ylcx_radar_message struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_radar_message C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_radar_message_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_radar_message_t* ylcx_radar_message)
{
    return mavlink_msg_ylcx_radar_message_pack(system_id, component_id, msg, ylcx_radar_message->index, ylcx_radar_message->emergency, ylcx_radar_message->distance);
}

/**
 * @brief Encode a ylcx_radar_message struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_radar_message C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_radar_message_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_radar_message_t* ylcx_radar_message)
{
    return mavlink_msg_ylcx_radar_message_pack_chan(system_id, component_id, chan, msg, ylcx_radar_message->index, ylcx_radar_message->emergency, ylcx_radar_message->distance);
}

/**
 * @brief Encode a ylcx_radar_message struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_radar_message C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_radar_message_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_radar_message_t* ylcx_radar_message)
{
    return mavlink_msg_ylcx_radar_message_pack_status(system_id, component_id, _status, msg,  ylcx_radar_message->index, ylcx_radar_message->emergency, ylcx_radar_message->distance);
}

/**
 * @brief Send a ylcx_radar_message message
 * @param chan MAVLink channel to send the message
 *
 * @param index  which radar
 * @param emergency  O: safety 1: emergency
 * @param distance  obstacle distance
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_radar_message_send(mavlink_channel_t chan, int8_t index, int8_t emergency, float distance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN];
    _mav_put_float(buf, 0, distance);
    _mav_put_int8_t(buf, 4, index);
    _mav_put_int8_t(buf, 5, emergency);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE, buf, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_CRC);
#else
    mavlink_ylcx_radar_message_t packet;
    packet.distance = distance;
    packet.index = index;
    packet.emergency = emergency;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE, (const char *)&packet, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_CRC);
#endif
}

/**
 * @brief Send a ylcx_radar_message message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_radar_message_send_struct(mavlink_channel_t chan, const mavlink_ylcx_radar_message_t* ylcx_radar_message)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_radar_message_send(chan, ylcx_radar_message->index, ylcx_radar_message->emergency, ylcx_radar_message->distance);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE, (const char *)ylcx_radar_message, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_radar_message_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int8_t index, int8_t emergency, float distance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_float(buf, 0, distance);
    _mav_put_int8_t(buf, 4, index);
    _mav_put_int8_t(buf, 5, emergency);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE, buf, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_CRC);
#else
    mavlink_ylcx_radar_message_t *packet = (mavlink_ylcx_radar_message_t *)msgbuf;
    packet->distance = distance;
    packet->index = index;
    packet->emergency = emergency;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE, (const char *)packet, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_RADAR_MESSAGE UNPACKING


/**
 * @brief Get field index from ylcx_radar_message message
 *
 * @return  which radar
 */
static inline int8_t mavlink_msg_ylcx_radar_message_get_index(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  4);
}

/**
 * @brief Get field emergency from ylcx_radar_message message
 *
 * @return  O: safety 1: emergency
 */
static inline int8_t mavlink_msg_ylcx_radar_message_get_emergency(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  5);
}

/**
 * @brief Get field distance from ylcx_radar_message message
 *
 * @return  obstacle distance
 */
static inline float mavlink_msg_ylcx_radar_message_get_distance(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Decode a ylcx_radar_message message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_radar_message C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_radar_message_decode(const mavlink_message_t* msg, mavlink_ylcx_radar_message_t* ylcx_radar_message)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_radar_message->distance = mavlink_msg_ylcx_radar_message_get_distance(msg);
    ylcx_radar_message->index = mavlink_msg_ylcx_radar_message_get_index(msg);
    ylcx_radar_message->emergency = mavlink_msg_ylcx_radar_message_get_emergency(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN? msg->len : MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN;
        memset(ylcx_radar_message, 0, MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_LEN);
    memcpy(ylcx_radar_message, _MAV_PAYLOAD(msg), len);
#endif
}
