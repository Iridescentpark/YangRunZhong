#pragma once
// MESSAGE YLCX_SPIDER_SET_VEHICLE PACKING

#define MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE 54404


typedef struct __mavlink_ylcx_spider_set_vehicle_t {
 uint8_t headlight; /*<  0 is close, 1 is open*/
 uint8_t beaconlight; /*<  hangbiaodeng 0 is close, 1 is open*/
 uint8_t lowlight; /*<  jinguangdeng 0 is close, 1 is open*/
 uint8_t farlight; /*<  yuanguangdeng 0 is close, 1 is open*/
 uint8_t liferaft; /*<  jiushengfa 0 is close, 1 is open*/
} mavlink_ylcx_spider_set_vehicle_t;

#define MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN 5
#define MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN 5
#define MAVLINK_MSG_ID_54404_LEN 5
#define MAVLINK_MSG_ID_54404_MIN_LEN 5

#define MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_CRC 213
#define MAVLINK_MSG_ID_54404_CRC 213



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_SPIDER_SET_VEHICLE { \
    54404, \
    "YLCX_SPIDER_SET_VEHICLE", \
    5, \
    {  { "headlight", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_ylcx_spider_set_vehicle_t, headlight) }, \
         { "beaconlight", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_ylcx_spider_set_vehicle_t, beaconlight) }, \
         { "lowlight", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_ylcx_spider_set_vehicle_t, lowlight) }, \
         { "farlight", NULL, MAVLINK_TYPE_UINT8_T, 0, 3, offsetof(mavlink_ylcx_spider_set_vehicle_t, farlight) }, \
         { "liferaft", NULL, MAVLINK_TYPE_UINT8_T, 0, 4, offsetof(mavlink_ylcx_spider_set_vehicle_t, liferaft) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_SPIDER_SET_VEHICLE { \
    "YLCX_SPIDER_SET_VEHICLE", \
    5, \
    {  { "headlight", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_ylcx_spider_set_vehicle_t, headlight) }, \
         { "beaconlight", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_ylcx_spider_set_vehicle_t, beaconlight) }, \
         { "lowlight", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_ylcx_spider_set_vehicle_t, lowlight) }, \
         { "farlight", NULL, MAVLINK_TYPE_UINT8_T, 0, 3, offsetof(mavlink_ylcx_spider_set_vehicle_t, farlight) }, \
         { "liferaft", NULL, MAVLINK_TYPE_UINT8_T, 0, 4, offsetof(mavlink_ylcx_spider_set_vehicle_t, liferaft) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_spider_set_vehicle message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param headlight  0 is close, 1 is open
 * @param beaconlight  hangbiaodeng 0 is close, 1 is open
 * @param lowlight  jinguangdeng 0 is close, 1 is open
 * @param farlight  yuanguangdeng 0 is close, 1 is open
 * @param liferaft  jiushengfa 0 is close, 1 is open
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_spider_set_vehicle_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t headlight, uint8_t beaconlight, uint8_t lowlight, uint8_t farlight, uint8_t liferaft)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN];
    _mav_put_uint8_t(buf, 0, headlight);
    _mav_put_uint8_t(buf, 1, beaconlight);
    _mav_put_uint8_t(buf, 2, lowlight);
    _mav_put_uint8_t(buf, 3, farlight);
    _mav_put_uint8_t(buf, 4, liferaft);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN);
#else
    mavlink_ylcx_spider_set_vehicle_t packet;
    packet.headlight = headlight;
    packet.beaconlight = beaconlight;
    packet.lowlight = lowlight;
    packet.farlight = farlight;
    packet.liferaft = liferaft;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_CRC);
}

/**
 * @brief Pack a ylcx_spider_set_vehicle message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param headlight  0 is close, 1 is open
 * @param beaconlight  hangbiaodeng 0 is close, 1 is open
 * @param lowlight  jinguangdeng 0 is close, 1 is open
 * @param farlight  yuanguangdeng 0 is close, 1 is open
 * @param liferaft  jiushengfa 0 is close, 1 is open
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_spider_set_vehicle_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t headlight, uint8_t beaconlight, uint8_t lowlight, uint8_t farlight, uint8_t liferaft)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN];
    _mav_put_uint8_t(buf, 0, headlight);
    _mav_put_uint8_t(buf, 1, beaconlight);
    _mav_put_uint8_t(buf, 2, lowlight);
    _mav_put_uint8_t(buf, 3, farlight);
    _mav_put_uint8_t(buf, 4, liferaft);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN);
#else
    mavlink_ylcx_spider_set_vehicle_t packet;
    packet.headlight = headlight;
    packet.beaconlight = beaconlight;
    packet.lowlight = lowlight;
    packet.farlight = farlight;
    packet.liferaft = liferaft;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN);
#endif
}

/**
 * @brief Pack a ylcx_spider_set_vehicle message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param headlight  0 is close, 1 is open
 * @param beaconlight  hangbiaodeng 0 is close, 1 is open
 * @param lowlight  jinguangdeng 0 is close, 1 is open
 * @param farlight  yuanguangdeng 0 is close, 1 is open
 * @param liferaft  jiushengfa 0 is close, 1 is open
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_spider_set_vehicle_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t headlight,uint8_t beaconlight,uint8_t lowlight,uint8_t farlight,uint8_t liferaft)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN];
    _mav_put_uint8_t(buf, 0, headlight);
    _mav_put_uint8_t(buf, 1, beaconlight);
    _mav_put_uint8_t(buf, 2, lowlight);
    _mav_put_uint8_t(buf, 3, farlight);
    _mav_put_uint8_t(buf, 4, liferaft);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN);
#else
    mavlink_ylcx_spider_set_vehicle_t packet;
    packet.headlight = headlight;
    packet.beaconlight = beaconlight;
    packet.lowlight = lowlight;
    packet.farlight = farlight;
    packet.liferaft = liferaft;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_CRC);
}

/**
 * @brief Encode a ylcx_spider_set_vehicle struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_spider_set_vehicle C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_spider_set_vehicle_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_spider_set_vehicle_t* ylcx_spider_set_vehicle)
{
    return mavlink_msg_ylcx_spider_set_vehicle_pack(system_id, component_id, msg, ylcx_spider_set_vehicle->headlight, ylcx_spider_set_vehicle->beaconlight, ylcx_spider_set_vehicle->lowlight, ylcx_spider_set_vehicle->farlight, ylcx_spider_set_vehicle->liferaft);
}

/**
 * @brief Encode a ylcx_spider_set_vehicle struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_spider_set_vehicle C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_spider_set_vehicle_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_spider_set_vehicle_t* ylcx_spider_set_vehicle)
{
    return mavlink_msg_ylcx_spider_set_vehicle_pack_chan(system_id, component_id, chan, msg, ylcx_spider_set_vehicle->headlight, ylcx_spider_set_vehicle->beaconlight, ylcx_spider_set_vehicle->lowlight, ylcx_spider_set_vehicle->farlight, ylcx_spider_set_vehicle->liferaft);
}

/**
 * @brief Encode a ylcx_spider_set_vehicle struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_spider_set_vehicle C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_spider_set_vehicle_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_spider_set_vehicle_t* ylcx_spider_set_vehicle)
{
    return mavlink_msg_ylcx_spider_set_vehicle_pack_status(system_id, component_id, _status, msg,  ylcx_spider_set_vehicle->headlight, ylcx_spider_set_vehicle->beaconlight, ylcx_spider_set_vehicle->lowlight, ylcx_spider_set_vehicle->farlight, ylcx_spider_set_vehicle->liferaft);
}

/**
 * @brief Send a ylcx_spider_set_vehicle message
 * @param chan MAVLink channel to send the message
 *
 * @param headlight  0 is close, 1 is open
 * @param beaconlight  hangbiaodeng 0 is close, 1 is open
 * @param lowlight  jinguangdeng 0 is close, 1 is open
 * @param farlight  yuanguangdeng 0 is close, 1 is open
 * @param liferaft  jiushengfa 0 is close, 1 is open
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_spider_set_vehicle_send(mavlink_channel_t chan, uint8_t headlight, uint8_t beaconlight, uint8_t lowlight, uint8_t farlight, uint8_t liferaft)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN];
    _mav_put_uint8_t(buf, 0, headlight);
    _mav_put_uint8_t(buf, 1, beaconlight);
    _mav_put_uint8_t(buf, 2, lowlight);
    _mav_put_uint8_t(buf, 3, farlight);
    _mav_put_uint8_t(buf, 4, liferaft);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE, buf, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_CRC);
#else
    mavlink_ylcx_spider_set_vehicle_t packet;
    packet.headlight = headlight;
    packet.beaconlight = beaconlight;
    packet.lowlight = lowlight;
    packet.farlight = farlight;
    packet.liferaft = liferaft;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE, (const char *)&packet, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_CRC);
#endif
}

/**
 * @brief Send a ylcx_spider_set_vehicle message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_spider_set_vehicle_send_struct(mavlink_channel_t chan, const mavlink_ylcx_spider_set_vehicle_t* ylcx_spider_set_vehicle)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_spider_set_vehicle_send(chan, ylcx_spider_set_vehicle->headlight, ylcx_spider_set_vehicle->beaconlight, ylcx_spider_set_vehicle->lowlight, ylcx_spider_set_vehicle->farlight, ylcx_spider_set_vehicle->liferaft);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE, (const char *)ylcx_spider_set_vehicle, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_spider_set_vehicle_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t headlight, uint8_t beaconlight, uint8_t lowlight, uint8_t farlight, uint8_t liferaft)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, headlight);
    _mav_put_uint8_t(buf, 1, beaconlight);
    _mav_put_uint8_t(buf, 2, lowlight);
    _mav_put_uint8_t(buf, 3, farlight);
    _mav_put_uint8_t(buf, 4, liferaft);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE, buf, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_CRC);
#else
    mavlink_ylcx_spider_set_vehicle_t *packet = (mavlink_ylcx_spider_set_vehicle_t *)msgbuf;
    packet->headlight = headlight;
    packet->beaconlight = beaconlight;
    packet->lowlight = lowlight;
    packet->farlight = farlight;
    packet->liferaft = liferaft;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE, (const char *)packet, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_SPIDER_SET_VEHICLE UNPACKING


/**
 * @brief Get field headlight from ylcx_spider_set_vehicle message
 *
 * @return  0 is close, 1 is open
 */
static inline uint8_t mavlink_msg_ylcx_spider_set_vehicle_get_headlight(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field beaconlight from ylcx_spider_set_vehicle message
 *
 * @return  hangbiaodeng 0 is close, 1 is open
 */
static inline uint8_t mavlink_msg_ylcx_spider_set_vehicle_get_beaconlight(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  1);
}

/**
 * @brief Get field lowlight from ylcx_spider_set_vehicle message
 *
 * @return  jinguangdeng 0 is close, 1 is open
 */
static inline uint8_t mavlink_msg_ylcx_spider_set_vehicle_get_lowlight(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  2);
}

/**
 * @brief Get field farlight from ylcx_spider_set_vehicle message
 *
 * @return  yuanguangdeng 0 is close, 1 is open
 */
static inline uint8_t mavlink_msg_ylcx_spider_set_vehicle_get_farlight(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  3);
}

/**
 * @brief Get field liferaft from ylcx_spider_set_vehicle message
 *
 * @return  jiushengfa 0 is close, 1 is open
 */
static inline uint8_t mavlink_msg_ylcx_spider_set_vehicle_get_liferaft(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  4);
}

/**
 * @brief Decode a ylcx_spider_set_vehicle message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_spider_set_vehicle C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_spider_set_vehicle_decode(const mavlink_message_t* msg, mavlink_ylcx_spider_set_vehicle_t* ylcx_spider_set_vehicle)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_spider_set_vehicle->headlight = mavlink_msg_ylcx_spider_set_vehicle_get_headlight(msg);
    ylcx_spider_set_vehicle->beaconlight = mavlink_msg_ylcx_spider_set_vehicle_get_beaconlight(msg);
    ylcx_spider_set_vehicle->lowlight = mavlink_msg_ylcx_spider_set_vehicle_get_lowlight(msg);
    ylcx_spider_set_vehicle->farlight = mavlink_msg_ylcx_spider_set_vehicle_get_farlight(msg);
    ylcx_spider_set_vehicle->liferaft = mavlink_msg_ylcx_spider_set_vehicle_get_liferaft(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN? msg->len : MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN;
        memset(ylcx_spider_set_vehicle, 0, MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_LEN);
    memcpy(ylcx_spider_set_vehicle, _MAV_PAYLOAD(msg), len);
#endif
}
