#pragma once
// MESSAGE YLCX_GUOKEDA_INFO PACKING

#define MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO 54408


typedef struct __mavlink_ylcx_guokeda_info_t {
 int16_t airPressure; /*< [pa]  / 1e2 */
 int16_t temperature; /*< [cdegC]  / 1e1 */
 int16_t humidity; /*< [%]  / 1e1 */
 int16_t windDirectionR; /*< [cdegC]  / 1e1 */
 int16_t windDirectionG; /*< [cdegC]  / 1e1 */
 int16_t windSpeedN; /*< [knot]  / 1e1 */
 int16_t windSpeedM; /*< [m/s]  / 1e1 */
 int16_t waterDeep; /*< [m]  / 1e2 */
} mavlink_ylcx_guokeda_info_t;

#define MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN 16
#define MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN 16
#define MAVLINK_MSG_ID_54408_LEN 16
#define MAVLINK_MSG_ID_54408_MIN_LEN 16

#define MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_CRC 199
#define MAVLINK_MSG_ID_54408_CRC 199



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_GUOKEDA_INFO { \
    54408, \
    "YLCX_GUOKEDA_INFO", \
    8, \
    {  { "airPressure", NULL, MAVLINK_TYPE_INT16_T, 0, 0, offsetof(mavlink_ylcx_guokeda_info_t, airPressure) }, \
         { "temperature", NULL, MAVLINK_TYPE_INT16_T, 0, 2, offsetof(mavlink_ylcx_guokeda_info_t, temperature) }, \
         { "humidity", NULL, MAVLINK_TYPE_INT16_T, 0, 4, offsetof(mavlink_ylcx_guokeda_info_t, humidity) }, \
         { "windDirectionR", NULL, MAVLINK_TYPE_INT16_T, 0, 6, offsetof(mavlink_ylcx_guokeda_info_t, windDirectionR) }, \
         { "windDirectionG", NULL, MAVLINK_TYPE_INT16_T, 0, 8, offsetof(mavlink_ylcx_guokeda_info_t, windDirectionG) }, \
         { "windSpeedN", NULL, MAVLINK_TYPE_INT16_T, 0, 10, offsetof(mavlink_ylcx_guokeda_info_t, windSpeedN) }, \
         { "windSpeedM", NULL, MAVLINK_TYPE_INT16_T, 0, 12, offsetof(mavlink_ylcx_guokeda_info_t, windSpeedM) }, \
         { "waterDeep", NULL, MAVLINK_TYPE_INT16_T, 0, 14, offsetof(mavlink_ylcx_guokeda_info_t, waterDeep) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_GUOKEDA_INFO { \
    "YLCX_GUOKEDA_INFO", \
    8, \
    {  { "airPressure", NULL, MAVLINK_TYPE_INT16_T, 0, 0, offsetof(mavlink_ylcx_guokeda_info_t, airPressure) }, \
         { "temperature", NULL, MAVLINK_TYPE_INT16_T, 0, 2, offsetof(mavlink_ylcx_guokeda_info_t, temperature) }, \
         { "humidity", NULL, MAVLINK_TYPE_INT16_T, 0, 4, offsetof(mavlink_ylcx_guokeda_info_t, humidity) }, \
         { "windDirectionR", NULL, MAVLINK_TYPE_INT16_T, 0, 6, offsetof(mavlink_ylcx_guokeda_info_t, windDirectionR) }, \
         { "windDirectionG", NULL, MAVLINK_TYPE_INT16_T, 0, 8, offsetof(mavlink_ylcx_guokeda_info_t, windDirectionG) }, \
         { "windSpeedN", NULL, MAVLINK_TYPE_INT16_T, 0, 10, offsetof(mavlink_ylcx_guokeda_info_t, windSpeedN) }, \
         { "windSpeedM", NULL, MAVLINK_TYPE_INT16_T, 0, 12, offsetof(mavlink_ylcx_guokeda_info_t, windSpeedM) }, \
         { "waterDeep", NULL, MAVLINK_TYPE_INT16_T, 0, 14, offsetof(mavlink_ylcx_guokeda_info_t, waterDeep) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_guokeda_info message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param airPressure [pa]  / 1e2 
 * @param temperature [cdegC]  / 1e1 
 * @param humidity [%]  / 1e1 
 * @param windDirectionR [cdegC]  / 1e1 
 * @param windDirectionG [cdegC]  / 1e1 
 * @param windSpeedN [knot]  / 1e1 
 * @param windSpeedM [m/s]  / 1e1 
 * @param waterDeep [m]  / 1e2 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_guokeda_info_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int16_t airPressure, int16_t temperature, int16_t humidity, int16_t windDirectionR, int16_t windDirectionG, int16_t windSpeedN, int16_t windSpeedM, int16_t waterDeep)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN];
    _mav_put_int16_t(buf, 0, airPressure);
    _mav_put_int16_t(buf, 2, temperature);
    _mav_put_int16_t(buf, 4, humidity);
    _mav_put_int16_t(buf, 6, windDirectionR);
    _mav_put_int16_t(buf, 8, windDirectionG);
    _mav_put_int16_t(buf, 10, windSpeedN);
    _mav_put_int16_t(buf, 12, windSpeedM);
    _mav_put_int16_t(buf, 14, waterDeep);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN);
#else
    mavlink_ylcx_guokeda_info_t packet;
    packet.airPressure = airPressure;
    packet.temperature = temperature;
    packet.humidity = humidity;
    packet.windDirectionR = windDirectionR;
    packet.windDirectionG = windDirectionG;
    packet.windSpeedN = windSpeedN;
    packet.windSpeedM = windSpeedM;
    packet.waterDeep = waterDeep;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_CRC);
}

/**
 * @brief Pack a ylcx_guokeda_info message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param airPressure [pa]  / 1e2 
 * @param temperature [cdegC]  / 1e1 
 * @param humidity [%]  / 1e1 
 * @param windDirectionR [cdegC]  / 1e1 
 * @param windDirectionG [cdegC]  / 1e1 
 * @param windSpeedN [knot]  / 1e1 
 * @param windSpeedM [m/s]  / 1e1 
 * @param waterDeep [m]  / 1e2 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_guokeda_info_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               int16_t airPressure, int16_t temperature, int16_t humidity, int16_t windDirectionR, int16_t windDirectionG, int16_t windSpeedN, int16_t windSpeedM, int16_t waterDeep)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN];
    _mav_put_int16_t(buf, 0, airPressure);
    _mav_put_int16_t(buf, 2, temperature);
    _mav_put_int16_t(buf, 4, humidity);
    _mav_put_int16_t(buf, 6, windDirectionR);
    _mav_put_int16_t(buf, 8, windDirectionG);
    _mav_put_int16_t(buf, 10, windSpeedN);
    _mav_put_int16_t(buf, 12, windSpeedM);
    _mav_put_int16_t(buf, 14, waterDeep);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN);
#else
    mavlink_ylcx_guokeda_info_t packet;
    packet.airPressure = airPressure;
    packet.temperature = temperature;
    packet.humidity = humidity;
    packet.windDirectionR = windDirectionR;
    packet.windDirectionG = windDirectionG;
    packet.windSpeedN = windSpeedN;
    packet.windSpeedM = windSpeedM;
    packet.waterDeep = waterDeep;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN);
#endif
}

/**
 * @brief Pack a ylcx_guokeda_info message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param airPressure [pa]  / 1e2 
 * @param temperature [cdegC]  / 1e1 
 * @param humidity [%]  / 1e1 
 * @param windDirectionR [cdegC]  / 1e1 
 * @param windDirectionG [cdegC]  / 1e1 
 * @param windSpeedN [knot]  / 1e1 
 * @param windSpeedM [m/s]  / 1e1 
 * @param waterDeep [m]  / 1e2 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_guokeda_info_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int16_t airPressure,int16_t temperature,int16_t humidity,int16_t windDirectionR,int16_t windDirectionG,int16_t windSpeedN,int16_t windSpeedM,int16_t waterDeep)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN];
    _mav_put_int16_t(buf, 0, airPressure);
    _mav_put_int16_t(buf, 2, temperature);
    _mav_put_int16_t(buf, 4, humidity);
    _mav_put_int16_t(buf, 6, windDirectionR);
    _mav_put_int16_t(buf, 8, windDirectionG);
    _mav_put_int16_t(buf, 10, windSpeedN);
    _mav_put_int16_t(buf, 12, windSpeedM);
    _mav_put_int16_t(buf, 14, waterDeep);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN);
#else
    mavlink_ylcx_guokeda_info_t packet;
    packet.airPressure = airPressure;
    packet.temperature = temperature;
    packet.humidity = humidity;
    packet.windDirectionR = windDirectionR;
    packet.windDirectionG = windDirectionG;
    packet.windSpeedN = windSpeedN;
    packet.windSpeedM = windSpeedM;
    packet.waterDeep = waterDeep;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_CRC);
}

/**
 * @brief Encode a ylcx_guokeda_info struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_guokeda_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_guokeda_info_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_guokeda_info_t* ylcx_guokeda_info)
{
    return mavlink_msg_ylcx_guokeda_info_pack(system_id, component_id, msg, ylcx_guokeda_info->airPressure, ylcx_guokeda_info->temperature, ylcx_guokeda_info->humidity, ylcx_guokeda_info->windDirectionR, ylcx_guokeda_info->windDirectionG, ylcx_guokeda_info->windSpeedN, ylcx_guokeda_info->windSpeedM, ylcx_guokeda_info->waterDeep);
}

/**
 * @brief Encode a ylcx_guokeda_info struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_guokeda_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_guokeda_info_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_guokeda_info_t* ylcx_guokeda_info)
{
    return mavlink_msg_ylcx_guokeda_info_pack_chan(system_id, component_id, chan, msg, ylcx_guokeda_info->airPressure, ylcx_guokeda_info->temperature, ylcx_guokeda_info->humidity, ylcx_guokeda_info->windDirectionR, ylcx_guokeda_info->windDirectionG, ylcx_guokeda_info->windSpeedN, ylcx_guokeda_info->windSpeedM, ylcx_guokeda_info->waterDeep);
}

/**
 * @brief Encode a ylcx_guokeda_info struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_guokeda_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_guokeda_info_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_guokeda_info_t* ylcx_guokeda_info)
{
    return mavlink_msg_ylcx_guokeda_info_pack_status(system_id, component_id, _status, msg,  ylcx_guokeda_info->airPressure, ylcx_guokeda_info->temperature, ylcx_guokeda_info->humidity, ylcx_guokeda_info->windDirectionR, ylcx_guokeda_info->windDirectionG, ylcx_guokeda_info->windSpeedN, ylcx_guokeda_info->windSpeedM, ylcx_guokeda_info->waterDeep);
}

/**
 * @brief Send a ylcx_guokeda_info message
 * @param chan MAVLink channel to send the message
 *
 * @param airPressure [pa]  / 1e2 
 * @param temperature [cdegC]  / 1e1 
 * @param humidity [%]  / 1e1 
 * @param windDirectionR [cdegC]  / 1e1 
 * @param windDirectionG [cdegC]  / 1e1 
 * @param windSpeedN [knot]  / 1e1 
 * @param windSpeedM [m/s]  / 1e1 
 * @param waterDeep [m]  / 1e2 
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_guokeda_info_send(mavlink_channel_t chan, int16_t airPressure, int16_t temperature, int16_t humidity, int16_t windDirectionR, int16_t windDirectionG, int16_t windSpeedN, int16_t windSpeedM, int16_t waterDeep)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN];
    _mav_put_int16_t(buf, 0, airPressure);
    _mav_put_int16_t(buf, 2, temperature);
    _mav_put_int16_t(buf, 4, humidity);
    _mav_put_int16_t(buf, 6, windDirectionR);
    _mav_put_int16_t(buf, 8, windDirectionG);
    _mav_put_int16_t(buf, 10, windSpeedN);
    _mav_put_int16_t(buf, 12, windSpeedM);
    _mav_put_int16_t(buf, 14, waterDeep);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO, buf, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_CRC);
#else
    mavlink_ylcx_guokeda_info_t packet;
    packet.airPressure = airPressure;
    packet.temperature = temperature;
    packet.humidity = humidity;
    packet.windDirectionR = windDirectionR;
    packet.windDirectionG = windDirectionG;
    packet.windSpeedN = windSpeedN;
    packet.windSpeedM = windSpeedM;
    packet.waterDeep = waterDeep;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO, (const char *)&packet, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_CRC);
#endif
}

/**
 * @brief Send a ylcx_guokeda_info message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_guokeda_info_send_struct(mavlink_channel_t chan, const mavlink_ylcx_guokeda_info_t* ylcx_guokeda_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_guokeda_info_send(chan, ylcx_guokeda_info->airPressure, ylcx_guokeda_info->temperature, ylcx_guokeda_info->humidity, ylcx_guokeda_info->windDirectionR, ylcx_guokeda_info->windDirectionG, ylcx_guokeda_info->windSpeedN, ylcx_guokeda_info->windSpeedM, ylcx_guokeda_info->waterDeep);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO, (const char *)ylcx_guokeda_info, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_guokeda_info_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int16_t airPressure, int16_t temperature, int16_t humidity, int16_t windDirectionR, int16_t windDirectionG, int16_t windSpeedN, int16_t windSpeedM, int16_t waterDeep)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int16_t(buf, 0, airPressure);
    _mav_put_int16_t(buf, 2, temperature);
    _mav_put_int16_t(buf, 4, humidity);
    _mav_put_int16_t(buf, 6, windDirectionR);
    _mav_put_int16_t(buf, 8, windDirectionG);
    _mav_put_int16_t(buf, 10, windSpeedN);
    _mav_put_int16_t(buf, 12, windSpeedM);
    _mav_put_int16_t(buf, 14, waterDeep);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO, buf, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_CRC);
#else
    mavlink_ylcx_guokeda_info_t *packet = (mavlink_ylcx_guokeda_info_t *)msgbuf;
    packet->airPressure = airPressure;
    packet->temperature = temperature;
    packet->humidity = humidity;
    packet->windDirectionR = windDirectionR;
    packet->windDirectionG = windDirectionG;
    packet->windSpeedN = windSpeedN;
    packet->windSpeedM = windSpeedM;
    packet->waterDeep = waterDeep;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO, (const char *)packet, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_GUOKEDA_INFO UNPACKING


/**
 * @brief Get field airPressure from ylcx_guokeda_info message
 *
 * @return [pa]  / 1e2 
 */
static inline int16_t mavlink_msg_ylcx_guokeda_info_get_airPressure(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  0);
}

/**
 * @brief Get field temperature from ylcx_guokeda_info message
 *
 * @return [cdegC]  / 1e1 
 */
static inline int16_t mavlink_msg_ylcx_guokeda_info_get_temperature(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  2);
}

/**
 * @brief Get field humidity from ylcx_guokeda_info message
 *
 * @return [%]  / 1e1 
 */
static inline int16_t mavlink_msg_ylcx_guokeda_info_get_humidity(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  4);
}

/**
 * @brief Get field windDirectionR from ylcx_guokeda_info message
 *
 * @return [cdegC]  / 1e1 
 */
static inline int16_t mavlink_msg_ylcx_guokeda_info_get_windDirectionR(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  6);
}

/**
 * @brief Get field windDirectionG from ylcx_guokeda_info message
 *
 * @return [cdegC]  / 1e1 
 */
static inline int16_t mavlink_msg_ylcx_guokeda_info_get_windDirectionG(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  8);
}

/**
 * @brief Get field windSpeedN from ylcx_guokeda_info message
 *
 * @return [knot]  / 1e1 
 */
static inline int16_t mavlink_msg_ylcx_guokeda_info_get_windSpeedN(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  10);
}

/**
 * @brief Get field windSpeedM from ylcx_guokeda_info message
 *
 * @return [m/s]  / 1e1 
 */
static inline int16_t mavlink_msg_ylcx_guokeda_info_get_windSpeedM(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  12);
}

/**
 * @brief Get field waterDeep from ylcx_guokeda_info message
 *
 * @return [m]  / 1e2 
 */
static inline int16_t mavlink_msg_ylcx_guokeda_info_get_waterDeep(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  14);
}

/**
 * @brief Decode a ylcx_guokeda_info message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_guokeda_info C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_guokeda_info_decode(const mavlink_message_t* msg, mavlink_ylcx_guokeda_info_t* ylcx_guokeda_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_guokeda_info->airPressure = mavlink_msg_ylcx_guokeda_info_get_airPressure(msg);
    ylcx_guokeda_info->temperature = mavlink_msg_ylcx_guokeda_info_get_temperature(msg);
    ylcx_guokeda_info->humidity = mavlink_msg_ylcx_guokeda_info_get_humidity(msg);
    ylcx_guokeda_info->windDirectionR = mavlink_msg_ylcx_guokeda_info_get_windDirectionR(msg);
    ylcx_guokeda_info->windDirectionG = mavlink_msg_ylcx_guokeda_info_get_windDirectionG(msg);
    ylcx_guokeda_info->windSpeedN = mavlink_msg_ylcx_guokeda_info_get_windSpeedN(msg);
    ylcx_guokeda_info->windSpeedM = mavlink_msg_ylcx_guokeda_info_get_windSpeedM(msg);
    ylcx_guokeda_info->waterDeep = mavlink_msg_ylcx_guokeda_info_get_waterDeep(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN? msg->len : MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN;
        memset(ylcx_guokeda_info, 0, MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_LEN);
    memcpy(ylcx_guokeda_info, _MAV_PAYLOAD(msg), len);
#endif
}
