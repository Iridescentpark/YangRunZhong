#pragma once
// MESSAGE YLCX_RC_CHANNELS_RAW PACKING

#define MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW 54307


typedef struct __mavlink_ylcx_rc_channels_raw_t {
 int16_t chan1_raw; /*<  RC channel 1 value. Usually used to control the host or left dirver*/
 int16_t chan2_raw; /*<  RC channel 2 value. Usually used to control the ruuder or right dirver*/
 int16_t chan3_raw; /*<  RC channel 3 value.*/
 int16_t chan4_raw; /*<  RC channel 4 value.*/
 int16_t chan5_raw; /*<  RC channel 5 value.*/
 int16_t chan6_raw; /*<  RC channel 6 value.*/
 int16_t chan7_raw; /*<  RC channel 7 value.*/
 int16_t chan8_raw; /*<  RC channel 8 value.*/
} mavlink_ylcx_rc_channels_raw_t;

#define MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN 16
#define MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN 16
#define MAVLINK_MSG_ID_54307_LEN 16
#define MAVLINK_MSG_ID_54307_MIN_LEN 16

#define MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_CRC 130
#define MAVLINK_MSG_ID_54307_CRC 130



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_RC_CHANNELS_RAW { \
    54307, \
    "YLCX_RC_CHANNELS_RAW", \
    8, \
    {  { "chan1_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 0, offsetof(mavlink_ylcx_rc_channels_raw_t, chan1_raw) }, \
         { "chan2_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 2, offsetof(mavlink_ylcx_rc_channels_raw_t, chan2_raw) }, \
         { "chan3_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 4, offsetof(mavlink_ylcx_rc_channels_raw_t, chan3_raw) }, \
         { "chan4_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 6, offsetof(mavlink_ylcx_rc_channels_raw_t, chan4_raw) }, \
         { "chan5_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 8, offsetof(mavlink_ylcx_rc_channels_raw_t, chan5_raw) }, \
         { "chan6_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 10, offsetof(mavlink_ylcx_rc_channels_raw_t, chan6_raw) }, \
         { "chan7_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 12, offsetof(mavlink_ylcx_rc_channels_raw_t, chan7_raw) }, \
         { "chan8_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 14, offsetof(mavlink_ylcx_rc_channels_raw_t, chan8_raw) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_RC_CHANNELS_RAW { \
    "YLCX_RC_CHANNELS_RAW", \
    8, \
    {  { "chan1_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 0, offsetof(mavlink_ylcx_rc_channels_raw_t, chan1_raw) }, \
         { "chan2_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 2, offsetof(mavlink_ylcx_rc_channels_raw_t, chan2_raw) }, \
         { "chan3_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 4, offsetof(mavlink_ylcx_rc_channels_raw_t, chan3_raw) }, \
         { "chan4_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 6, offsetof(mavlink_ylcx_rc_channels_raw_t, chan4_raw) }, \
         { "chan5_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 8, offsetof(mavlink_ylcx_rc_channels_raw_t, chan5_raw) }, \
         { "chan6_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 10, offsetof(mavlink_ylcx_rc_channels_raw_t, chan6_raw) }, \
         { "chan7_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 12, offsetof(mavlink_ylcx_rc_channels_raw_t, chan7_raw) }, \
         { "chan8_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 14, offsetof(mavlink_ylcx_rc_channels_raw_t, chan8_raw) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_rc_channels_raw message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param chan1_raw  RC channel 1 value. Usually used to control the host or left dirver
 * @param chan2_raw  RC channel 2 value. Usually used to control the ruuder or right dirver
 * @param chan3_raw  RC channel 3 value.
 * @param chan4_raw  RC channel 4 value.
 * @param chan5_raw  RC channel 5 value.
 * @param chan6_raw  RC channel 6 value.
 * @param chan7_raw  RC channel 7 value.
 * @param chan8_raw  RC channel 8 value.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_rc_channels_raw_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int16_t chan1_raw, int16_t chan2_raw, int16_t chan3_raw, int16_t chan4_raw, int16_t chan5_raw, int16_t chan6_raw, int16_t chan7_raw, int16_t chan8_raw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN];
    _mav_put_int16_t(buf, 0, chan1_raw);
    _mav_put_int16_t(buf, 2, chan2_raw);
    _mav_put_int16_t(buf, 4, chan3_raw);
    _mav_put_int16_t(buf, 6, chan4_raw);
    _mav_put_int16_t(buf, 8, chan5_raw);
    _mav_put_int16_t(buf, 10, chan6_raw);
    _mav_put_int16_t(buf, 12, chan7_raw);
    _mav_put_int16_t(buf, 14, chan8_raw);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN);
#else
    mavlink_ylcx_rc_channels_raw_t packet;
    packet.chan1_raw = chan1_raw;
    packet.chan2_raw = chan2_raw;
    packet.chan3_raw = chan3_raw;
    packet.chan4_raw = chan4_raw;
    packet.chan5_raw = chan5_raw;
    packet.chan6_raw = chan6_raw;
    packet.chan7_raw = chan7_raw;
    packet.chan8_raw = chan8_raw;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_CRC);
}

/**
 * @brief Pack a ylcx_rc_channels_raw message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param chan1_raw  RC channel 1 value. Usually used to control the host or left dirver
 * @param chan2_raw  RC channel 2 value. Usually used to control the ruuder or right dirver
 * @param chan3_raw  RC channel 3 value.
 * @param chan4_raw  RC channel 4 value.
 * @param chan5_raw  RC channel 5 value.
 * @param chan6_raw  RC channel 6 value.
 * @param chan7_raw  RC channel 7 value.
 * @param chan8_raw  RC channel 8 value.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_rc_channels_raw_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               int16_t chan1_raw, int16_t chan2_raw, int16_t chan3_raw, int16_t chan4_raw, int16_t chan5_raw, int16_t chan6_raw, int16_t chan7_raw, int16_t chan8_raw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN];
    _mav_put_int16_t(buf, 0, chan1_raw);
    _mav_put_int16_t(buf, 2, chan2_raw);
    _mav_put_int16_t(buf, 4, chan3_raw);
    _mav_put_int16_t(buf, 6, chan4_raw);
    _mav_put_int16_t(buf, 8, chan5_raw);
    _mav_put_int16_t(buf, 10, chan6_raw);
    _mav_put_int16_t(buf, 12, chan7_raw);
    _mav_put_int16_t(buf, 14, chan8_raw);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN);
#else
    mavlink_ylcx_rc_channels_raw_t packet;
    packet.chan1_raw = chan1_raw;
    packet.chan2_raw = chan2_raw;
    packet.chan3_raw = chan3_raw;
    packet.chan4_raw = chan4_raw;
    packet.chan5_raw = chan5_raw;
    packet.chan6_raw = chan6_raw;
    packet.chan7_raw = chan7_raw;
    packet.chan8_raw = chan8_raw;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN);
#endif
}

/**
 * @brief Pack a ylcx_rc_channels_raw message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param chan1_raw  RC channel 1 value. Usually used to control the host or left dirver
 * @param chan2_raw  RC channel 2 value. Usually used to control the ruuder or right dirver
 * @param chan3_raw  RC channel 3 value.
 * @param chan4_raw  RC channel 4 value.
 * @param chan5_raw  RC channel 5 value.
 * @param chan6_raw  RC channel 6 value.
 * @param chan7_raw  RC channel 7 value.
 * @param chan8_raw  RC channel 8 value.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_rc_channels_raw_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int16_t chan1_raw,int16_t chan2_raw,int16_t chan3_raw,int16_t chan4_raw,int16_t chan5_raw,int16_t chan6_raw,int16_t chan7_raw,int16_t chan8_raw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN];
    _mav_put_int16_t(buf, 0, chan1_raw);
    _mav_put_int16_t(buf, 2, chan2_raw);
    _mav_put_int16_t(buf, 4, chan3_raw);
    _mav_put_int16_t(buf, 6, chan4_raw);
    _mav_put_int16_t(buf, 8, chan5_raw);
    _mav_put_int16_t(buf, 10, chan6_raw);
    _mav_put_int16_t(buf, 12, chan7_raw);
    _mav_put_int16_t(buf, 14, chan8_raw);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN);
#else
    mavlink_ylcx_rc_channels_raw_t packet;
    packet.chan1_raw = chan1_raw;
    packet.chan2_raw = chan2_raw;
    packet.chan3_raw = chan3_raw;
    packet.chan4_raw = chan4_raw;
    packet.chan5_raw = chan5_raw;
    packet.chan6_raw = chan6_raw;
    packet.chan7_raw = chan7_raw;
    packet.chan8_raw = chan8_raw;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_CRC);
}

/**
 * @brief Encode a ylcx_rc_channels_raw struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_rc_channels_raw C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_rc_channels_raw_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_rc_channels_raw_t* ylcx_rc_channels_raw)
{
    return mavlink_msg_ylcx_rc_channels_raw_pack(system_id, component_id, msg, ylcx_rc_channels_raw->chan1_raw, ylcx_rc_channels_raw->chan2_raw, ylcx_rc_channels_raw->chan3_raw, ylcx_rc_channels_raw->chan4_raw, ylcx_rc_channels_raw->chan5_raw, ylcx_rc_channels_raw->chan6_raw, ylcx_rc_channels_raw->chan7_raw, ylcx_rc_channels_raw->chan8_raw);
}

/**
 * @brief Encode a ylcx_rc_channels_raw struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_rc_channels_raw C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_rc_channels_raw_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_rc_channels_raw_t* ylcx_rc_channels_raw)
{
    return mavlink_msg_ylcx_rc_channels_raw_pack_chan(system_id, component_id, chan, msg, ylcx_rc_channels_raw->chan1_raw, ylcx_rc_channels_raw->chan2_raw, ylcx_rc_channels_raw->chan3_raw, ylcx_rc_channels_raw->chan4_raw, ylcx_rc_channels_raw->chan5_raw, ylcx_rc_channels_raw->chan6_raw, ylcx_rc_channels_raw->chan7_raw, ylcx_rc_channels_raw->chan8_raw);
}

/**
 * @brief Encode a ylcx_rc_channels_raw struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_rc_channels_raw C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_rc_channels_raw_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_rc_channels_raw_t* ylcx_rc_channels_raw)
{
    return mavlink_msg_ylcx_rc_channels_raw_pack_status(system_id, component_id, _status, msg,  ylcx_rc_channels_raw->chan1_raw, ylcx_rc_channels_raw->chan2_raw, ylcx_rc_channels_raw->chan3_raw, ylcx_rc_channels_raw->chan4_raw, ylcx_rc_channels_raw->chan5_raw, ylcx_rc_channels_raw->chan6_raw, ylcx_rc_channels_raw->chan7_raw, ylcx_rc_channels_raw->chan8_raw);
}

/**
 * @brief Send a ylcx_rc_channels_raw message
 * @param chan MAVLink channel to send the message
 *
 * @param chan1_raw  RC channel 1 value. Usually used to control the host or left dirver
 * @param chan2_raw  RC channel 2 value. Usually used to control the ruuder or right dirver
 * @param chan3_raw  RC channel 3 value.
 * @param chan4_raw  RC channel 4 value.
 * @param chan5_raw  RC channel 5 value.
 * @param chan6_raw  RC channel 6 value.
 * @param chan7_raw  RC channel 7 value.
 * @param chan8_raw  RC channel 8 value.
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_rc_channels_raw_send(mavlink_channel_t chan, int16_t chan1_raw, int16_t chan2_raw, int16_t chan3_raw, int16_t chan4_raw, int16_t chan5_raw, int16_t chan6_raw, int16_t chan7_raw, int16_t chan8_raw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN];
    _mav_put_int16_t(buf, 0, chan1_raw);
    _mav_put_int16_t(buf, 2, chan2_raw);
    _mav_put_int16_t(buf, 4, chan3_raw);
    _mav_put_int16_t(buf, 6, chan4_raw);
    _mav_put_int16_t(buf, 8, chan5_raw);
    _mav_put_int16_t(buf, 10, chan6_raw);
    _mav_put_int16_t(buf, 12, chan7_raw);
    _mav_put_int16_t(buf, 14, chan8_raw);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW, buf, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_CRC);
#else
    mavlink_ylcx_rc_channels_raw_t packet;
    packet.chan1_raw = chan1_raw;
    packet.chan2_raw = chan2_raw;
    packet.chan3_raw = chan3_raw;
    packet.chan4_raw = chan4_raw;
    packet.chan5_raw = chan5_raw;
    packet.chan6_raw = chan6_raw;
    packet.chan7_raw = chan7_raw;
    packet.chan8_raw = chan8_raw;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW, (const char *)&packet, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_CRC);
#endif
}

/**
 * @brief Send a ylcx_rc_channels_raw message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_rc_channels_raw_send_struct(mavlink_channel_t chan, const mavlink_ylcx_rc_channels_raw_t* ylcx_rc_channels_raw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_rc_channels_raw_send(chan, ylcx_rc_channels_raw->chan1_raw, ylcx_rc_channels_raw->chan2_raw, ylcx_rc_channels_raw->chan3_raw, ylcx_rc_channels_raw->chan4_raw, ylcx_rc_channels_raw->chan5_raw, ylcx_rc_channels_raw->chan6_raw, ylcx_rc_channels_raw->chan7_raw, ylcx_rc_channels_raw->chan8_raw);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW, (const char *)ylcx_rc_channels_raw, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_rc_channels_raw_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int16_t chan1_raw, int16_t chan2_raw, int16_t chan3_raw, int16_t chan4_raw, int16_t chan5_raw, int16_t chan6_raw, int16_t chan7_raw, int16_t chan8_raw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int16_t(buf, 0, chan1_raw);
    _mav_put_int16_t(buf, 2, chan2_raw);
    _mav_put_int16_t(buf, 4, chan3_raw);
    _mav_put_int16_t(buf, 6, chan4_raw);
    _mav_put_int16_t(buf, 8, chan5_raw);
    _mav_put_int16_t(buf, 10, chan6_raw);
    _mav_put_int16_t(buf, 12, chan7_raw);
    _mav_put_int16_t(buf, 14, chan8_raw);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW, buf, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_CRC);
#else
    mavlink_ylcx_rc_channels_raw_t *packet = (mavlink_ylcx_rc_channels_raw_t *)msgbuf;
    packet->chan1_raw = chan1_raw;
    packet->chan2_raw = chan2_raw;
    packet->chan3_raw = chan3_raw;
    packet->chan4_raw = chan4_raw;
    packet->chan5_raw = chan5_raw;
    packet->chan6_raw = chan6_raw;
    packet->chan7_raw = chan7_raw;
    packet->chan8_raw = chan8_raw;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW, (const char *)packet, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_RC_CHANNELS_RAW UNPACKING


/**
 * @brief Get field chan1_raw from ylcx_rc_channels_raw message
 *
 * @return  RC channel 1 value. Usually used to control the host or left dirver
 */
static inline int16_t mavlink_msg_ylcx_rc_channels_raw_get_chan1_raw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  0);
}

/**
 * @brief Get field chan2_raw from ylcx_rc_channels_raw message
 *
 * @return  RC channel 2 value. Usually used to control the ruuder or right dirver
 */
static inline int16_t mavlink_msg_ylcx_rc_channels_raw_get_chan2_raw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  2);
}

/**
 * @brief Get field chan3_raw from ylcx_rc_channels_raw message
 *
 * @return  RC channel 3 value.
 */
static inline int16_t mavlink_msg_ylcx_rc_channels_raw_get_chan3_raw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  4);
}

/**
 * @brief Get field chan4_raw from ylcx_rc_channels_raw message
 *
 * @return  RC channel 4 value.
 */
static inline int16_t mavlink_msg_ylcx_rc_channels_raw_get_chan4_raw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  6);
}

/**
 * @brief Get field chan5_raw from ylcx_rc_channels_raw message
 *
 * @return  RC channel 5 value.
 */
static inline int16_t mavlink_msg_ylcx_rc_channels_raw_get_chan5_raw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  8);
}

/**
 * @brief Get field chan6_raw from ylcx_rc_channels_raw message
 *
 * @return  RC channel 6 value.
 */
static inline int16_t mavlink_msg_ylcx_rc_channels_raw_get_chan6_raw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  10);
}

/**
 * @brief Get field chan7_raw from ylcx_rc_channels_raw message
 *
 * @return  RC channel 7 value.
 */
static inline int16_t mavlink_msg_ylcx_rc_channels_raw_get_chan7_raw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  12);
}

/**
 * @brief Get field chan8_raw from ylcx_rc_channels_raw message
 *
 * @return  RC channel 8 value.
 */
static inline int16_t mavlink_msg_ylcx_rc_channels_raw_get_chan8_raw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  14);
}

/**
 * @brief Decode a ylcx_rc_channels_raw message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_rc_channels_raw C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_rc_channels_raw_decode(const mavlink_message_t* msg, mavlink_ylcx_rc_channels_raw_t* ylcx_rc_channels_raw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_rc_channels_raw->chan1_raw = mavlink_msg_ylcx_rc_channels_raw_get_chan1_raw(msg);
    ylcx_rc_channels_raw->chan2_raw = mavlink_msg_ylcx_rc_channels_raw_get_chan2_raw(msg);
    ylcx_rc_channels_raw->chan3_raw = mavlink_msg_ylcx_rc_channels_raw_get_chan3_raw(msg);
    ylcx_rc_channels_raw->chan4_raw = mavlink_msg_ylcx_rc_channels_raw_get_chan4_raw(msg);
    ylcx_rc_channels_raw->chan5_raw = mavlink_msg_ylcx_rc_channels_raw_get_chan5_raw(msg);
    ylcx_rc_channels_raw->chan6_raw = mavlink_msg_ylcx_rc_channels_raw_get_chan6_raw(msg);
    ylcx_rc_channels_raw->chan7_raw = mavlink_msg_ylcx_rc_channels_raw_get_chan7_raw(msg);
    ylcx_rc_channels_raw->chan8_raw = mavlink_msg_ylcx_rc_channels_raw_get_chan8_raw(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN? msg->len : MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN;
        memset(ylcx_rc_channels_raw, 0, MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_LEN);
    memcpy(ylcx_rc_channels_raw, _MAV_PAYLOAD(msg), len);
#endif
}
