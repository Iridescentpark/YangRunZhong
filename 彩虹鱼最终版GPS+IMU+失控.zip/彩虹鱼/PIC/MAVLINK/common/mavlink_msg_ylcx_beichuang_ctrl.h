#pragma once
// MESSAGE YLCX_BEICHUANG_CTRL PACKING

#define MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL 54407


typedef struct __mavlink_ylcx_beichuang_ctrl_t {
 float gps_speed; /*< [m/s] gps speed info.*/
 float compass_heading; /*< [deg] Compass heading info.*/
 float imu_heading; /*< [deg] imu heading info.*/
 float pid_p; /*<  PID p.*/
 float pid_i; /*<  PID i.*/
 float pid_d; /*<  PID i.*/
 float cmd_1; /*<  reserved.*/
 float cmd_2; /*<  reserved.*/
 int16_t mode; /*<  drive mode (0,1,2,3,4,5).*/
 int16_t speed; /*< [m/s] speed or left motor.*/
 int16_t heading; /*<  heading or right motor.*/
 int16_t light; /*<  light switch (0,1).*/
} mavlink_ylcx_beichuang_ctrl_t;

#define MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN 40
#define MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN 40
#define MAVLINK_MSG_ID_54407_LEN 40
#define MAVLINK_MSG_ID_54407_MIN_LEN 40

#define MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_CRC 159
#define MAVLINK_MSG_ID_54407_CRC 159



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_BEICHUANG_CTRL { \
    54407, \
    "YLCX_BEICHUANG_CTRL", \
    12, \
    {  { "mode", NULL, MAVLINK_TYPE_INT16_T, 0, 32, offsetof(mavlink_ylcx_beichuang_ctrl_t, mode) }, \
         { "speed", NULL, MAVLINK_TYPE_INT16_T, 0, 34, offsetof(mavlink_ylcx_beichuang_ctrl_t, speed) }, \
         { "heading", NULL, MAVLINK_TYPE_INT16_T, 0, 36, offsetof(mavlink_ylcx_beichuang_ctrl_t, heading) }, \
         { "light", NULL, MAVLINK_TYPE_INT16_T, 0, 38, offsetof(mavlink_ylcx_beichuang_ctrl_t, light) }, \
         { "gps_speed", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ylcx_beichuang_ctrl_t, gps_speed) }, \
         { "compass_heading", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_ylcx_beichuang_ctrl_t, compass_heading) }, \
         { "imu_heading", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ylcx_beichuang_ctrl_t, imu_heading) }, \
         { "pid_p", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ylcx_beichuang_ctrl_t, pid_p) }, \
         { "pid_i", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_ylcx_beichuang_ctrl_t, pid_i) }, \
         { "pid_d", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_ylcx_beichuang_ctrl_t, pid_d) }, \
         { "cmd_1", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_ylcx_beichuang_ctrl_t, cmd_1) }, \
         { "cmd_2", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_ylcx_beichuang_ctrl_t, cmd_2) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_BEICHUANG_CTRL { \
    "YLCX_BEICHUANG_CTRL", \
    12, \
    {  { "mode", NULL, MAVLINK_TYPE_INT16_T, 0, 32, offsetof(mavlink_ylcx_beichuang_ctrl_t, mode) }, \
         { "speed", NULL, MAVLINK_TYPE_INT16_T, 0, 34, offsetof(mavlink_ylcx_beichuang_ctrl_t, speed) }, \
         { "heading", NULL, MAVLINK_TYPE_INT16_T, 0, 36, offsetof(mavlink_ylcx_beichuang_ctrl_t, heading) }, \
         { "light", NULL, MAVLINK_TYPE_INT16_T, 0, 38, offsetof(mavlink_ylcx_beichuang_ctrl_t, light) }, \
         { "gps_speed", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ylcx_beichuang_ctrl_t, gps_speed) }, \
         { "compass_heading", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_ylcx_beichuang_ctrl_t, compass_heading) }, \
         { "imu_heading", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ylcx_beichuang_ctrl_t, imu_heading) }, \
         { "pid_p", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ylcx_beichuang_ctrl_t, pid_p) }, \
         { "pid_i", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_ylcx_beichuang_ctrl_t, pid_i) }, \
         { "pid_d", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_ylcx_beichuang_ctrl_t, pid_d) }, \
         { "cmd_1", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_ylcx_beichuang_ctrl_t, cmd_1) }, \
         { "cmd_2", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_ylcx_beichuang_ctrl_t, cmd_2) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_beichuang_ctrl message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param mode  drive mode (0,1,2,3,4,5).
 * @param speed [m/s] speed or left motor.
 * @param heading  heading or right motor.
 * @param light  light switch (0,1).
 * @param gps_speed [m/s] gps speed info.
 * @param compass_heading [deg] Compass heading info.
 * @param imu_heading [deg] imu heading info.
 * @param pid_p  PID p.
 * @param pid_i  PID i.
 * @param pid_d  PID i.
 * @param cmd_1  reserved.
 * @param cmd_2  reserved.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_beichuang_ctrl_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int16_t mode, int16_t speed, int16_t heading, int16_t light, float gps_speed, float compass_heading, float imu_heading, float pid_p, float pid_i, float pid_d, float cmd_1, float cmd_2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN];
    _mav_put_float(buf, 0, gps_speed);
    _mav_put_float(buf, 4, compass_heading);
    _mav_put_float(buf, 8, imu_heading);
    _mav_put_float(buf, 12, pid_p);
    _mav_put_float(buf, 16, pid_i);
    _mav_put_float(buf, 20, pid_d);
    _mav_put_float(buf, 24, cmd_1);
    _mav_put_float(buf, 28, cmd_2);
    _mav_put_int16_t(buf, 32, mode);
    _mav_put_int16_t(buf, 34, speed);
    _mav_put_int16_t(buf, 36, heading);
    _mav_put_int16_t(buf, 38, light);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN);
#else
    mavlink_ylcx_beichuang_ctrl_t packet;
    packet.gps_speed = gps_speed;
    packet.compass_heading = compass_heading;
    packet.imu_heading = imu_heading;
    packet.pid_p = pid_p;
    packet.pid_i = pid_i;
    packet.pid_d = pid_d;
    packet.cmd_1 = cmd_1;
    packet.cmd_2 = cmd_2;
    packet.mode = mode;
    packet.speed = speed;
    packet.heading = heading;
    packet.light = light;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_CRC);
}

/**
 * @brief Pack a ylcx_beichuang_ctrl message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param mode  drive mode (0,1,2,3,4,5).
 * @param speed [m/s] speed or left motor.
 * @param heading  heading or right motor.
 * @param light  light switch (0,1).
 * @param gps_speed [m/s] gps speed info.
 * @param compass_heading [deg] Compass heading info.
 * @param imu_heading [deg] imu heading info.
 * @param pid_p  PID p.
 * @param pid_i  PID i.
 * @param pid_d  PID i.
 * @param cmd_1  reserved.
 * @param cmd_2  reserved.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_beichuang_ctrl_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               int16_t mode, int16_t speed, int16_t heading, int16_t light, float gps_speed, float compass_heading, float imu_heading, float pid_p, float pid_i, float pid_d, float cmd_1, float cmd_2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN];
    _mav_put_float(buf, 0, gps_speed);
    _mav_put_float(buf, 4, compass_heading);
    _mav_put_float(buf, 8, imu_heading);
    _mav_put_float(buf, 12, pid_p);
    _mav_put_float(buf, 16, pid_i);
    _mav_put_float(buf, 20, pid_d);
    _mav_put_float(buf, 24, cmd_1);
    _mav_put_float(buf, 28, cmd_2);
    _mav_put_int16_t(buf, 32, mode);
    _mav_put_int16_t(buf, 34, speed);
    _mav_put_int16_t(buf, 36, heading);
    _mav_put_int16_t(buf, 38, light);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN);
#else
    mavlink_ylcx_beichuang_ctrl_t packet;
    packet.gps_speed = gps_speed;
    packet.compass_heading = compass_heading;
    packet.imu_heading = imu_heading;
    packet.pid_p = pid_p;
    packet.pid_i = pid_i;
    packet.pid_d = pid_d;
    packet.cmd_1 = cmd_1;
    packet.cmd_2 = cmd_2;
    packet.mode = mode;
    packet.speed = speed;
    packet.heading = heading;
    packet.light = light;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN);
#endif
}

/**
 * @brief Pack a ylcx_beichuang_ctrl message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param mode  drive mode (0,1,2,3,4,5).
 * @param speed [m/s] speed or left motor.
 * @param heading  heading or right motor.
 * @param light  light switch (0,1).
 * @param gps_speed [m/s] gps speed info.
 * @param compass_heading [deg] Compass heading info.
 * @param imu_heading [deg] imu heading info.
 * @param pid_p  PID p.
 * @param pid_i  PID i.
 * @param pid_d  PID i.
 * @param cmd_1  reserved.
 * @param cmd_2  reserved.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_beichuang_ctrl_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int16_t mode,int16_t speed,int16_t heading,int16_t light,float gps_speed,float compass_heading,float imu_heading,float pid_p,float pid_i,float pid_d,float cmd_1,float cmd_2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN];
    _mav_put_float(buf, 0, gps_speed);
    _mav_put_float(buf, 4, compass_heading);
    _mav_put_float(buf, 8, imu_heading);
    _mav_put_float(buf, 12, pid_p);
    _mav_put_float(buf, 16, pid_i);
    _mav_put_float(buf, 20, pid_d);
    _mav_put_float(buf, 24, cmd_1);
    _mav_put_float(buf, 28, cmd_2);
    _mav_put_int16_t(buf, 32, mode);
    _mav_put_int16_t(buf, 34, speed);
    _mav_put_int16_t(buf, 36, heading);
    _mav_put_int16_t(buf, 38, light);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN);
#else
    mavlink_ylcx_beichuang_ctrl_t packet;
    packet.gps_speed = gps_speed;
    packet.compass_heading = compass_heading;
    packet.imu_heading = imu_heading;
    packet.pid_p = pid_p;
    packet.pid_i = pid_i;
    packet.pid_d = pid_d;
    packet.cmd_1 = cmd_1;
    packet.cmd_2 = cmd_2;
    packet.mode = mode;
    packet.speed = speed;
    packet.heading = heading;
    packet.light = light;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_CRC);
}

/**
 * @brief Encode a ylcx_beichuang_ctrl struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_beichuang_ctrl C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_beichuang_ctrl_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_beichuang_ctrl_t* ylcx_beichuang_ctrl)
{
    return mavlink_msg_ylcx_beichuang_ctrl_pack(system_id, component_id, msg, ylcx_beichuang_ctrl->mode, ylcx_beichuang_ctrl->speed, ylcx_beichuang_ctrl->heading, ylcx_beichuang_ctrl->light, ylcx_beichuang_ctrl->gps_speed, ylcx_beichuang_ctrl->compass_heading, ylcx_beichuang_ctrl->imu_heading, ylcx_beichuang_ctrl->pid_p, ylcx_beichuang_ctrl->pid_i, ylcx_beichuang_ctrl->pid_d, ylcx_beichuang_ctrl->cmd_1, ylcx_beichuang_ctrl->cmd_2);
}

/**
 * @brief Encode a ylcx_beichuang_ctrl struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_beichuang_ctrl C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_beichuang_ctrl_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_beichuang_ctrl_t* ylcx_beichuang_ctrl)
{
    return mavlink_msg_ylcx_beichuang_ctrl_pack_chan(system_id, component_id, chan, msg, ylcx_beichuang_ctrl->mode, ylcx_beichuang_ctrl->speed, ylcx_beichuang_ctrl->heading, ylcx_beichuang_ctrl->light, ylcx_beichuang_ctrl->gps_speed, ylcx_beichuang_ctrl->compass_heading, ylcx_beichuang_ctrl->imu_heading, ylcx_beichuang_ctrl->pid_p, ylcx_beichuang_ctrl->pid_i, ylcx_beichuang_ctrl->pid_d, ylcx_beichuang_ctrl->cmd_1, ylcx_beichuang_ctrl->cmd_2);
}

/**
 * @brief Encode a ylcx_beichuang_ctrl struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_beichuang_ctrl C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_beichuang_ctrl_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_beichuang_ctrl_t* ylcx_beichuang_ctrl)
{
    return mavlink_msg_ylcx_beichuang_ctrl_pack_status(system_id, component_id, _status, msg,  ylcx_beichuang_ctrl->mode, ylcx_beichuang_ctrl->speed, ylcx_beichuang_ctrl->heading, ylcx_beichuang_ctrl->light, ylcx_beichuang_ctrl->gps_speed, ylcx_beichuang_ctrl->compass_heading, ylcx_beichuang_ctrl->imu_heading, ylcx_beichuang_ctrl->pid_p, ylcx_beichuang_ctrl->pid_i, ylcx_beichuang_ctrl->pid_d, ylcx_beichuang_ctrl->cmd_1, ylcx_beichuang_ctrl->cmd_2);
}

/**
 * @brief Send a ylcx_beichuang_ctrl message
 * @param chan MAVLink channel to send the message
 *
 * @param mode  drive mode (0,1,2,3,4,5).
 * @param speed [m/s] speed or left motor.
 * @param heading  heading or right motor.
 * @param light  light switch (0,1).
 * @param gps_speed [m/s] gps speed info.
 * @param compass_heading [deg] Compass heading info.
 * @param imu_heading [deg] imu heading info.
 * @param pid_p  PID p.
 * @param pid_i  PID i.
 * @param pid_d  PID i.
 * @param cmd_1  reserved.
 * @param cmd_2  reserved.
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_beichuang_ctrl_send(mavlink_channel_t chan, int16_t mode, int16_t speed, int16_t heading, int16_t light, float gps_speed, float compass_heading, float imu_heading, float pid_p, float pid_i, float pid_d, float cmd_1, float cmd_2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN];
    _mav_put_float(buf, 0, gps_speed);
    _mav_put_float(buf, 4, compass_heading);
    _mav_put_float(buf, 8, imu_heading);
    _mav_put_float(buf, 12, pid_p);
    _mav_put_float(buf, 16, pid_i);
    _mav_put_float(buf, 20, pid_d);
    _mav_put_float(buf, 24, cmd_1);
    _mav_put_float(buf, 28, cmd_2);
    _mav_put_int16_t(buf, 32, mode);
    _mav_put_int16_t(buf, 34, speed);
    _mav_put_int16_t(buf, 36, heading);
    _mav_put_int16_t(buf, 38, light);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL, buf, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_CRC);
#else
    mavlink_ylcx_beichuang_ctrl_t packet;
    packet.gps_speed = gps_speed;
    packet.compass_heading = compass_heading;
    packet.imu_heading = imu_heading;
    packet.pid_p = pid_p;
    packet.pid_i = pid_i;
    packet.pid_d = pid_d;
    packet.cmd_1 = cmd_1;
    packet.cmd_2 = cmd_2;
    packet.mode = mode;
    packet.speed = speed;
    packet.heading = heading;
    packet.light = light;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL, (const char *)&packet, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_CRC);
#endif
}

/**
 * @brief Send a ylcx_beichuang_ctrl message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_beichuang_ctrl_send_struct(mavlink_channel_t chan, const mavlink_ylcx_beichuang_ctrl_t* ylcx_beichuang_ctrl)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_beichuang_ctrl_send(chan, ylcx_beichuang_ctrl->mode, ylcx_beichuang_ctrl->speed, ylcx_beichuang_ctrl->heading, ylcx_beichuang_ctrl->light, ylcx_beichuang_ctrl->gps_speed, ylcx_beichuang_ctrl->compass_heading, ylcx_beichuang_ctrl->imu_heading, ylcx_beichuang_ctrl->pid_p, ylcx_beichuang_ctrl->pid_i, ylcx_beichuang_ctrl->pid_d, ylcx_beichuang_ctrl->cmd_1, ylcx_beichuang_ctrl->cmd_2);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL, (const char *)ylcx_beichuang_ctrl, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_beichuang_ctrl_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int16_t mode, int16_t speed, int16_t heading, int16_t light, float gps_speed, float compass_heading, float imu_heading, float pid_p, float pid_i, float pid_d, float cmd_1, float cmd_2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_float(buf, 0, gps_speed);
    _mav_put_float(buf, 4, compass_heading);
    _mav_put_float(buf, 8, imu_heading);
    _mav_put_float(buf, 12, pid_p);
    _mav_put_float(buf, 16, pid_i);
    _mav_put_float(buf, 20, pid_d);
    _mav_put_float(buf, 24, cmd_1);
    _mav_put_float(buf, 28, cmd_2);
    _mav_put_int16_t(buf, 32, mode);
    _mav_put_int16_t(buf, 34, speed);
    _mav_put_int16_t(buf, 36, heading);
    _mav_put_int16_t(buf, 38, light);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL, buf, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_CRC);
#else
    mavlink_ylcx_beichuang_ctrl_t *packet = (mavlink_ylcx_beichuang_ctrl_t *)msgbuf;
    packet->gps_speed = gps_speed;
    packet->compass_heading = compass_heading;
    packet->imu_heading = imu_heading;
    packet->pid_p = pid_p;
    packet->pid_i = pid_i;
    packet->pid_d = pid_d;
    packet->cmd_1 = cmd_1;
    packet->cmd_2 = cmd_2;
    packet->mode = mode;
    packet->speed = speed;
    packet->heading = heading;
    packet->light = light;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL, (const char *)packet, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_BEICHUANG_CTRL UNPACKING


/**
 * @brief Get field mode from ylcx_beichuang_ctrl message
 *
 * @return  drive mode (0,1,2,3,4,5).
 */
static inline int16_t mavlink_msg_ylcx_beichuang_ctrl_get_mode(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  32);
}

/**
 * @brief Get field speed from ylcx_beichuang_ctrl message
 *
 * @return [m/s] speed or left motor.
 */
static inline int16_t mavlink_msg_ylcx_beichuang_ctrl_get_speed(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  34);
}

/**
 * @brief Get field heading from ylcx_beichuang_ctrl message
 *
 * @return  heading or right motor.
 */
static inline int16_t mavlink_msg_ylcx_beichuang_ctrl_get_heading(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  36);
}

/**
 * @brief Get field light from ylcx_beichuang_ctrl message
 *
 * @return  light switch (0,1).
 */
static inline int16_t mavlink_msg_ylcx_beichuang_ctrl_get_light(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  38);
}

/**
 * @brief Get field gps_speed from ylcx_beichuang_ctrl message
 *
 * @return [m/s] gps speed info.
 */
static inline float mavlink_msg_ylcx_beichuang_ctrl_get_gps_speed(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Get field compass_heading from ylcx_beichuang_ctrl message
 *
 * @return [deg] Compass heading info.
 */
static inline float mavlink_msg_ylcx_beichuang_ctrl_get_compass_heading(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field imu_heading from ylcx_beichuang_ctrl message
 *
 * @return [deg] imu heading info.
 */
static inline float mavlink_msg_ylcx_beichuang_ctrl_get_imu_heading(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field pid_p from ylcx_beichuang_ctrl message
 *
 * @return  PID p.
 */
static inline float mavlink_msg_ylcx_beichuang_ctrl_get_pid_p(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Get field pid_i from ylcx_beichuang_ctrl message
 *
 * @return  PID i.
 */
static inline float mavlink_msg_ylcx_beichuang_ctrl_get_pid_i(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  16);
}

/**
 * @brief Get field pid_d from ylcx_beichuang_ctrl message
 *
 * @return  PID i.
 */
static inline float mavlink_msg_ylcx_beichuang_ctrl_get_pid_d(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  20);
}

/**
 * @brief Get field cmd_1 from ylcx_beichuang_ctrl message
 *
 * @return  reserved.
 */
static inline float mavlink_msg_ylcx_beichuang_ctrl_get_cmd_1(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  24);
}

/**
 * @brief Get field cmd_2 from ylcx_beichuang_ctrl message
 *
 * @return  reserved.
 */
static inline float mavlink_msg_ylcx_beichuang_ctrl_get_cmd_2(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  28);
}

/**
 * @brief Decode a ylcx_beichuang_ctrl message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_beichuang_ctrl C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_beichuang_ctrl_decode(const mavlink_message_t* msg, mavlink_ylcx_beichuang_ctrl_t* ylcx_beichuang_ctrl)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_beichuang_ctrl->gps_speed = mavlink_msg_ylcx_beichuang_ctrl_get_gps_speed(msg);
    ylcx_beichuang_ctrl->compass_heading = mavlink_msg_ylcx_beichuang_ctrl_get_compass_heading(msg);
    ylcx_beichuang_ctrl->imu_heading = mavlink_msg_ylcx_beichuang_ctrl_get_imu_heading(msg);
    ylcx_beichuang_ctrl->pid_p = mavlink_msg_ylcx_beichuang_ctrl_get_pid_p(msg);
    ylcx_beichuang_ctrl->pid_i = mavlink_msg_ylcx_beichuang_ctrl_get_pid_i(msg);
    ylcx_beichuang_ctrl->pid_d = mavlink_msg_ylcx_beichuang_ctrl_get_pid_d(msg);
    ylcx_beichuang_ctrl->cmd_1 = mavlink_msg_ylcx_beichuang_ctrl_get_cmd_1(msg);
    ylcx_beichuang_ctrl->cmd_2 = mavlink_msg_ylcx_beichuang_ctrl_get_cmd_2(msg);
    ylcx_beichuang_ctrl->mode = mavlink_msg_ylcx_beichuang_ctrl_get_mode(msg);
    ylcx_beichuang_ctrl->speed = mavlink_msg_ylcx_beichuang_ctrl_get_speed(msg);
    ylcx_beichuang_ctrl->heading = mavlink_msg_ylcx_beichuang_ctrl_get_heading(msg);
    ylcx_beichuang_ctrl->light = mavlink_msg_ylcx_beichuang_ctrl_get_light(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN? msg->len : MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN;
        memset(ylcx_beichuang_ctrl, 0, MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_LEN);
    memcpy(ylcx_beichuang_ctrl, _MAV_PAYLOAD(msg), len);
#endif
}
