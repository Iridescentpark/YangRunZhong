#pragma once
// MESSAGE YLCX_MPC_CONTROL PACKING

#define MAVLINK_MSG_ID_YLCX_MPC_CONTROL 54410


typedef struct __mavlink_ylcx_mpc_control_t {
 int16_t traget_propeller_speed; /*<  */
 int8_t target_rudder_angle; /*<  target_rudder_angle*/
} mavlink_ylcx_mpc_control_t;

#define MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN 3
#define MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN 3
#define MAVLINK_MSG_ID_54410_LEN 3
#define MAVLINK_MSG_ID_54410_MIN_LEN 3

#define MAVLINK_MSG_ID_YLCX_MPC_CONTROL_CRC 78
#define MAVLINK_MSG_ID_54410_CRC 78



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_MPC_CONTROL { \
    54410, \
    "YLCX_MPC_CONTROL", \
    2, \
    {  { "target_rudder_angle", NULL, MAVLINK_TYPE_INT8_T, 0, 2, offsetof(mavlink_ylcx_mpc_control_t, target_rudder_angle) }, \
         { "traget_propeller_speed", NULL, MAVLINK_TYPE_INT16_T, 0, 0, offsetof(mavlink_ylcx_mpc_control_t, traget_propeller_speed) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_MPC_CONTROL { \
    "YLCX_MPC_CONTROL", \
    2, \
    {  { "target_rudder_angle", NULL, MAVLINK_TYPE_INT8_T, 0, 2, offsetof(mavlink_ylcx_mpc_control_t, target_rudder_angle) }, \
         { "traget_propeller_speed", NULL, MAVLINK_TYPE_INT16_T, 0, 0, offsetof(mavlink_ylcx_mpc_control_t, traget_propeller_speed) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_mpc_control message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param target_rudder_angle  target_rudder_angle
 * @param traget_propeller_speed  
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_mpc_control_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int8_t target_rudder_angle, int16_t traget_propeller_speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN];
    _mav_put_int16_t(buf, 0, traget_propeller_speed);
    _mav_put_int8_t(buf, 2, target_rudder_angle);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN);
#else
    mavlink_ylcx_mpc_control_t packet;
    packet.traget_propeller_speed = traget_propeller_speed;
    packet.target_rudder_angle = target_rudder_angle;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_MPC_CONTROL;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_CRC);
}

/**
 * @brief Pack a ylcx_mpc_control message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param target_rudder_angle  target_rudder_angle
 * @param traget_propeller_speed  
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_mpc_control_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               int8_t target_rudder_angle, int16_t traget_propeller_speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN];
    _mav_put_int16_t(buf, 0, traget_propeller_speed);
    _mav_put_int8_t(buf, 2, target_rudder_angle);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN);
#else
    mavlink_ylcx_mpc_control_t packet;
    packet.traget_propeller_speed = traget_propeller_speed;
    packet.target_rudder_angle = target_rudder_angle;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_MPC_CONTROL;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN);
#endif
}

/**
 * @brief Pack a ylcx_mpc_control message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param target_rudder_angle  target_rudder_angle
 * @param traget_propeller_speed  
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_mpc_control_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int8_t target_rudder_angle,int16_t traget_propeller_speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN];
    _mav_put_int16_t(buf, 0, traget_propeller_speed);
    _mav_put_int8_t(buf, 2, target_rudder_angle);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN);
#else
    mavlink_ylcx_mpc_control_t packet;
    packet.traget_propeller_speed = traget_propeller_speed;
    packet.target_rudder_angle = target_rudder_angle;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_MPC_CONTROL;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_CRC);
}

/**
 * @brief Encode a ylcx_mpc_control struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_mpc_control C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_mpc_control_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_mpc_control_t* ylcx_mpc_control)
{
    return mavlink_msg_ylcx_mpc_control_pack(system_id, component_id, msg, ylcx_mpc_control->target_rudder_angle, ylcx_mpc_control->traget_propeller_speed);
}

/**
 * @brief Encode a ylcx_mpc_control struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_mpc_control C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_mpc_control_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_mpc_control_t* ylcx_mpc_control)
{
    return mavlink_msg_ylcx_mpc_control_pack_chan(system_id, component_id, chan, msg, ylcx_mpc_control->target_rudder_angle, ylcx_mpc_control->traget_propeller_speed);
}

/**
 * @brief Encode a ylcx_mpc_control struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_mpc_control C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_mpc_control_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_mpc_control_t* ylcx_mpc_control)
{
    return mavlink_msg_ylcx_mpc_control_pack_status(system_id, component_id, _status, msg,  ylcx_mpc_control->target_rudder_angle, ylcx_mpc_control->traget_propeller_speed);
}

/**
 * @brief Send a ylcx_mpc_control message
 * @param chan MAVLink channel to send the message
 *
 * @param target_rudder_angle  target_rudder_angle
 * @param traget_propeller_speed  
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_mpc_control_send(mavlink_channel_t chan, int8_t target_rudder_angle, int16_t traget_propeller_speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN];
    _mav_put_int16_t(buf, 0, traget_propeller_speed);
    _mav_put_int8_t(buf, 2, target_rudder_angle);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_MPC_CONTROL, buf, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_CRC);
#else
    mavlink_ylcx_mpc_control_t packet;
    packet.traget_propeller_speed = traget_propeller_speed;
    packet.target_rudder_angle = target_rudder_angle;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_MPC_CONTROL, (const char *)&packet, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_CRC);
#endif
}

/**
 * @brief Send a ylcx_mpc_control message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_mpc_control_send_struct(mavlink_channel_t chan, const mavlink_ylcx_mpc_control_t* ylcx_mpc_control)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_mpc_control_send(chan, ylcx_mpc_control->target_rudder_angle, ylcx_mpc_control->traget_propeller_speed);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_MPC_CONTROL, (const char *)ylcx_mpc_control, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_mpc_control_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int8_t target_rudder_angle, int16_t traget_propeller_speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int16_t(buf, 0, traget_propeller_speed);
    _mav_put_int8_t(buf, 2, target_rudder_angle);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_MPC_CONTROL, buf, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_CRC);
#else
    mavlink_ylcx_mpc_control_t *packet = (mavlink_ylcx_mpc_control_t *)msgbuf;
    packet->traget_propeller_speed = traget_propeller_speed;
    packet->target_rudder_angle = target_rudder_angle;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_MPC_CONTROL, (const char *)packet, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_MPC_CONTROL UNPACKING


/**
 * @brief Get field target_rudder_angle from ylcx_mpc_control message
 *
 * @return  target_rudder_angle
 */
static inline int8_t mavlink_msg_ylcx_mpc_control_get_target_rudder_angle(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  2);
}

/**
 * @brief Get field traget_propeller_speed from ylcx_mpc_control message
 *
 * @return  
 */
static inline int16_t mavlink_msg_ylcx_mpc_control_get_traget_propeller_speed(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  0);
}

/**
 * @brief Decode a ylcx_mpc_control message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_mpc_control C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_mpc_control_decode(const mavlink_message_t* msg, mavlink_ylcx_mpc_control_t* ylcx_mpc_control)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_mpc_control->traget_propeller_speed = mavlink_msg_ylcx_mpc_control_get_traget_propeller_speed(msg);
    ylcx_mpc_control->target_rudder_angle = mavlink_msg_ylcx_mpc_control_get_target_rudder_angle(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN? msg->len : MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN;
        memset(ylcx_mpc_control, 0, MAVLINK_MSG_ID_YLCX_MPC_CONTROL_LEN);
    memcpy(ylcx_mpc_control, _MAV_PAYLOAD(msg), len);
#endif
}
