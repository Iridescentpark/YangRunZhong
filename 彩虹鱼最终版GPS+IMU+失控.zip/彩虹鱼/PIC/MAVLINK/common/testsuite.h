/** @file
 *    @brief MAVLink comm protocol testsuite generated from ylcx.xml
 *    @see https://mavlink.io/en/
 */
#pragma once
#ifndef YLCX_TESTSUITE_H
#define YLCX_TESTSUITE_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MAVLINK_TEST_ALL
#define MAVLINK_TEST_ALL
static void mavlink_test_standard(uint8_t, uint8_t, mavlink_message_t *last_msg);
static void mavlink_test_common(uint8_t, uint8_t, mavlink_message_t *last_msg);
static void mavlink_test_ylcx(uint8_t, uint8_t, mavlink_message_t *last_msg);

static void mavlink_test_all(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
    mavlink_test_standard(system_id, component_id, last_msg);
    mavlink_test_common(system_id, component_id, last_msg);
    mavlink_test_ylcx(system_id, component_id, last_msg);
}
#endif

#include "../standard/testsuite.h"
#include "../common/testsuite.h"


static void mavlink_test_ylcx_vehicle_status(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_vehicle_status_t packet_in = {
        963497464,17,84
    };
    mavlink_ylcx_vehicle_status_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.temperature = packet_in.temperature;
        packet1.water_alarm = packet_in.water_alarm;
        packet1.urgency_alarm = packet_in.urgency_alarm;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_status_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_vehicle_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_status_pack(system_id, component_id, &msg , packet1.water_alarm , packet1.urgency_alarm , packet1.temperature );
    mavlink_msg_ylcx_vehicle_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_status_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.water_alarm , packet1.urgency_alarm , packet1.temperature );
    mavlink_msg_ylcx_vehicle_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_vehicle_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_status_send(MAVLINK_COMM_1 , packet1.water_alarm , packet1.urgency_alarm , packet1.temperature );
    mavlink_msg_ylcx_vehicle_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_VEHICLE_STATUS") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS) != NULL);
#endif
}

static void mavlink_test_ylcx_driver_status(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_DRIVER_STATUS >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_driver_status_t packet_in = {
        17.0,45.0,73.0,101.0
    };
    mavlink_ylcx_driver_status_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.rpm = packet_in.rpm;
        packet1.torque = packet_in.torque;
        packet1.power = packet_in.power;
        packet1.current_rudder = packet_in.current_rudder;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_driver_status_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_driver_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_driver_status_pack(system_id, component_id, &msg , packet1.rpm , packet1.torque , packet1.power , packet1.current_rudder );
    mavlink_msg_ylcx_driver_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_driver_status_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.rpm , packet1.torque , packet1.power , packet1.current_rudder );
    mavlink_msg_ylcx_driver_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_driver_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_driver_status_send(MAVLINK_COMM_1 , packet1.rpm , packet1.torque , packet1.power , packet1.current_rudder );
    mavlink_msg_ylcx_driver_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_DRIVER_STATUS") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_DRIVER_STATUS) != NULL);
#endif
}

static void mavlink_test_ylcx_battery_status(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_BATTERY_STATUS >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_battery_status_t packet_in = {
        963497464,963497672,963497880,963498088,963498296,65,132,199
    };
    mavlink_ylcx_battery_status_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.temperature = packet_in.temperature;
        packet1.voltage = packet_in.voltage;
        packet1.current_battery = packet_in.current_battery;
        packet1.current_consumed = packet_in.current_consumed;
        packet1.energy_consumed = packet_in.energy_consumed;
        packet1.id = packet_in.id;
        packet1.type = packet_in.type;
        packet1.battery_remaining = packet_in.battery_remaining;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_BATTERY_STATUS_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_BATTERY_STATUS_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_battery_status_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_battery_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_battery_status_pack(system_id, component_id, &msg , packet1.id , packet1.type , packet1.temperature , packet1.voltage , packet1.current_battery , packet1.current_consumed , packet1.energy_consumed , packet1.battery_remaining );
    mavlink_msg_ylcx_battery_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_battery_status_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.id , packet1.type , packet1.temperature , packet1.voltage , packet1.current_battery , packet1.current_consumed , packet1.energy_consumed , packet1.battery_remaining );
    mavlink_msg_ylcx_battery_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_battery_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_battery_status_send(MAVLINK_COMM_1 , packet1.id , packet1.type , packet1.temperature , packet1.voltage , packet1.current_battery , packet1.current_consumed , packet1.energy_consumed , packet1.battery_remaining );
    mavlink_msg_ylcx_battery_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_BATTERY_STATUS") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_BATTERY_STATUS) != NULL);
#endif
}

static void mavlink_test_ylcx_rc_channels_raw(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_rc_channels_raw_t packet_in = {
        17235,17339,17443,17547,17651,17755,17859,17963
    };
    mavlink_ylcx_rc_channels_raw_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.chan1_raw = packet_in.chan1_raw;
        packet1.chan2_raw = packet_in.chan2_raw;
        packet1.chan3_raw = packet_in.chan3_raw;
        packet1.chan4_raw = packet_in.chan4_raw;
        packet1.chan5_raw = packet_in.chan5_raw;
        packet1.chan6_raw = packet_in.chan6_raw;
        packet1.chan7_raw = packet_in.chan7_raw;
        packet1.chan8_raw = packet_in.chan8_raw;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rc_channels_raw_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_rc_channels_raw_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rc_channels_raw_pack(system_id, component_id, &msg , packet1.chan1_raw , packet1.chan2_raw , packet1.chan3_raw , packet1.chan4_raw , packet1.chan5_raw , packet1.chan6_raw , packet1.chan7_raw , packet1.chan8_raw );
    mavlink_msg_ylcx_rc_channels_raw_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rc_channels_raw_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.chan1_raw , packet1.chan2_raw , packet1.chan3_raw , packet1.chan4_raw , packet1.chan5_raw , packet1.chan6_raw , packet1.chan7_raw , packet1.chan8_raw );
    mavlink_msg_ylcx_rc_channels_raw_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_rc_channels_raw_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rc_channels_raw_send(MAVLINK_COMM_1 , packet1.chan1_raw , packet1.chan2_raw , packet1.chan3_raw , packet1.chan4_raw , packet1.chan5_raw , packet1.chan6_raw , packet1.chan7_raw , packet1.chan8_raw );
    mavlink_msg_ylcx_rc_channels_raw_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_RC_CHANNELS_RAW") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_RC_CHANNELS_RAW) != NULL);
#endif
}

static void mavlink_test_ylcx_vehicle_parameter_request(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_REQUEST >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_vehicle_parameter_request_t packet_in = {
        5
    };
    mavlink_ylcx_vehicle_parameter_request_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.count = packet_in.count;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_REQUEST_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_REQUEST_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_request_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_vehicle_parameter_request_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_request_pack(system_id, component_id, &msg , packet1.count );
    mavlink_msg_ylcx_vehicle_parameter_request_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_request_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.count );
    mavlink_msg_ylcx_vehicle_parameter_request_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_vehicle_parameter_request_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_request_send(MAVLINK_COMM_1 , packet1.count );
    mavlink_msg_ylcx_vehicle_parameter_request_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_VEHICLE_PARAMETER_REQUEST") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_REQUEST) != NULL);
#endif
}

static void mavlink_test_ylcx_vehicle_parameter(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_vehicle_parameter_t packet_in = {
        17.0,45.0,73.0,101.0,129.0,157.0,185.0,213.0,241.0,269.0,19315,19419,19523,19627,149,216,27,94,161,228,39,106,173,240,51,118
    };
    mavlink_ylcx_vehicle_parameter_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.d_kp = packet_in.d_kp;
        packet1.d_ki = packet_in.d_ki;
        packet1.d_kd = packet_in.d_kd;
        packet1.v_kp = packet_in.v_kp;
        packet1.v_ki = packet_in.v_ki;
        packet1.v_kd = packet_in.v_kd;
        packet1.l1_kp = packet_in.l1_kp;
        packet1.l1_ki = packet_in.l1_ki;
        packet1.l1_kd = packet_in.l1_kd;
        packet1.path_distance = packet_in.path_distance;
        packet1.z_over_angle = packet_in.z_over_angle;
        packet1.z_rudder_angle = packet_in.z_rudder_angle;
        packet1.rotation_rudder_angle = packet_in.rotation_rudder_angle;
        packet1.return_rudder_angle = packet_in.return_rudder_angle;
        packet1.z_direction = packet_in.z_direction;
        packet1.z_velo = packet_in.z_velo;
        packet1.z_over_count = packet_in.z_over_count;
        packet1.z_rudder_speed = packet_in.z_rudder_speed;
        packet1.rotation_direction = packet_in.rotation_direction;
        packet1.rotation_velo = packet_in.rotation_velo;
        packet1.rotation_rudder_speed = packet_in.rotation_rudder_speed;
        packet1.urgent_speed = packet_in.urgent_speed;
        packet1.inertia_speed = packet_in.inertia_speed;
        packet1.return_rudder_speed = packet_in.return_rudder_speed;
        packet1.return_rudder_direction = packet_in.return_rudder_direction;
        packet1.return_rudder_velo = packet_in.return_rudder_velo;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_vehicle_parameter_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_pack(system_id, component_id, &msg , packet1.z_over_angle , packet1.z_direction , packet1.z_velo , packet1.z_over_count , packet1.z_rudder_speed , packet1.z_rudder_angle , packet1.rotation_direction , packet1.rotation_velo , packet1.rotation_rudder_angle , packet1.rotation_rudder_speed , packet1.urgent_speed , packet1.inertia_speed , packet1.return_rudder_speed , packet1.return_rudder_angle , packet1.return_rudder_direction , packet1.return_rudder_velo , packet1.d_kp , packet1.d_ki , packet1.d_kd , packet1.v_kp , packet1.v_ki , packet1.v_kd , packet1.l1_kp , packet1.l1_ki , packet1.l1_kd , packet1.path_distance );
    mavlink_msg_ylcx_vehicle_parameter_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.z_over_angle , packet1.z_direction , packet1.z_velo , packet1.z_over_count , packet1.z_rudder_speed , packet1.z_rudder_angle , packet1.rotation_direction , packet1.rotation_velo , packet1.rotation_rudder_angle , packet1.rotation_rudder_speed , packet1.urgent_speed , packet1.inertia_speed , packet1.return_rudder_speed , packet1.return_rudder_angle , packet1.return_rudder_direction , packet1.return_rudder_velo , packet1.d_kp , packet1.d_ki , packet1.d_kd , packet1.v_kp , packet1.v_ki , packet1.v_kd , packet1.l1_kp , packet1.l1_ki , packet1.l1_kd , packet1.path_distance );
    mavlink_msg_ylcx_vehicle_parameter_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_vehicle_parameter_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_send(MAVLINK_COMM_1 , packet1.z_over_angle , packet1.z_direction , packet1.z_velo , packet1.z_over_count , packet1.z_rudder_speed , packet1.z_rudder_angle , packet1.rotation_direction , packet1.rotation_velo , packet1.rotation_rudder_angle , packet1.rotation_rudder_speed , packet1.urgent_speed , packet1.inertia_speed , packet1.return_rudder_speed , packet1.return_rudder_angle , packet1.return_rudder_direction , packet1.return_rudder_velo , packet1.d_kp , packet1.d_ki , packet1.d_kd , packet1.v_kp , packet1.v_ki , packet1.v_kd , packet1.l1_kp , packet1.l1_ki , packet1.l1_kd , packet1.path_distance );
    mavlink_msg_ylcx_vehicle_parameter_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_VEHICLE_PARAMETER") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER) != NULL);
#endif
}

static void mavlink_test_ylcx_vehicle_parameter_ack(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_ACK >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_vehicle_parameter_ack_t packet_in = {
        5,72
    };
    mavlink_ylcx_vehicle_parameter_ack_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.count = packet_in.count;
        packet1.ack = packet_in.ack;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_ACK_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_ACK_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_ack_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_vehicle_parameter_ack_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_ack_pack(system_id, component_id, &msg , packet1.count , packet1.ack );
    mavlink_msg_ylcx_vehicle_parameter_ack_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_ack_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.count , packet1.ack );
    mavlink_msg_ylcx_vehicle_parameter_ack_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_vehicle_parameter_ack_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_vehicle_parameter_ack_send(MAVLINK_COMM_1 , packet1.count , packet1.ack );
    mavlink_msg_ylcx_vehicle_parameter_ack_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_VEHICLE_PARAMETER_ACK") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_ACK) != NULL);
#endif
}

static void mavlink_test_ylcx_uwb_raw_int(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_UWB_RAW_INT >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_uwb_raw_int_t packet_in = {
        963497464,963497672,963497880,963498088,963498296,963498504,963498712,963498920,18899,19003,19107,19211,125,192
    };
    mavlink_ylcx_uwb_raw_int_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.x = packet_in.x;
        packet1.y = packet_in.y;
        packet1.x_acc = packet_in.x_acc;
        packet1.y_acc = packet_in.y_acc;
        packet1.x_hdg_acc = packet_in.x_hdg_acc;
        packet1.y_hdg_acc = packet_in.y_hdg_acc;
        packet1.lat = packet_in.lat;
        packet1.lon = packet_in.lon;
        packet1.x_ep = packet_in.x_ep;
        packet1.y_ep = packet_in.y_ep;
        packet1.velo = packet_in.velo;
        packet1.yaw = packet_in.yaw;
        packet1.x1_vec = packet_in.x1_vec;
        packet1.y1_vec = packet_in.y1_vec;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_uwb_raw_int_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_uwb_raw_int_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_uwb_raw_int_pack(system_id, component_id, &msg , packet1.x , packet1.y , packet1.x_ep , packet1.y_ep , packet1.x_acc , packet1.y_acc , packet1.x_hdg_acc , packet1.y_hdg_acc , packet1.lat , packet1.lon , packet1.velo , packet1.yaw , packet1.x1_vec , packet1.y1_vec );
    mavlink_msg_ylcx_uwb_raw_int_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_uwb_raw_int_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.x , packet1.y , packet1.x_ep , packet1.y_ep , packet1.x_acc , packet1.y_acc , packet1.x_hdg_acc , packet1.y_hdg_acc , packet1.lat , packet1.lon , packet1.velo , packet1.yaw , packet1.x1_vec , packet1.y1_vec );
    mavlink_msg_ylcx_uwb_raw_int_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_uwb_raw_int_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_uwb_raw_int_send(MAVLINK_COMM_1 , packet1.x , packet1.y , packet1.x_ep , packet1.y_ep , packet1.x_acc , packet1.y_acc , packet1.x_hdg_acc , packet1.y_hdg_acc , packet1.lat , packet1.lon , packet1.velo , packet1.yaw , packet1.x1_vec , packet1.y1_vec );
    mavlink_msg_ylcx_uwb_raw_int_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_UWB_RAW_INT") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_UWB_RAW_INT) != NULL);
#endif
}

static void mavlink_test_ylcx_ros_channels_raw(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_ROS_CHANNELS_RAW >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_ros_channels_raw_t packet_in = {
        17235,17339,17443,17547,17651,17755,17859,17963
    };
    mavlink_ylcx_ros_channels_raw_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.chan1_raw = packet_in.chan1_raw;
        packet1.chan2_raw = packet_in.chan2_raw;
        packet1.chan3_raw = packet_in.chan3_raw;
        packet1.chan4_raw = packet_in.chan4_raw;
        packet1.chan5_raw = packet_in.chan5_raw;
        packet1.chan6_raw = packet_in.chan6_raw;
        packet1.chan7_raw = packet_in.chan7_raw;
        packet1.chan8_raw = packet_in.chan8_raw;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_ROS_CHANNELS_RAW_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_ROS_CHANNELS_RAW_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_ros_channels_raw_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_ros_channels_raw_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_ros_channels_raw_pack(system_id, component_id, &msg , packet1.chan1_raw , packet1.chan2_raw , packet1.chan3_raw , packet1.chan4_raw , packet1.chan5_raw , packet1.chan6_raw , packet1.chan7_raw , packet1.chan8_raw );
    mavlink_msg_ylcx_ros_channels_raw_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_ros_channels_raw_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.chan1_raw , packet1.chan2_raw , packet1.chan3_raw , packet1.chan4_raw , packet1.chan5_raw , packet1.chan6_raw , packet1.chan7_raw , packet1.chan8_raw );
    mavlink_msg_ylcx_ros_channels_raw_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_ros_channels_raw_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_ros_channels_raw_send(MAVLINK_COMM_1 , packet1.chan1_raw , packet1.chan2_raw , packet1.chan3_raw , packet1.chan4_raw , packet1.chan5_raw , packet1.chan6_raw , packet1.chan7_raw , packet1.chan8_raw );
    mavlink_msg_ylcx_ros_channels_raw_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_ROS_CHANNELS_RAW") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_ROS_CHANNELS_RAW) != NULL);
#endif
}

static void mavlink_test_ylcx_execute_algo(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_EXECUTE_ALGO >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_execute_algo_t packet_in = {
        5,72
    };
    mavlink_ylcx_execute_algo_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.type = packet_in.type;
        packet1.enable = packet_in.enable;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_EXECUTE_ALGO_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_EXECUTE_ALGO_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_execute_algo_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_execute_algo_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_execute_algo_pack(system_id, component_id, &msg , packet1.type , packet1.enable );
    mavlink_msg_ylcx_execute_algo_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_execute_algo_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.type , packet1.enable );
    mavlink_msg_ylcx_execute_algo_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_execute_algo_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_execute_algo_send(MAVLINK_COMM_1 , packet1.type , packet1.enable );
    mavlink_msg_ylcx_execute_algo_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_EXECUTE_ALGO") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_EXECUTE_ALGO) != NULL);
#endif
}

static void mavlink_test_ylcx_execute_algo_ack(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_EXECUTE_ALGO_ACK >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_execute_algo_ack_t packet_in = {
        5,72
    };
    mavlink_ylcx_execute_algo_ack_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.type = packet_in.type;
        packet1.result = packet_in.result;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_EXECUTE_ALGO_ACK_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_EXECUTE_ALGO_ACK_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_execute_algo_ack_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_execute_algo_ack_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_execute_algo_ack_pack(system_id, component_id, &msg , packet1.type , packet1.result );
    mavlink_msg_ylcx_execute_algo_ack_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_execute_algo_ack_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.type , packet1.result );
    mavlink_msg_ylcx_execute_algo_ack_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_execute_algo_ack_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_execute_algo_ack_send(MAVLINK_COMM_1 , packet1.type , packet1.result );
    mavlink_msg_ylcx_execute_algo_ack_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_EXECUTE_ALGO_ACK") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_EXECUTE_ALGO_ACK) != NULL);
#endif
}

static void mavlink_test_ylcx_rpm_speed_raw(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_RPM_SPEED_RAW >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_rpm_speed_raw_t packet_in = {
        17.0,17443
    };
    mavlink_ylcx_rpm_speed_raw_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.speed = packet_in.speed;
        packet1.rpm = packet_in.rpm;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_RPM_SPEED_RAW_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_RPM_SPEED_RAW_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rpm_speed_raw_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_rpm_speed_raw_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rpm_speed_raw_pack(system_id, component_id, &msg , packet1.rpm , packet1.speed );
    mavlink_msg_ylcx_rpm_speed_raw_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rpm_speed_raw_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.rpm , packet1.speed );
    mavlink_msg_ylcx_rpm_speed_raw_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_rpm_speed_raw_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rpm_speed_raw_send(MAVLINK_COMM_1 , packet1.rpm , packet1.speed );
    mavlink_msg_ylcx_rpm_speed_raw_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_RPM_SPEED_RAW") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_RPM_SPEED_RAW) != NULL);
#endif
}

static void mavlink_test_ylcx_spider_set_vehicle_ack(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_ACK >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_spider_set_vehicle_ack_t packet_in = {
        5,72,139,206,17
    };
    mavlink_ylcx_spider_set_vehicle_ack_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.headlight = packet_in.headlight;
        packet1.beaconlight = packet_in.beaconlight;
        packet1.lowlight = packet_in.lowlight;
        packet1.farlight = packet_in.farlight;
        packet1.liferaft = packet_in.liferaft;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_ACK_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_ACK_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehicle_ack_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_spider_set_vehicle_ack_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehicle_ack_pack(system_id, component_id, &msg , packet1.headlight , packet1.beaconlight , packet1.lowlight , packet1.farlight , packet1.liferaft );
    mavlink_msg_ylcx_spider_set_vehicle_ack_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehicle_ack_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.headlight , packet1.beaconlight , packet1.lowlight , packet1.farlight , packet1.liferaft );
    mavlink_msg_ylcx_spider_set_vehicle_ack_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_spider_set_vehicle_ack_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehicle_ack_send(MAVLINK_COMM_1 , packet1.headlight , packet1.beaconlight , packet1.lowlight , packet1.farlight , packet1.liferaft );
    mavlink_msg_ylcx_spider_set_vehicle_ack_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_SPIDER_SET_VEHICLE_ACK") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_ACK) != NULL);
#endif
}

static void mavlink_test_ylcx_spider_set_platform(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_SPIDER_SET_PLATFORM >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_spider_set_platform_t packet_in = {
        5
    };
    mavlink_ylcx_spider_set_platform_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.status = packet_in.status;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_SPIDER_SET_PLATFORM_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_SPIDER_SET_PLATFORM_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_platform_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_spider_set_platform_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_platform_pack(system_id, component_id, &msg , packet1.status );
    mavlink_msg_ylcx_spider_set_platform_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_platform_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.status );
    mavlink_msg_ylcx_spider_set_platform_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_spider_set_platform_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_platform_send(MAVLINK_COMM_1 , packet1.status );
    mavlink_msg_ylcx_spider_set_platform_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_SPIDER_SET_PLATFORM") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_SPIDER_SET_PLATFORM) != NULL);
#endif
}

static void mavlink_test_ylcx_spider_set_ptz(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_SPIDER_SET_PTZ >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_spider_set_ptz_t packet_in = {
        5
    };
    mavlink_ylcx_spider_set_ptz_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.status = packet_in.status;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_SPIDER_SET_PTZ_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_SPIDER_SET_PTZ_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_ptz_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_spider_set_ptz_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_ptz_pack(system_id, component_id, &msg , packet1.status );
    mavlink_msg_ylcx_spider_set_ptz_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_ptz_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.status );
    mavlink_msg_ylcx_spider_set_ptz_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_spider_set_ptz_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_ptz_send(MAVLINK_COMM_1 , packet1.status );
    mavlink_msg_ylcx_spider_set_ptz_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_SPIDER_SET_PTZ") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_SPIDER_SET_PTZ) != NULL);
#endif
}

static void mavlink_test_ylcx_spider_set_vehicle(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_spider_set_vehicle_t packet_in = {
        5,72,139,206,17
    };
    mavlink_ylcx_spider_set_vehicle_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.headlight = packet_in.headlight;
        packet1.beaconlight = packet_in.beaconlight;
        packet1.lowlight = packet_in.lowlight;
        packet1.farlight = packet_in.farlight;
        packet1.liferaft = packet_in.liferaft;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehicle_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_spider_set_vehicle_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehicle_pack(system_id, component_id, &msg , packet1.headlight , packet1.beaconlight , packet1.lowlight , packet1.farlight , packet1.liferaft );
    mavlink_msg_ylcx_spider_set_vehicle_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehicle_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.headlight , packet1.beaconlight , packet1.lowlight , packet1.farlight , packet1.liferaft );
    mavlink_msg_ylcx_spider_set_vehicle_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_spider_set_vehicle_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehicle_send(MAVLINK_COMM_1 , packet1.headlight , packet1.beaconlight , packet1.lowlight , packet1.farlight , packet1.liferaft );
    mavlink_msg_ylcx_spider_set_vehicle_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_SPIDER_SET_VEHICLE") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHICLE) != NULL);
#endif
}

static void mavlink_test_ylcx_spider_battery(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_spider_battery_t packet_in = {
        963497464,963497672,963497880,17859,175,242,53,120,187,254,65,132,199,10,77,144
    };
    mavlink_ylcx_spider_battery_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.voltage = packet_in.voltage;
        packet1.current = packet_in.current;
        packet1.temperature = packet_in.temperature;
        packet1.battery_remaining = packet_in.battery_remaining;
        packet1.id = packet_in.id;
        packet1.type = packet_in.type;
        packet1.in_voltage_high = packet_in.in_voltage_high;
        packet1.in_voltage_low = packet_in.in_voltage_low;
        packet1.in_current_high = packet_in.in_current_high;
        packet1.in_temperature_high = packet_in.in_temperature_high;
        packet1.in_temperature_low = packet_in.in_temperature_low;
        packet1.out_voltage_high = packet_in.out_voltage_high;
        packet1.out_voltage_low = packet_in.out_voltage_low;
        packet1.out_current_high = packet_in.out_current_high;
        packet1.out_temperature_high = packet_in.out_temperature_high;
        packet1.out_temperature_low = packet_in.out_temperature_low;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_battery_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_spider_battery_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_battery_pack(system_id, component_id, &msg , packet1.id , packet1.type , packet1.voltage , packet1.current , packet1.battery_remaining , packet1.temperature , packet1.in_voltage_high , packet1.in_voltage_low , packet1.in_current_high , packet1.in_temperature_high , packet1.in_temperature_low , packet1.out_voltage_high , packet1.out_voltage_low , packet1.out_current_high , packet1.out_temperature_high , packet1.out_temperature_low );
    mavlink_msg_ylcx_spider_battery_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_battery_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.id , packet1.type , packet1.voltage , packet1.current , packet1.battery_remaining , packet1.temperature , packet1.in_voltage_high , packet1.in_voltage_low , packet1.in_current_high , packet1.in_temperature_high , packet1.in_temperature_low , packet1.out_voltage_high , packet1.out_voltage_low , packet1.out_current_high , packet1.out_temperature_high , packet1.out_temperature_low );
    mavlink_msg_ylcx_spider_battery_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_spider_battery_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_battery_send(MAVLINK_COMM_1 , packet1.id , packet1.type , packet1.voltage , packet1.current , packet1.battery_remaining , packet1.temperature , packet1.in_voltage_high , packet1.in_voltage_low , packet1.in_current_high , packet1.in_temperature_high , packet1.in_temperature_low , packet1.out_voltage_high , packet1.out_voltage_low , packet1.out_current_high , packet1.out_temperature_high , packet1.out_temperature_low );
    mavlink_msg_ylcx_spider_battery_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_SPIDER_BATTERY") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY) != NULL);
#endif
}

static void mavlink_test_ylcx_spider_set_vehcile_2(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHCILE_2 >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_spider_set_vehcile_2_t packet_in = {
        5,72
    };
    mavlink_ylcx_spider_set_vehcile_2_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.type = packet_in.type;
        packet1.cmd = packet_in.cmd;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHCILE_2_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHCILE_2_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehcile_2_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_spider_set_vehcile_2_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehcile_2_pack(system_id, component_id, &msg , packet1.type , packet1.cmd );
    mavlink_msg_ylcx_spider_set_vehcile_2_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehcile_2_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.type , packet1.cmd );
    mavlink_msg_ylcx_spider_set_vehcile_2_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_spider_set_vehcile_2_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_spider_set_vehcile_2_send(MAVLINK_COMM_1 , packet1.type , packet1.cmd );
    mavlink_msg_ylcx_spider_set_vehcile_2_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_SPIDER_SET_VEHCILE_2") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_SPIDER_SET_VEHCILE_2) != NULL);
#endif
}

static void mavlink_test_ylcx_beichuang_ctrl(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_beichuang_ctrl_t packet_in = {
        17.0,45.0,73.0,101.0,129.0,157.0,185.0,213.0,18899,19003,19107,19211
    };
    mavlink_ylcx_beichuang_ctrl_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.gps_speed = packet_in.gps_speed;
        packet1.compass_heading = packet_in.compass_heading;
        packet1.imu_heading = packet_in.imu_heading;
        packet1.pid_p = packet_in.pid_p;
        packet1.pid_i = packet_in.pid_i;
        packet1.pid_d = packet_in.pid_d;
        packet1.cmd_1 = packet_in.cmd_1;
        packet1.cmd_2 = packet_in.cmd_2;
        packet1.mode = packet_in.mode;
        packet1.speed = packet_in.speed;
        packet1.heading = packet_in.heading;
        packet1.light = packet_in.light;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_beichuang_ctrl_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_beichuang_ctrl_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_beichuang_ctrl_pack(system_id, component_id, &msg , packet1.mode , packet1.speed , packet1.heading , packet1.light , packet1.gps_speed , packet1.compass_heading , packet1.imu_heading , packet1.pid_p , packet1.pid_i , packet1.pid_d , packet1.cmd_1 , packet1.cmd_2 );
    mavlink_msg_ylcx_beichuang_ctrl_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_beichuang_ctrl_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.mode , packet1.speed , packet1.heading , packet1.light , packet1.gps_speed , packet1.compass_heading , packet1.imu_heading , packet1.pid_p , packet1.pid_i , packet1.pid_d , packet1.cmd_1 , packet1.cmd_2 );
    mavlink_msg_ylcx_beichuang_ctrl_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_beichuang_ctrl_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_beichuang_ctrl_send(MAVLINK_COMM_1 , packet1.mode , packet1.speed , packet1.heading , packet1.light , packet1.gps_speed , packet1.compass_heading , packet1.imu_heading , packet1.pid_p , packet1.pid_i , packet1.pid_d , packet1.cmd_1 , packet1.cmd_2 );
    mavlink_msg_ylcx_beichuang_ctrl_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_BEICHUANG_CTRL") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_BEICHUANG_CTRL) != NULL);
#endif
}

static void mavlink_test_ylcx_guokeda_info(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_guokeda_info_t packet_in = {
        17235,17339,17443,17547,17651,17755,17859,17963
    };
    mavlink_ylcx_guokeda_info_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.airPressure = packet_in.airPressure;
        packet1.temperature = packet_in.temperature;
        packet1.humidity = packet_in.humidity;
        packet1.windDirectionR = packet_in.windDirectionR;
        packet1.windDirectionG = packet_in.windDirectionG;
        packet1.windSpeedN = packet_in.windSpeedN;
        packet1.windSpeedM = packet_in.windSpeedM;
        packet1.waterDeep = packet_in.waterDeep;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_guokeda_info_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_guokeda_info_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_guokeda_info_pack(system_id, component_id, &msg , packet1.airPressure , packet1.temperature , packet1.humidity , packet1.windDirectionR , packet1.windDirectionG , packet1.windSpeedN , packet1.windSpeedM , packet1.waterDeep );
    mavlink_msg_ylcx_guokeda_info_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_guokeda_info_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.airPressure , packet1.temperature , packet1.humidity , packet1.windDirectionR , packet1.windDirectionG , packet1.windSpeedN , packet1.windSpeedM , packet1.waterDeep );
    mavlink_msg_ylcx_guokeda_info_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_guokeda_info_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_guokeda_info_send(MAVLINK_COMM_1 , packet1.airPressure , packet1.temperature , packet1.humidity , packet1.windDirectionR , packet1.windDirectionG , packet1.windSpeedN , packet1.windSpeedM , packet1.waterDeep );
    mavlink_msg_ylcx_guokeda_info_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_GUOKEDA_INFO") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_GUOKEDA_INFO) != NULL);
#endif
}

static void mavlink_test_ylcx_l1_info(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_L1_INFO >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_l1_info_t packet_in = {
        17.0,45.0,73.0,101.0
    };
    mavlink_ylcx_l1_info_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.l1_distance = packet_in.l1_distance;
        packet1.target_yaw = packet_in.target_yaw;
        packet1.road_yaw = packet_in.road_yaw;
        packet1.target_acc = packet_in.target_acc;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_L1_INFO_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_L1_INFO_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_l1_info_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_l1_info_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_l1_info_pack(system_id, component_id, &msg , packet1.l1_distance , packet1.target_yaw , packet1.road_yaw , packet1.target_acc );
    mavlink_msg_ylcx_l1_info_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_l1_info_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.l1_distance , packet1.target_yaw , packet1.road_yaw , packet1.target_acc );
    mavlink_msg_ylcx_l1_info_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_l1_info_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_l1_info_send(MAVLINK_COMM_1 , packet1.l1_distance , packet1.target_yaw , packet1.road_yaw , packet1.target_acc );
    mavlink_msg_ylcx_l1_info_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_L1_INFO") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_L1_INFO) != NULL);
#endif
}

static void mavlink_test_ylcx_mpc_control(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_MPC_CONTROL >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_mpc_control_t packet_in = {
        17235,139
    };
    mavlink_ylcx_mpc_control_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.traget_propeller_speed = packet_in.traget_propeller_speed;
        packet1.target_rudder_angle = packet_in.target_rudder_angle;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_MPC_CONTROL_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_mpc_control_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_mpc_control_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_mpc_control_pack(system_id, component_id, &msg , packet1.target_rudder_angle , packet1.traget_propeller_speed );
    mavlink_msg_ylcx_mpc_control_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_mpc_control_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.target_rudder_angle , packet1.traget_propeller_speed );
    mavlink_msg_ylcx_mpc_control_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_mpc_control_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_mpc_control_send(MAVLINK_COMM_1 , packet1.target_rudder_angle , packet1.traget_propeller_speed );
    mavlink_msg_ylcx_mpc_control_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_MPC_CONTROL") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_MPC_CONTROL) != NULL);
#endif
}

static void mavlink_test_ylcx_radar_message(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_radar_message_t packet_in = {
        17.0,17,84
    };
    mavlink_ylcx_radar_message_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.distance = packet_in.distance;
        packet1.index = packet_in.index;
        packet1.emergency = packet_in.emergency;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_radar_message_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_radar_message_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_radar_message_pack(system_id, component_id, &msg , packet1.index , packet1.emergency , packet1.distance );
    mavlink_msg_ylcx_radar_message_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_radar_message_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.index , packet1.emergency , packet1.distance );
    mavlink_msg_ylcx_radar_message_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_radar_message_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_radar_message_send(MAVLINK_COMM_1 , packet1.index , packet1.emergency , packet1.distance );
    mavlink_msg_ylcx_radar_message_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_RADAR_MESSAGE") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_RADAR_MESSAGE) != NULL);
#endif
}

static void mavlink_test_ylcx_rib_ctrl(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_RIB_CTRL >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_rib_ctrl_t packet_in = {
        17.0,45.0,17651,17755,41,108
    };
    mavlink_ylcx_rib_ctrl_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.cmd_1 = packet_in.cmd_1;
        packet1.cmd_2 = packet_in.cmd_2;
        packet1.throttle = packet_in.throttle;
        packet1.direction = packet_in.direction;
        packet1.start_up = packet_in.start_up;
        packet1.trim = packet_in.trim;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_RIB_CTRL_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_RIB_CTRL_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rib_ctrl_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_rib_ctrl_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rib_ctrl_pack(system_id, component_id, &msg , packet1.start_up , packet1.trim , packet1.throttle , packet1.direction , packet1.cmd_1 , packet1.cmd_2 );
    mavlink_msg_ylcx_rib_ctrl_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rib_ctrl_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.start_up , packet1.trim , packet1.throttle , packet1.direction , packet1.cmd_1 , packet1.cmd_2 );
    mavlink_msg_ylcx_rib_ctrl_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_rib_ctrl_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_rib_ctrl_send(MAVLINK_COMM_1 , packet1.start_up , packet1.trim , packet1.throttle , packet1.direction , packet1.cmd_1 , packet1.cmd_2 );
    mavlink_msg_ylcx_rib_ctrl_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_RIB_CTRL") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_RIB_CTRL) != NULL);
#endif
}

static void mavlink_test_ylcx_gun_station(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_GUN_STATION >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_gun_station_t packet_in = {
        17.0,45.0,29,96
    };
    mavlink_ylcx_gun_station_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.x_vel = packet_in.x_vel;
        packet1.y_vel = packet_in.y_vel;
        packet1.x = packet_in.x;
        packet1.y = packet_in.y;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_GUN_STATION_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_GUN_STATION_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_gun_station_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_pack(system_id, component_id, &msg , packet1.x , packet1.y , packet1.x_vel , packet1.y_vel );
    mavlink_msg_ylcx_gun_station_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.x , packet1.y , packet1.x_vel , packet1.y_vel );
    mavlink_msg_ylcx_gun_station_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_gun_station_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_send(MAVLINK_COMM_1 , packet1.x , packet1.y , packet1.x_vel , packet1.y_vel );
    mavlink_msg_ylcx_gun_station_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_GUN_STATION") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_GUN_STATION) != NULL);
#endif
}

static void mavlink_test_ylcx_gun_station_position(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_GUN_STATION_POSITION >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_gun_station_position_t packet_in = {
        17.0,45.0,73.0,101.0
    };
    mavlink_ylcx_gun_station_position_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.x_pos = packet_in.x_pos;
        packet1.y_pos = packet_in.y_pos;
        packet1.x_vel = packet_in.x_vel;
        packet1.y_vel = packet_in.y_vel;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_GUN_STATION_POSITION_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_GUN_STATION_POSITION_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_position_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_gun_station_position_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_position_pack(system_id, component_id, &msg , packet1.x_pos , packet1.y_pos , packet1.x_vel , packet1.y_vel );
    mavlink_msg_ylcx_gun_station_position_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_position_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.x_pos , packet1.y_pos , packet1.x_vel , packet1.y_vel );
    mavlink_msg_ylcx_gun_station_position_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_gun_station_position_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_position_send(MAVLINK_COMM_1 , packet1.x_pos , packet1.y_pos , packet1.x_vel , packet1.y_vel );
    mavlink_msg_ylcx_gun_station_position_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_GUN_STATION_POSITION") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_GUN_STATION_POSITION) != NULL);
#endif
}

static void mavlink_test_ylcx_gun_station_status(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_ylcx_gun_station_status_t packet_in = {
        17.0,45.0,73.0,101.0,129.0,157.0,185.0,213.0
    };
    mavlink_ylcx_gun_station_status_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.x_pos = packet_in.x_pos;
        packet1.y_pos = packet_in.y_pos;
        packet1.x_vel = packet_in.x_vel;
        packet1.y_vel = packet_in.y_vel;
        packet1.x_tor = packet_in.x_tor;
        packet1.y_tor = packet_in.y_tor;
        packet1.temp_mos = packet_in.temp_mos;
        packet1.temp_coil = packet_in.temp_coil;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_status_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_ylcx_gun_station_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_status_pack(system_id, component_id, &msg , packet1.x_pos , packet1.y_pos , packet1.x_vel , packet1.y_vel , packet1.x_tor , packet1.y_tor , packet1.temp_mos , packet1.temp_coil );
    mavlink_msg_ylcx_gun_station_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_status_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.x_pos , packet1.y_pos , packet1.x_vel , packet1.y_vel , packet1.x_tor , packet1.y_tor , packet1.temp_mos , packet1.temp_coil );
    mavlink_msg_ylcx_gun_station_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_ylcx_gun_station_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_ylcx_gun_station_status_send(MAVLINK_COMM_1 , packet1.x_pos , packet1.y_pos , packet1.x_vel , packet1.y_vel , packet1.x_tor , packet1.y_tor , packet1.temp_mos , packet1.temp_coil );
    mavlink_msg_ylcx_gun_station_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

#ifdef MAVLINK_HAVE_GET_MESSAGE_INFO
    MAVLINK_ASSERT(mavlink_get_message_info_by_name("YLCX_GUN_STATION_STATUS") != NULL);
    MAVLINK_ASSERT(mavlink_get_message_info_by_id(MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS) != NULL);
#endif
}

static void mavlink_test_ylcx(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
    mavlink_test_ylcx_vehicle_status(system_id, component_id, last_msg);
    mavlink_test_ylcx_driver_status(system_id, component_id, last_msg);
    mavlink_test_ylcx_battery_status(system_id, component_id, last_msg);
    mavlink_test_ylcx_rc_channels_raw(system_id, component_id, last_msg);
    mavlink_test_ylcx_vehicle_parameter_request(system_id, component_id, last_msg);
    mavlink_test_ylcx_vehicle_parameter(system_id, component_id, last_msg);
    mavlink_test_ylcx_vehicle_parameter_ack(system_id, component_id, last_msg);
    mavlink_test_ylcx_uwb_raw_int(system_id, component_id, last_msg);
    mavlink_test_ylcx_ros_channels_raw(system_id, component_id, last_msg);
    mavlink_test_ylcx_execute_algo(system_id, component_id, last_msg);
    mavlink_test_ylcx_execute_algo_ack(system_id, component_id, last_msg);
    mavlink_test_ylcx_rpm_speed_raw(system_id, component_id, last_msg);
    mavlink_test_ylcx_spider_set_vehicle_ack(system_id, component_id, last_msg);
    mavlink_test_ylcx_spider_set_platform(system_id, component_id, last_msg);
    mavlink_test_ylcx_spider_set_ptz(system_id, component_id, last_msg);
    mavlink_test_ylcx_spider_set_vehicle(system_id, component_id, last_msg);
    mavlink_test_ylcx_spider_battery(system_id, component_id, last_msg);
    mavlink_test_ylcx_spider_set_vehcile_2(system_id, component_id, last_msg);
    mavlink_test_ylcx_beichuang_ctrl(system_id, component_id, last_msg);
    mavlink_test_ylcx_guokeda_info(system_id, component_id, last_msg);
    mavlink_test_ylcx_l1_info(system_id, component_id, last_msg);
    mavlink_test_ylcx_mpc_control(system_id, component_id, last_msg);
    mavlink_test_ylcx_radar_message(system_id, component_id, last_msg);
    mavlink_test_ylcx_rib_ctrl(system_id, component_id, last_msg);
    mavlink_test_ylcx_gun_station(system_id, component_id, last_msg);
    mavlink_test_ylcx_gun_station_position(system_id, component_id, last_msg);
    mavlink_test_ylcx_gun_station_status(system_id, component_id, last_msg);
}

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // YLCX_TESTSUITE_H
