#pragma once
// MESSAGE YLCX_VEHICLE_STATUS PACKING

#define MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS 54301


typedef struct __mavlink_ylcx_vehicle_status_t {
 int32_t temperature; /*<  Temperature of the vehicle. INT16_MAX for unknown temperature.*/
 int8_t water_alarm; /*<  0 is normal. 1 is warning*/
 int8_t urgency_alarm; /*<  0 is normal. 1 is warning*/
} mavlink_ylcx_vehicle_status_t;

#define MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN 6
#define MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN 6
#define MAVLINK_MSG_ID_54301_LEN 6
#define MAVLINK_MSG_ID_54301_MIN_LEN 6

#define MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_CRC 10
#define MAVLINK_MSG_ID_54301_CRC 10



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_VEHICLE_STATUS { \
    54301, \
    "YLCX_VEHICLE_STATUS", \
    3, \
    {  { "water_alarm", NULL, MAVLINK_TYPE_INT8_T, 0, 4, offsetof(mavlink_ylcx_vehicle_status_t, water_alarm) }, \
         { "urgency_alarm", NULL, MAVLINK_TYPE_INT8_T, 0, 5, offsetof(mavlink_ylcx_vehicle_status_t, urgency_alarm) }, \
         { "temperature", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_ylcx_vehicle_status_t, temperature) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_VEHICLE_STATUS { \
    "YLCX_VEHICLE_STATUS", \
    3, \
    {  { "water_alarm", NULL, MAVLINK_TYPE_INT8_T, 0, 4, offsetof(mavlink_ylcx_vehicle_status_t, water_alarm) }, \
         { "urgency_alarm", NULL, MAVLINK_TYPE_INT8_T, 0, 5, offsetof(mavlink_ylcx_vehicle_status_t, urgency_alarm) }, \
         { "temperature", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_ylcx_vehicle_status_t, temperature) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_vehicle_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param water_alarm  0 is normal. 1 is warning
 * @param urgency_alarm  0 is normal. 1 is warning
 * @param temperature  Temperature of the vehicle. INT16_MAX for unknown temperature.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int8_t water_alarm, int8_t urgency_alarm, int32_t temperature)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN];
    _mav_put_int32_t(buf, 0, temperature);
    _mav_put_int8_t(buf, 4, water_alarm);
    _mav_put_int8_t(buf, 5, urgency_alarm);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN);
#else
    mavlink_ylcx_vehicle_status_t packet;
    packet.temperature = temperature;
    packet.water_alarm = water_alarm;
    packet.urgency_alarm = urgency_alarm;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_CRC);
}

/**
 * @brief Pack a ylcx_vehicle_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param water_alarm  0 is normal. 1 is warning
 * @param urgency_alarm  0 is normal. 1 is warning
 * @param temperature  Temperature of the vehicle. INT16_MAX for unknown temperature.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_status_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               int8_t water_alarm, int8_t urgency_alarm, int32_t temperature)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN];
    _mav_put_int32_t(buf, 0, temperature);
    _mav_put_int8_t(buf, 4, water_alarm);
    _mav_put_int8_t(buf, 5, urgency_alarm);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN);
#else
    mavlink_ylcx_vehicle_status_t packet;
    packet.temperature = temperature;
    packet.water_alarm = water_alarm;
    packet.urgency_alarm = urgency_alarm;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN);
#endif
}

/**
 * @brief Pack a ylcx_vehicle_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param water_alarm  0 is normal. 1 is warning
 * @param urgency_alarm  0 is normal. 1 is warning
 * @param temperature  Temperature of the vehicle. INT16_MAX for unknown temperature.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int8_t water_alarm,int8_t urgency_alarm,int32_t temperature)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN];
    _mav_put_int32_t(buf, 0, temperature);
    _mav_put_int8_t(buf, 4, water_alarm);
    _mav_put_int8_t(buf, 5, urgency_alarm);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN);
#else
    mavlink_ylcx_vehicle_status_t packet;
    packet.temperature = temperature;
    packet.water_alarm = water_alarm;
    packet.urgency_alarm = urgency_alarm;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_CRC);
}

/**
 * @brief Encode a ylcx_vehicle_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_vehicle_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_vehicle_status_t* ylcx_vehicle_status)
{
    return mavlink_msg_ylcx_vehicle_status_pack(system_id, component_id, msg, ylcx_vehicle_status->water_alarm, ylcx_vehicle_status->urgency_alarm, ylcx_vehicle_status->temperature);
}

/**
 * @brief Encode a ylcx_vehicle_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_vehicle_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_vehicle_status_t* ylcx_vehicle_status)
{
    return mavlink_msg_ylcx_vehicle_status_pack_chan(system_id, component_id, chan, msg, ylcx_vehicle_status->water_alarm, ylcx_vehicle_status->urgency_alarm, ylcx_vehicle_status->temperature);
}

/**
 * @brief Encode a ylcx_vehicle_status struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_vehicle_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_status_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_vehicle_status_t* ylcx_vehicle_status)
{
    return mavlink_msg_ylcx_vehicle_status_pack_status(system_id, component_id, _status, msg,  ylcx_vehicle_status->water_alarm, ylcx_vehicle_status->urgency_alarm, ylcx_vehicle_status->temperature);
}

/**
 * @brief Send a ylcx_vehicle_status message
 * @param chan MAVLink channel to send the message
 *
 * @param water_alarm  0 is normal. 1 is warning
 * @param urgency_alarm  0 is normal. 1 is warning
 * @param temperature  Temperature of the vehicle. INT16_MAX for unknown temperature.
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_vehicle_status_send(mavlink_channel_t chan, int8_t water_alarm, int8_t urgency_alarm, int32_t temperature)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN];
    _mav_put_int32_t(buf, 0, temperature);
    _mav_put_int8_t(buf, 4, water_alarm);
    _mav_put_int8_t(buf, 5, urgency_alarm);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS, buf, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_CRC);
#else
    mavlink_ylcx_vehicle_status_t packet;
    packet.temperature = temperature;
    packet.water_alarm = water_alarm;
    packet.urgency_alarm = urgency_alarm;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS, (const char *)&packet, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_CRC);
#endif
}

/**
 * @brief Send a ylcx_vehicle_status message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_vehicle_status_send_struct(mavlink_channel_t chan, const mavlink_ylcx_vehicle_status_t* ylcx_vehicle_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_vehicle_status_send(chan, ylcx_vehicle_status->water_alarm, ylcx_vehicle_status->urgency_alarm, ylcx_vehicle_status->temperature);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS, (const char *)ylcx_vehicle_status, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_vehicle_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int8_t water_alarm, int8_t urgency_alarm, int32_t temperature)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int32_t(buf, 0, temperature);
    _mav_put_int8_t(buf, 4, water_alarm);
    _mav_put_int8_t(buf, 5, urgency_alarm);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS, buf, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_CRC);
#else
    mavlink_ylcx_vehicle_status_t *packet = (mavlink_ylcx_vehicle_status_t *)msgbuf;
    packet->temperature = temperature;
    packet->water_alarm = water_alarm;
    packet->urgency_alarm = urgency_alarm;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS, (const char *)packet, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_VEHICLE_STATUS UNPACKING


/**
 * @brief Get field water_alarm from ylcx_vehicle_status message
 *
 * @return  0 is normal. 1 is warning
 */
static inline int8_t mavlink_msg_ylcx_vehicle_status_get_water_alarm(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  4);
}

/**
 * @brief Get field urgency_alarm from ylcx_vehicle_status message
 *
 * @return  0 is normal. 1 is warning
 */
static inline int8_t mavlink_msg_ylcx_vehicle_status_get_urgency_alarm(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  5);
}

/**
 * @brief Get field temperature from ylcx_vehicle_status message
 *
 * @return  Temperature of the vehicle. INT16_MAX for unknown temperature.
 */
static inline int32_t mavlink_msg_ylcx_vehicle_status_get_temperature(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  0);
}

/**
 * @brief Decode a ylcx_vehicle_status message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_vehicle_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_vehicle_status_decode(const mavlink_message_t* msg, mavlink_ylcx_vehicle_status_t* ylcx_vehicle_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_vehicle_status->temperature = mavlink_msg_ylcx_vehicle_status_get_temperature(msg);
    ylcx_vehicle_status->water_alarm = mavlink_msg_ylcx_vehicle_status_get_water_alarm(msg);
    ylcx_vehicle_status->urgency_alarm = mavlink_msg_ylcx_vehicle_status_get_urgency_alarm(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN? msg->len : MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN;
        memset(ylcx_vehicle_status, 0, MAVLINK_MSG_ID_YLCX_VEHICLE_STATUS_LEN);
    memcpy(ylcx_vehicle_status, _MAV_PAYLOAD(msg), len);
#endif
}
