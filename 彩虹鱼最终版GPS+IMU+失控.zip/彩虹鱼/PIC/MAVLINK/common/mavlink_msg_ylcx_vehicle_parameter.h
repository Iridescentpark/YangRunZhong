#pragma once
// MESSAGE YLCX_VEHICLE_PARAMETER PACKING

#define MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER 54310


typedef struct __mavlink_ylcx_vehicle_parameter_t {
 float d_kp; /*<  */
 float d_ki; /*<  */
 float d_kd; /*<  */
 float v_kp; /*<  */
 float v_ki; /*<  */
 float v_kd; /*<  */
 float l1_kp; /*<  */
 float l1_ki; /*<  */
 float l1_kd; /*<  */
 float path_distance; /*<  */
 uint16_t z_over_angle; /*<  Z Action algo over angle range [0, 360]*/
 uint16_t z_rudder_angle; /*<  Z Action rudder angle*/
 uint16_t rotation_rudder_angle; /*<  rotation target rudder angle*/
 uint16_t return_rudder_angle; /*<  return rudder action angle*/
 uint8_t z_direction; /*<  0 is left, 1 is right*/
 uint8_t z_velo; /*<   Z Action target speed*/
 uint8_t z_over_count; /*<  Z Action over angle count.*/
 uint8_t z_rudder_speed; /*<  Z Action rudder speed.*/
 uint8_t rotation_direction; /*<  0 is left, 1 is right.*/
 uint8_t rotation_velo; /*<  rotation target speed. */
 uint8_t rotation_rudder_speed; /*<  rotation target rudder speed*/
 uint8_t urgent_speed; /*<  urgent stop vehicle speed.*/
 uint8_t inertia_speed; /*<  inertia stop vehicle speed.*/
 uint8_t return_rudder_speed; /*<  return rudder action speed*/
 uint8_t return_rudder_direction; /*<  0 is left, 1 is right*/
 uint8_t return_rudder_velo; /*<  return rudder action velo*/
} mavlink_ylcx_vehicle_parameter_t;

#define MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN 60
#define MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN 60
#define MAVLINK_MSG_ID_54310_LEN 60
#define MAVLINK_MSG_ID_54310_MIN_LEN 60

#define MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_CRC 246
#define MAVLINK_MSG_ID_54310_CRC 246



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_VEHICLE_PARAMETER { \
    54310, \
    "YLCX_VEHICLE_PARAMETER", \
    26, \
    {  { "z_over_angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 40, offsetof(mavlink_ylcx_vehicle_parameter_t, z_over_angle) }, \
         { "z_direction", NULL, MAVLINK_TYPE_UINT8_T, 0, 48, offsetof(mavlink_ylcx_vehicle_parameter_t, z_direction) }, \
         { "z_velo", NULL, MAVLINK_TYPE_UINT8_T, 0, 49, offsetof(mavlink_ylcx_vehicle_parameter_t, z_velo) }, \
         { "z_over_count", NULL, MAVLINK_TYPE_UINT8_T, 0, 50, offsetof(mavlink_ylcx_vehicle_parameter_t, z_over_count) }, \
         { "z_rudder_speed", NULL, MAVLINK_TYPE_UINT8_T, 0, 51, offsetof(mavlink_ylcx_vehicle_parameter_t, z_rudder_speed) }, \
         { "z_rudder_angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 42, offsetof(mavlink_ylcx_vehicle_parameter_t, z_rudder_angle) }, \
         { "rotation_direction", NULL, MAVLINK_TYPE_UINT8_T, 0, 52, offsetof(mavlink_ylcx_vehicle_parameter_t, rotation_direction) }, \
         { "rotation_velo", NULL, MAVLINK_TYPE_UINT8_T, 0, 53, offsetof(mavlink_ylcx_vehicle_parameter_t, rotation_velo) }, \
         { "rotation_rudder_angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 44, offsetof(mavlink_ylcx_vehicle_parameter_t, rotation_rudder_angle) }, \
         { "rotation_rudder_speed", NULL, MAVLINK_TYPE_UINT8_T, 0, 54, offsetof(mavlink_ylcx_vehicle_parameter_t, rotation_rudder_speed) }, \
         { "urgent_speed", NULL, MAVLINK_TYPE_UINT8_T, 0, 55, offsetof(mavlink_ylcx_vehicle_parameter_t, urgent_speed) }, \
         { "inertia_speed", NULL, MAVLINK_TYPE_UINT8_T, 0, 56, offsetof(mavlink_ylcx_vehicle_parameter_t, inertia_speed) }, \
         { "return_rudder_speed", NULL, MAVLINK_TYPE_UINT8_T, 0, 57, offsetof(mavlink_ylcx_vehicle_parameter_t, return_rudder_speed) }, \
         { "return_rudder_angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 46, offsetof(mavlink_ylcx_vehicle_parameter_t, return_rudder_angle) }, \
         { "return_rudder_direction", NULL, MAVLINK_TYPE_UINT8_T, 0, 58, offsetof(mavlink_ylcx_vehicle_parameter_t, return_rudder_direction) }, \
         { "return_rudder_velo", NULL, MAVLINK_TYPE_UINT8_T, 0, 59, offsetof(mavlink_ylcx_vehicle_parameter_t, return_rudder_velo) }, \
         { "d_kp", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ylcx_vehicle_parameter_t, d_kp) }, \
         { "d_ki", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_ylcx_vehicle_parameter_t, d_ki) }, \
         { "d_kd", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ylcx_vehicle_parameter_t, d_kd) }, \
         { "v_kp", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ylcx_vehicle_parameter_t, v_kp) }, \
         { "v_ki", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_ylcx_vehicle_parameter_t, v_ki) }, \
         { "v_kd", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_ylcx_vehicle_parameter_t, v_kd) }, \
         { "l1_kp", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_ylcx_vehicle_parameter_t, l1_kp) }, \
         { "l1_ki", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_ylcx_vehicle_parameter_t, l1_ki) }, \
         { "l1_kd", NULL, MAVLINK_TYPE_FLOAT, 0, 32, offsetof(mavlink_ylcx_vehicle_parameter_t, l1_kd) }, \
         { "path_distance", NULL, MAVLINK_TYPE_FLOAT, 0, 36, offsetof(mavlink_ylcx_vehicle_parameter_t, path_distance) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_VEHICLE_PARAMETER { \
    "YLCX_VEHICLE_PARAMETER", \
    26, \
    {  { "z_over_angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 40, offsetof(mavlink_ylcx_vehicle_parameter_t, z_over_angle) }, \
         { "z_direction", NULL, MAVLINK_TYPE_UINT8_T, 0, 48, offsetof(mavlink_ylcx_vehicle_parameter_t, z_direction) }, \
         { "z_velo", NULL, MAVLINK_TYPE_UINT8_T, 0, 49, offsetof(mavlink_ylcx_vehicle_parameter_t, z_velo) }, \
         { "z_over_count", NULL, MAVLINK_TYPE_UINT8_T, 0, 50, offsetof(mavlink_ylcx_vehicle_parameter_t, z_over_count) }, \
         { "z_rudder_speed", NULL, MAVLINK_TYPE_UINT8_T, 0, 51, offsetof(mavlink_ylcx_vehicle_parameter_t, z_rudder_speed) }, \
         { "z_rudder_angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 42, offsetof(mavlink_ylcx_vehicle_parameter_t, z_rudder_angle) }, \
         { "rotation_direction", NULL, MAVLINK_TYPE_UINT8_T, 0, 52, offsetof(mavlink_ylcx_vehicle_parameter_t, rotation_direction) }, \
         { "rotation_velo", NULL, MAVLINK_TYPE_UINT8_T, 0, 53, offsetof(mavlink_ylcx_vehicle_parameter_t, rotation_velo) }, \
         { "rotation_rudder_angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 44, offsetof(mavlink_ylcx_vehicle_parameter_t, rotation_rudder_angle) }, \
         { "rotation_rudder_speed", NULL, MAVLINK_TYPE_UINT8_T, 0, 54, offsetof(mavlink_ylcx_vehicle_parameter_t, rotation_rudder_speed) }, \
         { "urgent_speed", NULL, MAVLINK_TYPE_UINT8_T, 0, 55, offsetof(mavlink_ylcx_vehicle_parameter_t, urgent_speed) }, \
         { "inertia_speed", NULL, MAVLINK_TYPE_UINT8_T, 0, 56, offsetof(mavlink_ylcx_vehicle_parameter_t, inertia_speed) }, \
         { "return_rudder_speed", NULL, MAVLINK_TYPE_UINT8_T, 0, 57, offsetof(mavlink_ylcx_vehicle_parameter_t, return_rudder_speed) }, \
         { "return_rudder_angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 46, offsetof(mavlink_ylcx_vehicle_parameter_t, return_rudder_angle) }, \
         { "return_rudder_direction", NULL, MAVLINK_TYPE_UINT8_T, 0, 58, offsetof(mavlink_ylcx_vehicle_parameter_t, return_rudder_direction) }, \
         { "return_rudder_velo", NULL, MAVLINK_TYPE_UINT8_T, 0, 59, offsetof(mavlink_ylcx_vehicle_parameter_t, return_rudder_velo) }, \
         { "d_kp", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ylcx_vehicle_parameter_t, d_kp) }, \
         { "d_ki", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_ylcx_vehicle_parameter_t, d_ki) }, \
         { "d_kd", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ylcx_vehicle_parameter_t, d_kd) }, \
         { "v_kp", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ylcx_vehicle_parameter_t, v_kp) }, \
         { "v_ki", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_ylcx_vehicle_parameter_t, v_ki) }, \
         { "v_kd", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_ylcx_vehicle_parameter_t, v_kd) }, \
         { "l1_kp", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_ylcx_vehicle_parameter_t, l1_kp) }, \
         { "l1_ki", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_ylcx_vehicle_parameter_t, l1_ki) }, \
         { "l1_kd", NULL, MAVLINK_TYPE_FLOAT, 0, 32, offsetof(mavlink_ylcx_vehicle_parameter_t, l1_kd) }, \
         { "path_distance", NULL, MAVLINK_TYPE_FLOAT, 0, 36, offsetof(mavlink_ylcx_vehicle_parameter_t, path_distance) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_vehicle_parameter message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param z_over_angle  Z Action algo over angle range [0, 360]
 * @param z_direction  0 is left, 1 is right
 * @param z_velo   Z Action target speed
 * @param z_over_count  Z Action over angle count.
 * @param z_rudder_speed  Z Action rudder speed.
 * @param z_rudder_angle  Z Action rudder angle
 * @param rotation_direction  0 is left, 1 is right.
 * @param rotation_velo  rotation target speed. 
 * @param rotation_rudder_angle  rotation target rudder angle
 * @param rotation_rudder_speed  rotation target rudder speed
 * @param urgent_speed  urgent stop vehicle speed.
 * @param inertia_speed  inertia stop vehicle speed.
 * @param return_rudder_speed  return rudder action speed
 * @param return_rudder_angle  return rudder action angle
 * @param return_rudder_direction  0 is left, 1 is right
 * @param return_rudder_velo  return rudder action velo
 * @param d_kp  
 * @param d_ki  
 * @param d_kd  
 * @param v_kp  
 * @param v_ki  
 * @param v_kd  
 * @param l1_kp  
 * @param l1_ki  
 * @param l1_kd  
 * @param path_distance  
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_parameter_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint16_t z_over_angle, uint8_t z_direction, uint8_t z_velo, uint8_t z_over_count, uint8_t z_rudder_speed, uint16_t z_rudder_angle, uint8_t rotation_direction, uint8_t rotation_velo, uint16_t rotation_rudder_angle, uint8_t rotation_rudder_speed, uint8_t urgent_speed, uint8_t inertia_speed, uint8_t return_rudder_speed, uint16_t return_rudder_angle, uint8_t return_rudder_direction, uint8_t return_rudder_velo, float d_kp, float d_ki, float d_kd, float v_kp, float v_ki, float v_kd, float l1_kp, float l1_ki, float l1_kd, float path_distance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN];
    _mav_put_float(buf, 0, d_kp);
    _mav_put_float(buf, 4, d_ki);
    _mav_put_float(buf, 8, d_kd);
    _mav_put_float(buf, 12, v_kp);
    _mav_put_float(buf, 16, v_ki);
    _mav_put_float(buf, 20, v_kd);
    _mav_put_float(buf, 24, l1_kp);
    _mav_put_float(buf, 28, l1_ki);
    _mav_put_float(buf, 32, l1_kd);
    _mav_put_float(buf, 36, path_distance);
    _mav_put_uint16_t(buf, 40, z_over_angle);
    _mav_put_uint16_t(buf, 42, z_rudder_angle);
    _mav_put_uint16_t(buf, 44, rotation_rudder_angle);
    _mav_put_uint16_t(buf, 46, return_rudder_angle);
    _mav_put_uint8_t(buf, 48, z_direction);
    _mav_put_uint8_t(buf, 49, z_velo);
    _mav_put_uint8_t(buf, 50, z_over_count);
    _mav_put_uint8_t(buf, 51, z_rudder_speed);
    _mav_put_uint8_t(buf, 52, rotation_direction);
    _mav_put_uint8_t(buf, 53, rotation_velo);
    _mav_put_uint8_t(buf, 54, rotation_rudder_speed);
    _mav_put_uint8_t(buf, 55, urgent_speed);
    _mav_put_uint8_t(buf, 56, inertia_speed);
    _mav_put_uint8_t(buf, 57, return_rudder_speed);
    _mav_put_uint8_t(buf, 58, return_rudder_direction);
    _mav_put_uint8_t(buf, 59, return_rudder_velo);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN);
#else
    mavlink_ylcx_vehicle_parameter_t packet;
    packet.d_kp = d_kp;
    packet.d_ki = d_ki;
    packet.d_kd = d_kd;
    packet.v_kp = v_kp;
    packet.v_ki = v_ki;
    packet.v_kd = v_kd;
    packet.l1_kp = l1_kp;
    packet.l1_ki = l1_ki;
    packet.l1_kd = l1_kd;
    packet.path_distance = path_distance;
    packet.z_over_angle = z_over_angle;
    packet.z_rudder_angle = z_rudder_angle;
    packet.rotation_rudder_angle = rotation_rudder_angle;
    packet.return_rudder_angle = return_rudder_angle;
    packet.z_direction = z_direction;
    packet.z_velo = z_velo;
    packet.z_over_count = z_over_count;
    packet.z_rudder_speed = z_rudder_speed;
    packet.rotation_direction = rotation_direction;
    packet.rotation_velo = rotation_velo;
    packet.rotation_rudder_speed = rotation_rudder_speed;
    packet.urgent_speed = urgent_speed;
    packet.inertia_speed = inertia_speed;
    packet.return_rudder_speed = return_rudder_speed;
    packet.return_rudder_direction = return_rudder_direction;
    packet.return_rudder_velo = return_rudder_velo;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_CRC);
}

/**
 * @brief Pack a ylcx_vehicle_parameter message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param z_over_angle  Z Action algo over angle range [0, 360]
 * @param z_direction  0 is left, 1 is right
 * @param z_velo   Z Action target speed
 * @param z_over_count  Z Action over angle count.
 * @param z_rudder_speed  Z Action rudder speed.
 * @param z_rudder_angle  Z Action rudder angle
 * @param rotation_direction  0 is left, 1 is right.
 * @param rotation_velo  rotation target speed. 
 * @param rotation_rudder_angle  rotation target rudder angle
 * @param rotation_rudder_speed  rotation target rudder speed
 * @param urgent_speed  urgent stop vehicle speed.
 * @param inertia_speed  inertia stop vehicle speed.
 * @param return_rudder_speed  return rudder action speed
 * @param return_rudder_angle  return rudder action angle
 * @param return_rudder_direction  0 is left, 1 is right
 * @param return_rudder_velo  return rudder action velo
 * @param d_kp  
 * @param d_ki  
 * @param d_kd  
 * @param v_kp  
 * @param v_ki  
 * @param v_kd  
 * @param l1_kp  
 * @param l1_ki  
 * @param l1_kd  
 * @param path_distance  
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_parameter_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint16_t z_over_angle, uint8_t z_direction, uint8_t z_velo, uint8_t z_over_count, uint8_t z_rudder_speed, uint16_t z_rudder_angle, uint8_t rotation_direction, uint8_t rotation_velo, uint16_t rotation_rudder_angle, uint8_t rotation_rudder_speed, uint8_t urgent_speed, uint8_t inertia_speed, uint8_t return_rudder_speed, uint16_t return_rudder_angle, uint8_t return_rudder_direction, uint8_t return_rudder_velo, float d_kp, float d_ki, float d_kd, float v_kp, float v_ki, float v_kd, float l1_kp, float l1_ki, float l1_kd, float path_distance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN];
    _mav_put_float(buf, 0, d_kp);
    _mav_put_float(buf, 4, d_ki);
    _mav_put_float(buf, 8, d_kd);
    _mav_put_float(buf, 12, v_kp);
    _mav_put_float(buf, 16, v_ki);
    _mav_put_float(buf, 20, v_kd);
    _mav_put_float(buf, 24, l1_kp);
    _mav_put_float(buf, 28, l1_ki);
    _mav_put_float(buf, 32, l1_kd);
    _mav_put_float(buf, 36, path_distance);
    _mav_put_uint16_t(buf, 40, z_over_angle);
    _mav_put_uint16_t(buf, 42, z_rudder_angle);
    _mav_put_uint16_t(buf, 44, rotation_rudder_angle);
    _mav_put_uint16_t(buf, 46, return_rudder_angle);
    _mav_put_uint8_t(buf, 48, z_direction);
    _mav_put_uint8_t(buf, 49, z_velo);
    _mav_put_uint8_t(buf, 50, z_over_count);
    _mav_put_uint8_t(buf, 51, z_rudder_speed);
    _mav_put_uint8_t(buf, 52, rotation_direction);
    _mav_put_uint8_t(buf, 53, rotation_velo);
    _mav_put_uint8_t(buf, 54, rotation_rudder_speed);
    _mav_put_uint8_t(buf, 55, urgent_speed);
    _mav_put_uint8_t(buf, 56, inertia_speed);
    _mav_put_uint8_t(buf, 57, return_rudder_speed);
    _mav_put_uint8_t(buf, 58, return_rudder_direction);
    _mav_put_uint8_t(buf, 59, return_rudder_velo);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN);
#else
    mavlink_ylcx_vehicle_parameter_t packet;
    packet.d_kp = d_kp;
    packet.d_ki = d_ki;
    packet.d_kd = d_kd;
    packet.v_kp = v_kp;
    packet.v_ki = v_ki;
    packet.v_kd = v_kd;
    packet.l1_kp = l1_kp;
    packet.l1_ki = l1_ki;
    packet.l1_kd = l1_kd;
    packet.path_distance = path_distance;
    packet.z_over_angle = z_over_angle;
    packet.z_rudder_angle = z_rudder_angle;
    packet.rotation_rudder_angle = rotation_rudder_angle;
    packet.return_rudder_angle = return_rudder_angle;
    packet.z_direction = z_direction;
    packet.z_velo = z_velo;
    packet.z_over_count = z_over_count;
    packet.z_rudder_speed = z_rudder_speed;
    packet.rotation_direction = rotation_direction;
    packet.rotation_velo = rotation_velo;
    packet.rotation_rudder_speed = rotation_rudder_speed;
    packet.urgent_speed = urgent_speed;
    packet.inertia_speed = inertia_speed;
    packet.return_rudder_speed = return_rudder_speed;
    packet.return_rudder_direction = return_rudder_direction;
    packet.return_rudder_velo = return_rudder_velo;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN);
#endif
}

/**
 * @brief Pack a ylcx_vehicle_parameter message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param z_over_angle  Z Action algo over angle range [0, 360]
 * @param z_direction  0 is left, 1 is right
 * @param z_velo   Z Action target speed
 * @param z_over_count  Z Action over angle count.
 * @param z_rudder_speed  Z Action rudder speed.
 * @param z_rudder_angle  Z Action rudder angle
 * @param rotation_direction  0 is left, 1 is right.
 * @param rotation_velo  rotation target speed. 
 * @param rotation_rudder_angle  rotation target rudder angle
 * @param rotation_rudder_speed  rotation target rudder speed
 * @param urgent_speed  urgent stop vehicle speed.
 * @param inertia_speed  inertia stop vehicle speed.
 * @param return_rudder_speed  return rudder action speed
 * @param return_rudder_angle  return rudder action angle
 * @param return_rudder_direction  0 is left, 1 is right
 * @param return_rudder_velo  return rudder action velo
 * @param d_kp  
 * @param d_ki  
 * @param d_kd  
 * @param v_kp  
 * @param v_ki  
 * @param v_kd  
 * @param l1_kp  
 * @param l1_ki  
 * @param l1_kd  
 * @param path_distance  
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_parameter_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint16_t z_over_angle,uint8_t z_direction,uint8_t z_velo,uint8_t z_over_count,uint8_t z_rudder_speed,uint16_t z_rudder_angle,uint8_t rotation_direction,uint8_t rotation_velo,uint16_t rotation_rudder_angle,uint8_t rotation_rudder_speed,uint8_t urgent_speed,uint8_t inertia_speed,uint8_t return_rudder_speed,uint16_t return_rudder_angle,uint8_t return_rudder_direction,uint8_t return_rudder_velo,float d_kp,float d_ki,float d_kd,float v_kp,float v_ki,float v_kd,float l1_kp,float l1_ki,float l1_kd,float path_distance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN];
    _mav_put_float(buf, 0, d_kp);
    _mav_put_float(buf, 4, d_ki);
    _mav_put_float(buf, 8, d_kd);
    _mav_put_float(buf, 12, v_kp);
    _mav_put_float(buf, 16, v_ki);
    _mav_put_float(buf, 20, v_kd);
    _mav_put_float(buf, 24, l1_kp);
    _mav_put_float(buf, 28, l1_ki);
    _mav_put_float(buf, 32, l1_kd);
    _mav_put_float(buf, 36, path_distance);
    _mav_put_uint16_t(buf, 40, z_over_angle);
    _mav_put_uint16_t(buf, 42, z_rudder_angle);
    _mav_put_uint16_t(buf, 44, rotation_rudder_angle);
    _mav_put_uint16_t(buf, 46, return_rudder_angle);
    _mav_put_uint8_t(buf, 48, z_direction);
    _mav_put_uint8_t(buf, 49, z_velo);
    _mav_put_uint8_t(buf, 50, z_over_count);
    _mav_put_uint8_t(buf, 51, z_rudder_speed);
    _mav_put_uint8_t(buf, 52, rotation_direction);
    _mav_put_uint8_t(buf, 53, rotation_velo);
    _mav_put_uint8_t(buf, 54, rotation_rudder_speed);
    _mav_put_uint8_t(buf, 55, urgent_speed);
    _mav_put_uint8_t(buf, 56, inertia_speed);
    _mav_put_uint8_t(buf, 57, return_rudder_speed);
    _mav_put_uint8_t(buf, 58, return_rudder_direction);
    _mav_put_uint8_t(buf, 59, return_rudder_velo);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN);
#else
    mavlink_ylcx_vehicle_parameter_t packet;
    packet.d_kp = d_kp;
    packet.d_ki = d_ki;
    packet.d_kd = d_kd;
    packet.v_kp = v_kp;
    packet.v_ki = v_ki;
    packet.v_kd = v_kd;
    packet.l1_kp = l1_kp;
    packet.l1_ki = l1_ki;
    packet.l1_kd = l1_kd;
    packet.path_distance = path_distance;
    packet.z_over_angle = z_over_angle;
    packet.z_rudder_angle = z_rudder_angle;
    packet.rotation_rudder_angle = rotation_rudder_angle;
    packet.return_rudder_angle = return_rudder_angle;
    packet.z_direction = z_direction;
    packet.z_velo = z_velo;
    packet.z_over_count = z_over_count;
    packet.z_rudder_speed = z_rudder_speed;
    packet.rotation_direction = rotation_direction;
    packet.rotation_velo = rotation_velo;
    packet.rotation_rudder_speed = rotation_rudder_speed;
    packet.urgent_speed = urgent_speed;
    packet.inertia_speed = inertia_speed;
    packet.return_rudder_speed = return_rudder_speed;
    packet.return_rudder_direction = return_rudder_direction;
    packet.return_rudder_velo = return_rudder_velo;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_CRC);
}

/**
 * @brief Encode a ylcx_vehicle_parameter struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_vehicle_parameter C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_parameter_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_vehicle_parameter_t* ylcx_vehicle_parameter)
{
    return mavlink_msg_ylcx_vehicle_parameter_pack(system_id, component_id, msg, ylcx_vehicle_parameter->z_over_angle, ylcx_vehicle_parameter->z_direction, ylcx_vehicle_parameter->z_velo, ylcx_vehicle_parameter->z_over_count, ylcx_vehicle_parameter->z_rudder_speed, ylcx_vehicle_parameter->z_rudder_angle, ylcx_vehicle_parameter->rotation_direction, ylcx_vehicle_parameter->rotation_velo, ylcx_vehicle_parameter->rotation_rudder_angle, ylcx_vehicle_parameter->rotation_rudder_speed, ylcx_vehicle_parameter->urgent_speed, ylcx_vehicle_parameter->inertia_speed, ylcx_vehicle_parameter->return_rudder_speed, ylcx_vehicle_parameter->return_rudder_angle, ylcx_vehicle_parameter->return_rudder_direction, ylcx_vehicle_parameter->return_rudder_velo, ylcx_vehicle_parameter->d_kp, ylcx_vehicle_parameter->d_ki, ylcx_vehicle_parameter->d_kd, ylcx_vehicle_parameter->v_kp, ylcx_vehicle_parameter->v_ki, ylcx_vehicle_parameter->v_kd, ylcx_vehicle_parameter->l1_kp, ylcx_vehicle_parameter->l1_ki, ylcx_vehicle_parameter->l1_kd, ylcx_vehicle_parameter->path_distance);
}

/**
 * @brief Encode a ylcx_vehicle_parameter struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_vehicle_parameter C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_parameter_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_vehicle_parameter_t* ylcx_vehicle_parameter)
{
    return mavlink_msg_ylcx_vehicle_parameter_pack_chan(system_id, component_id, chan, msg, ylcx_vehicle_parameter->z_over_angle, ylcx_vehicle_parameter->z_direction, ylcx_vehicle_parameter->z_velo, ylcx_vehicle_parameter->z_over_count, ylcx_vehicle_parameter->z_rudder_speed, ylcx_vehicle_parameter->z_rudder_angle, ylcx_vehicle_parameter->rotation_direction, ylcx_vehicle_parameter->rotation_velo, ylcx_vehicle_parameter->rotation_rudder_angle, ylcx_vehicle_parameter->rotation_rudder_speed, ylcx_vehicle_parameter->urgent_speed, ylcx_vehicle_parameter->inertia_speed, ylcx_vehicle_parameter->return_rudder_speed, ylcx_vehicle_parameter->return_rudder_angle, ylcx_vehicle_parameter->return_rudder_direction, ylcx_vehicle_parameter->return_rudder_velo, ylcx_vehicle_parameter->d_kp, ylcx_vehicle_parameter->d_ki, ylcx_vehicle_parameter->d_kd, ylcx_vehicle_parameter->v_kp, ylcx_vehicle_parameter->v_ki, ylcx_vehicle_parameter->v_kd, ylcx_vehicle_parameter->l1_kp, ylcx_vehicle_parameter->l1_ki, ylcx_vehicle_parameter->l1_kd, ylcx_vehicle_parameter->path_distance);
}

/**
 * @brief Encode a ylcx_vehicle_parameter struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_vehicle_parameter C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_parameter_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_vehicle_parameter_t* ylcx_vehicle_parameter)
{
    return mavlink_msg_ylcx_vehicle_parameter_pack_status(system_id, component_id, _status, msg,  ylcx_vehicle_parameter->z_over_angle, ylcx_vehicle_parameter->z_direction, ylcx_vehicle_parameter->z_velo, ylcx_vehicle_parameter->z_over_count, ylcx_vehicle_parameter->z_rudder_speed, ylcx_vehicle_parameter->z_rudder_angle, ylcx_vehicle_parameter->rotation_direction, ylcx_vehicle_parameter->rotation_velo, ylcx_vehicle_parameter->rotation_rudder_angle, ylcx_vehicle_parameter->rotation_rudder_speed, ylcx_vehicle_parameter->urgent_speed, ylcx_vehicle_parameter->inertia_speed, ylcx_vehicle_parameter->return_rudder_speed, ylcx_vehicle_parameter->return_rudder_angle, ylcx_vehicle_parameter->return_rudder_direction, ylcx_vehicle_parameter->return_rudder_velo, ylcx_vehicle_parameter->d_kp, ylcx_vehicle_parameter->d_ki, ylcx_vehicle_parameter->d_kd, ylcx_vehicle_parameter->v_kp, ylcx_vehicle_parameter->v_ki, ylcx_vehicle_parameter->v_kd, ylcx_vehicle_parameter->l1_kp, ylcx_vehicle_parameter->l1_ki, ylcx_vehicle_parameter->l1_kd, ylcx_vehicle_parameter->path_distance);
}

/**
 * @brief Send a ylcx_vehicle_parameter message
 * @param chan MAVLink channel to send the message
 *
 * @param z_over_angle  Z Action algo over angle range [0, 360]
 * @param z_direction  0 is left, 1 is right
 * @param z_velo   Z Action target speed
 * @param z_over_count  Z Action over angle count.
 * @param z_rudder_speed  Z Action rudder speed.
 * @param z_rudder_angle  Z Action rudder angle
 * @param rotation_direction  0 is left, 1 is right.
 * @param rotation_velo  rotation target speed. 
 * @param rotation_rudder_angle  rotation target rudder angle
 * @param rotation_rudder_speed  rotation target rudder speed
 * @param urgent_speed  urgent stop vehicle speed.
 * @param inertia_speed  inertia stop vehicle speed.
 * @param return_rudder_speed  return rudder action speed
 * @param return_rudder_angle  return rudder action angle
 * @param return_rudder_direction  0 is left, 1 is right
 * @param return_rudder_velo  return rudder action velo
 * @param d_kp  
 * @param d_ki  
 * @param d_kd  
 * @param v_kp  
 * @param v_ki  
 * @param v_kd  
 * @param l1_kp  
 * @param l1_ki  
 * @param l1_kd  
 * @param path_distance  
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_vehicle_parameter_send(mavlink_channel_t chan, uint16_t z_over_angle, uint8_t z_direction, uint8_t z_velo, uint8_t z_over_count, uint8_t z_rudder_speed, uint16_t z_rudder_angle, uint8_t rotation_direction, uint8_t rotation_velo, uint16_t rotation_rudder_angle, uint8_t rotation_rudder_speed, uint8_t urgent_speed, uint8_t inertia_speed, uint8_t return_rudder_speed, uint16_t return_rudder_angle, uint8_t return_rudder_direction, uint8_t return_rudder_velo, float d_kp, float d_ki, float d_kd, float v_kp, float v_ki, float v_kd, float l1_kp, float l1_ki, float l1_kd, float path_distance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN];
    _mav_put_float(buf, 0, d_kp);
    _mav_put_float(buf, 4, d_ki);
    _mav_put_float(buf, 8, d_kd);
    _mav_put_float(buf, 12, v_kp);
    _mav_put_float(buf, 16, v_ki);
    _mav_put_float(buf, 20, v_kd);
    _mav_put_float(buf, 24, l1_kp);
    _mav_put_float(buf, 28, l1_ki);
    _mav_put_float(buf, 32, l1_kd);
    _mav_put_float(buf, 36, path_distance);
    _mav_put_uint16_t(buf, 40, z_over_angle);
    _mav_put_uint16_t(buf, 42, z_rudder_angle);
    _mav_put_uint16_t(buf, 44, rotation_rudder_angle);
    _mav_put_uint16_t(buf, 46, return_rudder_angle);
    _mav_put_uint8_t(buf, 48, z_direction);
    _mav_put_uint8_t(buf, 49, z_velo);
    _mav_put_uint8_t(buf, 50, z_over_count);
    _mav_put_uint8_t(buf, 51, z_rudder_speed);
    _mav_put_uint8_t(buf, 52, rotation_direction);
    _mav_put_uint8_t(buf, 53, rotation_velo);
    _mav_put_uint8_t(buf, 54, rotation_rudder_speed);
    _mav_put_uint8_t(buf, 55, urgent_speed);
    _mav_put_uint8_t(buf, 56, inertia_speed);
    _mav_put_uint8_t(buf, 57, return_rudder_speed);
    _mav_put_uint8_t(buf, 58, return_rudder_direction);
    _mav_put_uint8_t(buf, 59, return_rudder_velo);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER, buf, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_CRC);
#else
    mavlink_ylcx_vehicle_parameter_t packet;
    packet.d_kp = d_kp;
    packet.d_ki = d_ki;
    packet.d_kd = d_kd;
    packet.v_kp = v_kp;
    packet.v_ki = v_ki;
    packet.v_kd = v_kd;
    packet.l1_kp = l1_kp;
    packet.l1_ki = l1_ki;
    packet.l1_kd = l1_kd;
    packet.path_distance = path_distance;
    packet.z_over_angle = z_over_angle;
    packet.z_rudder_angle = z_rudder_angle;
    packet.rotation_rudder_angle = rotation_rudder_angle;
    packet.return_rudder_angle = return_rudder_angle;
    packet.z_direction = z_direction;
    packet.z_velo = z_velo;
    packet.z_over_count = z_over_count;
    packet.z_rudder_speed = z_rudder_speed;
    packet.rotation_direction = rotation_direction;
    packet.rotation_velo = rotation_velo;
    packet.rotation_rudder_speed = rotation_rudder_speed;
    packet.urgent_speed = urgent_speed;
    packet.inertia_speed = inertia_speed;
    packet.return_rudder_speed = return_rudder_speed;
    packet.return_rudder_direction = return_rudder_direction;
    packet.return_rudder_velo = return_rudder_velo;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER, (const char *)&packet, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_CRC);
#endif
}

/**
 * @brief Send a ylcx_vehicle_parameter message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_vehicle_parameter_send_struct(mavlink_channel_t chan, const mavlink_ylcx_vehicle_parameter_t* ylcx_vehicle_parameter)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_vehicle_parameter_send(chan, ylcx_vehicle_parameter->z_over_angle, ylcx_vehicle_parameter->z_direction, ylcx_vehicle_parameter->z_velo, ylcx_vehicle_parameter->z_over_count, ylcx_vehicle_parameter->z_rudder_speed, ylcx_vehicle_parameter->z_rudder_angle, ylcx_vehicle_parameter->rotation_direction, ylcx_vehicle_parameter->rotation_velo, ylcx_vehicle_parameter->rotation_rudder_angle, ylcx_vehicle_parameter->rotation_rudder_speed, ylcx_vehicle_parameter->urgent_speed, ylcx_vehicle_parameter->inertia_speed, ylcx_vehicle_parameter->return_rudder_speed, ylcx_vehicle_parameter->return_rudder_angle, ylcx_vehicle_parameter->return_rudder_direction, ylcx_vehicle_parameter->return_rudder_velo, ylcx_vehicle_parameter->d_kp, ylcx_vehicle_parameter->d_ki, ylcx_vehicle_parameter->d_kd, ylcx_vehicle_parameter->v_kp, ylcx_vehicle_parameter->v_ki, ylcx_vehicle_parameter->v_kd, ylcx_vehicle_parameter->l1_kp, ylcx_vehicle_parameter->l1_ki, ylcx_vehicle_parameter->l1_kd, ylcx_vehicle_parameter->path_distance);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER, (const char *)ylcx_vehicle_parameter, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_vehicle_parameter_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint16_t z_over_angle, uint8_t z_direction, uint8_t z_velo, uint8_t z_over_count, uint8_t z_rudder_speed, uint16_t z_rudder_angle, uint8_t rotation_direction, uint8_t rotation_velo, uint16_t rotation_rudder_angle, uint8_t rotation_rudder_speed, uint8_t urgent_speed, uint8_t inertia_speed, uint8_t return_rudder_speed, uint16_t return_rudder_angle, uint8_t return_rudder_direction, uint8_t return_rudder_velo, float d_kp, float d_ki, float d_kd, float v_kp, float v_ki, float v_kd, float l1_kp, float l1_ki, float l1_kd, float path_distance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_float(buf, 0, d_kp);
    _mav_put_float(buf, 4, d_ki);
    _mav_put_float(buf, 8, d_kd);
    _mav_put_float(buf, 12, v_kp);
    _mav_put_float(buf, 16, v_ki);
    _mav_put_float(buf, 20, v_kd);
    _mav_put_float(buf, 24, l1_kp);
    _mav_put_float(buf, 28, l1_ki);
    _mav_put_float(buf, 32, l1_kd);
    _mav_put_float(buf, 36, path_distance);
    _mav_put_uint16_t(buf, 40, z_over_angle);
    _mav_put_uint16_t(buf, 42, z_rudder_angle);
    _mav_put_uint16_t(buf, 44, rotation_rudder_angle);
    _mav_put_uint16_t(buf, 46, return_rudder_angle);
    _mav_put_uint8_t(buf, 48, z_direction);
    _mav_put_uint8_t(buf, 49, z_velo);
    _mav_put_uint8_t(buf, 50, z_over_count);
    _mav_put_uint8_t(buf, 51, z_rudder_speed);
    _mav_put_uint8_t(buf, 52, rotation_direction);
    _mav_put_uint8_t(buf, 53, rotation_velo);
    _mav_put_uint8_t(buf, 54, rotation_rudder_speed);
    _mav_put_uint8_t(buf, 55, urgent_speed);
    _mav_put_uint8_t(buf, 56, inertia_speed);
    _mav_put_uint8_t(buf, 57, return_rudder_speed);
    _mav_put_uint8_t(buf, 58, return_rudder_direction);
    _mav_put_uint8_t(buf, 59, return_rudder_velo);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER, buf, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_CRC);
#else
    mavlink_ylcx_vehicle_parameter_t *packet = (mavlink_ylcx_vehicle_parameter_t *)msgbuf;
    packet->d_kp = d_kp;
    packet->d_ki = d_ki;
    packet->d_kd = d_kd;
    packet->v_kp = v_kp;
    packet->v_ki = v_ki;
    packet->v_kd = v_kd;
    packet->l1_kp = l1_kp;
    packet->l1_ki = l1_ki;
    packet->l1_kd = l1_kd;
    packet->path_distance = path_distance;
    packet->z_over_angle = z_over_angle;
    packet->z_rudder_angle = z_rudder_angle;
    packet->rotation_rudder_angle = rotation_rudder_angle;
    packet->return_rudder_angle = return_rudder_angle;
    packet->z_direction = z_direction;
    packet->z_velo = z_velo;
    packet->z_over_count = z_over_count;
    packet->z_rudder_speed = z_rudder_speed;
    packet->rotation_direction = rotation_direction;
    packet->rotation_velo = rotation_velo;
    packet->rotation_rudder_speed = rotation_rudder_speed;
    packet->urgent_speed = urgent_speed;
    packet->inertia_speed = inertia_speed;
    packet->return_rudder_speed = return_rudder_speed;
    packet->return_rudder_direction = return_rudder_direction;
    packet->return_rudder_velo = return_rudder_velo;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER, (const char *)packet, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_MIN_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_VEHICLE_PARAMETER UNPACKING


/**
 * @brief Get field z_over_angle from ylcx_vehicle_parameter message
 *
 * @return  Z Action algo over angle range [0, 360]
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_parameter_get_z_over_angle(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  40);
}

/**
 * @brief Get field z_direction from ylcx_vehicle_parameter message
 *
 * @return  0 is left, 1 is right
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_z_direction(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  48);
}

/**
 * @brief Get field z_velo from ylcx_vehicle_parameter message
 *
 * @return   Z Action target speed
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_z_velo(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  49);
}

/**
 * @brief Get field z_over_count from ylcx_vehicle_parameter message
 *
 * @return  Z Action over angle count.
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_z_over_count(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  50);
}

/**
 * @brief Get field z_rudder_speed from ylcx_vehicle_parameter message
 *
 * @return  Z Action rudder speed.
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_z_rudder_speed(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  51);
}

/**
 * @brief Get field z_rudder_angle from ylcx_vehicle_parameter message
 *
 * @return  Z Action rudder angle
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_parameter_get_z_rudder_angle(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  42);
}

/**
 * @brief Get field rotation_direction from ylcx_vehicle_parameter message
 *
 * @return  0 is left, 1 is right.
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_rotation_direction(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  52);
}

/**
 * @brief Get field rotation_velo from ylcx_vehicle_parameter message
 *
 * @return  rotation target speed. 
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_rotation_velo(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  53);
}

/**
 * @brief Get field rotation_rudder_angle from ylcx_vehicle_parameter message
 *
 * @return  rotation target rudder angle
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_parameter_get_rotation_rudder_angle(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  44);
}

/**
 * @brief Get field rotation_rudder_speed from ylcx_vehicle_parameter message
 *
 * @return  rotation target rudder speed
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_rotation_rudder_speed(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  54);
}

/**
 * @brief Get field urgent_speed from ylcx_vehicle_parameter message
 *
 * @return  urgent stop vehicle speed.
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_urgent_speed(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  55);
}

/**
 * @brief Get field inertia_speed from ylcx_vehicle_parameter message
 *
 * @return  inertia stop vehicle speed.
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_inertia_speed(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  56);
}

/**
 * @brief Get field return_rudder_speed from ylcx_vehicle_parameter message
 *
 * @return  return rudder action speed
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_return_rudder_speed(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  57);
}

/**
 * @brief Get field return_rudder_angle from ylcx_vehicle_parameter message
 *
 * @return  return rudder action angle
 */
static inline uint16_t mavlink_msg_ylcx_vehicle_parameter_get_return_rudder_angle(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  46);
}

/**
 * @brief Get field return_rudder_direction from ylcx_vehicle_parameter message
 *
 * @return  0 is left, 1 is right
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_return_rudder_direction(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  58);
}

/**
 * @brief Get field return_rudder_velo from ylcx_vehicle_parameter message
 *
 * @return  return rudder action velo
 */
static inline uint8_t mavlink_msg_ylcx_vehicle_parameter_get_return_rudder_velo(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  59);
}

/**
 * @brief Get field d_kp from ylcx_vehicle_parameter message
 *
 * @return  
 */
static inline float mavlink_msg_ylcx_vehicle_parameter_get_d_kp(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Get field d_ki from ylcx_vehicle_parameter message
 *
 * @return  
 */
static inline float mavlink_msg_ylcx_vehicle_parameter_get_d_ki(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field d_kd from ylcx_vehicle_parameter message
 *
 * @return  
 */
static inline float mavlink_msg_ylcx_vehicle_parameter_get_d_kd(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field v_kp from ylcx_vehicle_parameter message
 *
 * @return  
 */
static inline float mavlink_msg_ylcx_vehicle_parameter_get_v_kp(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Get field v_ki from ylcx_vehicle_parameter message
 *
 * @return  
 */
static inline float mavlink_msg_ylcx_vehicle_parameter_get_v_ki(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  16);
}

/**
 * @brief Get field v_kd from ylcx_vehicle_parameter message
 *
 * @return  
 */
static inline float mavlink_msg_ylcx_vehicle_parameter_get_v_kd(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  20);
}

/**
 * @brief Get field l1_kp from ylcx_vehicle_parameter message
 *
 * @return  
 */
static inline float mavlink_msg_ylcx_vehicle_parameter_get_l1_kp(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  24);
}

/**
 * @brief Get field l1_ki from ylcx_vehicle_parameter message
 *
 * @return  
 */
static inline float mavlink_msg_ylcx_vehicle_parameter_get_l1_ki(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  28);
}

/**
 * @brief Get field l1_kd from ylcx_vehicle_parameter message
 *
 * @return  
 */
static inline float mavlink_msg_ylcx_vehicle_parameter_get_l1_kd(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  32);
}

/**
 * @brief Get field path_distance from ylcx_vehicle_parameter message
 *
 * @return  
 */
static inline float mavlink_msg_ylcx_vehicle_parameter_get_path_distance(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  36);
}

/**
 * @brief Decode a ylcx_vehicle_parameter message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_vehicle_parameter C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_vehicle_parameter_decode(const mavlink_message_t* msg, mavlink_ylcx_vehicle_parameter_t* ylcx_vehicle_parameter)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_vehicle_parameter->d_kp = mavlink_msg_ylcx_vehicle_parameter_get_d_kp(msg);
    ylcx_vehicle_parameter->d_ki = mavlink_msg_ylcx_vehicle_parameter_get_d_ki(msg);
    ylcx_vehicle_parameter->d_kd = mavlink_msg_ylcx_vehicle_parameter_get_d_kd(msg);
    ylcx_vehicle_parameter->v_kp = mavlink_msg_ylcx_vehicle_parameter_get_v_kp(msg);
    ylcx_vehicle_parameter->v_ki = mavlink_msg_ylcx_vehicle_parameter_get_v_ki(msg);
    ylcx_vehicle_parameter->v_kd = mavlink_msg_ylcx_vehicle_parameter_get_v_kd(msg);
    ylcx_vehicle_parameter->l1_kp = mavlink_msg_ylcx_vehicle_parameter_get_l1_kp(msg);
    ylcx_vehicle_parameter->l1_ki = mavlink_msg_ylcx_vehicle_parameter_get_l1_ki(msg);
    ylcx_vehicle_parameter->l1_kd = mavlink_msg_ylcx_vehicle_parameter_get_l1_kd(msg);
    ylcx_vehicle_parameter->path_distance = mavlink_msg_ylcx_vehicle_parameter_get_path_distance(msg);
    ylcx_vehicle_parameter->z_over_angle = mavlink_msg_ylcx_vehicle_parameter_get_z_over_angle(msg);
    ylcx_vehicle_parameter->z_rudder_angle = mavlink_msg_ylcx_vehicle_parameter_get_z_rudder_angle(msg);
    ylcx_vehicle_parameter->rotation_rudder_angle = mavlink_msg_ylcx_vehicle_parameter_get_rotation_rudder_angle(msg);
    ylcx_vehicle_parameter->return_rudder_angle = mavlink_msg_ylcx_vehicle_parameter_get_return_rudder_angle(msg);
    ylcx_vehicle_parameter->z_direction = mavlink_msg_ylcx_vehicle_parameter_get_z_direction(msg);
    ylcx_vehicle_parameter->z_velo = mavlink_msg_ylcx_vehicle_parameter_get_z_velo(msg);
    ylcx_vehicle_parameter->z_over_count = mavlink_msg_ylcx_vehicle_parameter_get_z_over_count(msg);
    ylcx_vehicle_parameter->z_rudder_speed = mavlink_msg_ylcx_vehicle_parameter_get_z_rudder_speed(msg);
    ylcx_vehicle_parameter->rotation_direction = mavlink_msg_ylcx_vehicle_parameter_get_rotation_direction(msg);
    ylcx_vehicle_parameter->rotation_velo = mavlink_msg_ylcx_vehicle_parameter_get_rotation_velo(msg);
    ylcx_vehicle_parameter->rotation_rudder_speed = mavlink_msg_ylcx_vehicle_parameter_get_rotation_rudder_speed(msg);
    ylcx_vehicle_parameter->urgent_speed = mavlink_msg_ylcx_vehicle_parameter_get_urgent_speed(msg);
    ylcx_vehicle_parameter->inertia_speed = mavlink_msg_ylcx_vehicle_parameter_get_inertia_speed(msg);
    ylcx_vehicle_parameter->return_rudder_speed = mavlink_msg_ylcx_vehicle_parameter_get_return_rudder_speed(msg);
    ylcx_vehicle_parameter->return_rudder_direction = mavlink_msg_ylcx_vehicle_parameter_get_return_rudder_direction(msg);
    ylcx_vehicle_parameter->return_rudder_velo = mavlink_msg_ylcx_vehicle_parameter_get_return_rudder_velo(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN? msg->len : MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN;
        memset(ylcx_vehicle_parameter, 0, MAVLINK_MSG_ID_YLCX_VEHICLE_PARAMETER_LEN);
    memcpy(ylcx_vehicle_parameter, _MAV_PAYLOAD(msg), len);
#endif
}
