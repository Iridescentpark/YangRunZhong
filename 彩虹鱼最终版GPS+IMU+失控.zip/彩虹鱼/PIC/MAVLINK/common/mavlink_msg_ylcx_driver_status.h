#pragma once
// MESSAGE YLCX_DRIVER_STATUS PACKING

#define MAVLINK_MSG_ID_YLCX_DRIVER_STATUS 54304


typedef struct __mavlink_ylcx_driver_status_t {
 float rpm; /*< [rpm] Indicated rate*/
 float torque; /*< [rpm] Indicated rate*/
 float power; /*< [rpm] Indicated rate*/
 float current_rudder; /*< [rpm] Indicated rate*/
} mavlink_ylcx_driver_status_t;

#define MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN 16
#define MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN 16
#define MAVLINK_MSG_ID_54304_LEN 16
#define MAVLINK_MSG_ID_54304_MIN_LEN 16

#define MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_CRC 193
#define MAVLINK_MSG_ID_54304_CRC 193



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_DRIVER_STATUS { \
    54304, \
    "YLCX_DRIVER_STATUS", \
    4, \
    {  { "rpm", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ylcx_driver_status_t, rpm) }, \
         { "torque", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_ylcx_driver_status_t, torque) }, \
         { "power", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ylcx_driver_status_t, power) }, \
         { "current_rudder", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ylcx_driver_status_t, current_rudder) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_DRIVER_STATUS { \
    "YLCX_DRIVER_STATUS", \
    4, \
    {  { "rpm", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ylcx_driver_status_t, rpm) }, \
         { "torque", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_ylcx_driver_status_t, torque) }, \
         { "power", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ylcx_driver_status_t, power) }, \
         { "current_rudder", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ylcx_driver_status_t, current_rudder) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_driver_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param rpm [rpm] Indicated rate
 * @param torque [rpm] Indicated rate
 * @param power [rpm] Indicated rate
 * @param current_rudder [rpm] Indicated rate
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_driver_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               float rpm, float torque, float power, float current_rudder)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN];
    _mav_put_float(buf, 0, rpm);
    _mav_put_float(buf, 4, torque);
    _mav_put_float(buf, 8, power);
    _mav_put_float(buf, 12, current_rudder);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN);
#else
    mavlink_ylcx_driver_status_t packet;
    packet.rpm = rpm;
    packet.torque = torque;
    packet.power = power;
    packet.current_rudder = current_rudder;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_DRIVER_STATUS;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_CRC);
}

/**
 * @brief Pack a ylcx_driver_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param rpm [rpm] Indicated rate
 * @param torque [rpm] Indicated rate
 * @param power [rpm] Indicated rate
 * @param current_rudder [rpm] Indicated rate
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_driver_status_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               float rpm, float torque, float power, float current_rudder)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN];
    _mav_put_float(buf, 0, rpm);
    _mav_put_float(buf, 4, torque);
    _mav_put_float(buf, 8, power);
    _mav_put_float(buf, 12, current_rudder);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN);
#else
    mavlink_ylcx_driver_status_t packet;
    packet.rpm = rpm;
    packet.torque = torque;
    packet.power = power;
    packet.current_rudder = current_rudder;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_DRIVER_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN);
#endif
}

/**
 * @brief Pack a ylcx_driver_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param rpm [rpm] Indicated rate
 * @param torque [rpm] Indicated rate
 * @param power [rpm] Indicated rate
 * @param current_rudder [rpm] Indicated rate
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_driver_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   float rpm,float torque,float power,float current_rudder)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN];
    _mav_put_float(buf, 0, rpm);
    _mav_put_float(buf, 4, torque);
    _mav_put_float(buf, 8, power);
    _mav_put_float(buf, 12, current_rudder);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN);
#else
    mavlink_ylcx_driver_status_t packet;
    packet.rpm = rpm;
    packet.torque = torque;
    packet.power = power;
    packet.current_rudder = current_rudder;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_DRIVER_STATUS;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_CRC);
}

/**
 * @brief Encode a ylcx_driver_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_driver_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_driver_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_driver_status_t* ylcx_driver_status)
{
    return mavlink_msg_ylcx_driver_status_pack(system_id, component_id, msg, ylcx_driver_status->rpm, ylcx_driver_status->torque, ylcx_driver_status->power, ylcx_driver_status->current_rudder);
}

/**
 * @brief Encode a ylcx_driver_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_driver_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_driver_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_driver_status_t* ylcx_driver_status)
{
    return mavlink_msg_ylcx_driver_status_pack_chan(system_id, component_id, chan, msg, ylcx_driver_status->rpm, ylcx_driver_status->torque, ylcx_driver_status->power, ylcx_driver_status->current_rudder);
}

/**
 * @brief Encode a ylcx_driver_status struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_driver_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_driver_status_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_driver_status_t* ylcx_driver_status)
{
    return mavlink_msg_ylcx_driver_status_pack_status(system_id, component_id, _status, msg,  ylcx_driver_status->rpm, ylcx_driver_status->torque, ylcx_driver_status->power, ylcx_driver_status->current_rudder);
}

/**
 * @brief Send a ylcx_driver_status message
 * @param chan MAVLink channel to send the message
 *
 * @param rpm [rpm] Indicated rate
 * @param torque [rpm] Indicated rate
 * @param power [rpm] Indicated rate
 * @param current_rudder [rpm] Indicated rate
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_driver_status_send(mavlink_channel_t chan, float rpm, float torque, float power, float current_rudder)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN];
    _mav_put_float(buf, 0, rpm);
    _mav_put_float(buf, 4, torque);
    _mav_put_float(buf, 8, power);
    _mav_put_float(buf, 12, current_rudder);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS, buf, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_CRC);
#else
    mavlink_ylcx_driver_status_t packet;
    packet.rpm = rpm;
    packet.torque = torque;
    packet.power = power;
    packet.current_rudder = current_rudder;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS, (const char *)&packet, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_CRC);
#endif
}

/**
 * @brief Send a ylcx_driver_status message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_driver_status_send_struct(mavlink_channel_t chan, const mavlink_ylcx_driver_status_t* ylcx_driver_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_driver_status_send(chan, ylcx_driver_status->rpm, ylcx_driver_status->torque, ylcx_driver_status->power, ylcx_driver_status->current_rudder);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS, (const char *)ylcx_driver_status, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_driver_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  float rpm, float torque, float power, float current_rudder)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_float(buf, 0, rpm);
    _mav_put_float(buf, 4, torque);
    _mav_put_float(buf, 8, power);
    _mav_put_float(buf, 12, current_rudder);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS, buf, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_CRC);
#else
    mavlink_ylcx_driver_status_t *packet = (mavlink_ylcx_driver_status_t *)msgbuf;
    packet->rpm = rpm;
    packet->torque = torque;
    packet->power = power;
    packet->current_rudder = current_rudder;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS, (const char *)packet, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_DRIVER_STATUS UNPACKING


/**
 * @brief Get field rpm from ylcx_driver_status message
 *
 * @return [rpm] Indicated rate
 */
static inline float mavlink_msg_ylcx_driver_status_get_rpm(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Get field torque from ylcx_driver_status message
 *
 * @return [rpm] Indicated rate
 */
static inline float mavlink_msg_ylcx_driver_status_get_torque(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field power from ylcx_driver_status message
 *
 * @return [rpm] Indicated rate
 */
static inline float mavlink_msg_ylcx_driver_status_get_power(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field current_rudder from ylcx_driver_status message
 *
 * @return [rpm] Indicated rate
 */
static inline float mavlink_msg_ylcx_driver_status_get_current_rudder(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Decode a ylcx_driver_status message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_driver_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_driver_status_decode(const mavlink_message_t* msg, mavlink_ylcx_driver_status_t* ylcx_driver_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_driver_status->rpm = mavlink_msg_ylcx_driver_status_get_rpm(msg);
    ylcx_driver_status->torque = mavlink_msg_ylcx_driver_status_get_torque(msg);
    ylcx_driver_status->power = mavlink_msg_ylcx_driver_status_get_power(msg);
    ylcx_driver_status->current_rudder = mavlink_msg_ylcx_driver_status_get_current_rudder(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN? msg->len : MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN;
        memset(ylcx_driver_status, 0, MAVLINK_MSG_ID_YLCX_DRIVER_STATUS_LEN);
    memcpy(ylcx_driver_status, _MAV_PAYLOAD(msg), len);
#endif
}
