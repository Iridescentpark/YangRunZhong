#pragma once
// MESSAGE YLCX_SPIDER_BATTERY PACKING

#define MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY 54405


typedef struct __mavlink_ylcx_spider_battery_t {
 int32_t voltage; /*< [mV] Battery voltage of cells 1 to 10 (see voltages_ext for cells 11-14). Cells in this field above the valid cell count for this battery should have the UINT16_MAX value. If individual cell voltages are unknown or not measured for this battery, then the overall battery voltage should be filled in cell 0, with all others set to UINT16_MAX. If the voltage of the battery is greater than (UINT16_MAX - 1), then cell 0 should be set to (UINT16_MAX - 1), and cell 1 to the remaining voltage. This can be extended to multiple cells if the total voltage is greater than 2 * (UINT16_MAX - 1).*/
 int32_t current; /*< [cA] Battery current, -1: autopilot does not measure the current*/
 int32_t temperature; /*< [cdegC] Temperature of the battery. INT16_MAX for unknown temperature.*/
 int16_t battery_remaining; /*< [%] Remaining battery energy. Values: [0-100], -1: autopilot does not estimate the remaining battery.*/
 uint8_t id; /*<  Battery ID*/
 uint8_t type; /*<  Type (chemistry) of the battery*/
 int8_t in_voltage_high; /*<  charge voltage high*/
 int8_t in_voltage_low; /*<  charge voltage low*/
 int8_t in_current_high; /*<  charge current high*/
 int8_t in_temperature_high; /*<  charge temperature high*/
 int8_t in_temperature_low; /*<  charge temperature low*/
 int8_t out_voltage_high; /*<  out voltage high*/
 int8_t out_voltage_low; /*<  out voltage low*/
 int8_t out_current_high; /*<  out current high*/
 int8_t out_temperature_high; /*<  out temperature high*/
 int8_t out_temperature_low; /*<  out temperature low*/
} mavlink_ylcx_spider_battery_t;

#define MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN 26
#define MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN 26
#define MAVLINK_MSG_ID_54405_LEN 26
#define MAVLINK_MSG_ID_54405_MIN_LEN 26

#define MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_CRC 4
#define MAVLINK_MSG_ID_54405_CRC 4



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_SPIDER_BATTERY { \
    54405, \
    "YLCX_SPIDER_BATTERY", \
    16, \
    {  { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 14, offsetof(mavlink_ylcx_spider_battery_t, id) }, \
         { "type", NULL, MAVLINK_TYPE_UINT8_T, 0, 15, offsetof(mavlink_ylcx_spider_battery_t, type) }, \
         { "voltage", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_ylcx_spider_battery_t, voltage) }, \
         { "current", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_ylcx_spider_battery_t, current) }, \
         { "battery_remaining", NULL, MAVLINK_TYPE_INT16_T, 0, 12, offsetof(mavlink_ylcx_spider_battery_t, battery_remaining) }, \
         { "temperature", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_ylcx_spider_battery_t, temperature) }, \
         { "in_voltage_high", NULL, MAVLINK_TYPE_INT8_T, 0, 16, offsetof(mavlink_ylcx_spider_battery_t, in_voltage_high) }, \
         { "in_voltage_low", NULL, MAVLINK_TYPE_INT8_T, 0, 17, offsetof(mavlink_ylcx_spider_battery_t, in_voltage_low) }, \
         { "in_current_high", NULL, MAVLINK_TYPE_INT8_T, 0, 18, offsetof(mavlink_ylcx_spider_battery_t, in_current_high) }, \
         { "in_temperature_high", NULL, MAVLINK_TYPE_INT8_T, 0, 19, offsetof(mavlink_ylcx_spider_battery_t, in_temperature_high) }, \
         { "in_temperature_low", NULL, MAVLINK_TYPE_INT8_T, 0, 20, offsetof(mavlink_ylcx_spider_battery_t, in_temperature_low) }, \
         { "out_voltage_high", NULL, MAVLINK_TYPE_INT8_T, 0, 21, offsetof(mavlink_ylcx_spider_battery_t, out_voltage_high) }, \
         { "out_voltage_low", NULL, MAVLINK_TYPE_INT8_T, 0, 22, offsetof(mavlink_ylcx_spider_battery_t, out_voltage_low) }, \
         { "out_current_high", NULL, MAVLINK_TYPE_INT8_T, 0, 23, offsetof(mavlink_ylcx_spider_battery_t, out_current_high) }, \
         { "out_temperature_high", NULL, MAVLINK_TYPE_INT8_T, 0, 24, offsetof(mavlink_ylcx_spider_battery_t, out_temperature_high) }, \
         { "out_temperature_low", NULL, MAVLINK_TYPE_INT8_T, 0, 25, offsetof(mavlink_ylcx_spider_battery_t, out_temperature_low) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_SPIDER_BATTERY { \
    "YLCX_SPIDER_BATTERY", \
    16, \
    {  { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 14, offsetof(mavlink_ylcx_spider_battery_t, id) }, \
         { "type", NULL, MAVLINK_TYPE_UINT8_T, 0, 15, offsetof(mavlink_ylcx_spider_battery_t, type) }, \
         { "voltage", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_ylcx_spider_battery_t, voltage) }, \
         { "current", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_ylcx_spider_battery_t, current) }, \
         { "battery_remaining", NULL, MAVLINK_TYPE_INT16_T, 0, 12, offsetof(mavlink_ylcx_spider_battery_t, battery_remaining) }, \
         { "temperature", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_ylcx_spider_battery_t, temperature) }, \
         { "in_voltage_high", NULL, MAVLINK_TYPE_INT8_T, 0, 16, offsetof(mavlink_ylcx_spider_battery_t, in_voltage_high) }, \
         { "in_voltage_low", NULL, MAVLINK_TYPE_INT8_T, 0, 17, offsetof(mavlink_ylcx_spider_battery_t, in_voltage_low) }, \
         { "in_current_high", NULL, MAVLINK_TYPE_INT8_T, 0, 18, offsetof(mavlink_ylcx_spider_battery_t, in_current_high) }, \
         { "in_temperature_high", NULL, MAVLINK_TYPE_INT8_T, 0, 19, offsetof(mavlink_ylcx_spider_battery_t, in_temperature_high) }, \
         { "in_temperature_low", NULL, MAVLINK_TYPE_INT8_T, 0, 20, offsetof(mavlink_ylcx_spider_battery_t, in_temperature_low) }, \
         { "out_voltage_high", NULL, MAVLINK_TYPE_INT8_T, 0, 21, offsetof(mavlink_ylcx_spider_battery_t, out_voltage_high) }, \
         { "out_voltage_low", NULL, MAVLINK_TYPE_INT8_T, 0, 22, offsetof(mavlink_ylcx_spider_battery_t, out_voltage_low) }, \
         { "out_current_high", NULL, MAVLINK_TYPE_INT8_T, 0, 23, offsetof(mavlink_ylcx_spider_battery_t, out_current_high) }, \
         { "out_temperature_high", NULL, MAVLINK_TYPE_INT8_T, 0, 24, offsetof(mavlink_ylcx_spider_battery_t, out_temperature_high) }, \
         { "out_temperature_low", NULL, MAVLINK_TYPE_INT8_T, 0, 25, offsetof(mavlink_ylcx_spider_battery_t, out_temperature_low) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_spider_battery message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param id  Battery ID
 * @param type  Type (chemistry) of the battery
 * @param voltage [mV] Battery voltage of cells 1 to 10 (see voltages_ext for cells 11-14). Cells in this field above the valid cell count for this battery should have the UINT16_MAX value. If individual cell voltages are unknown or not measured for this battery, then the overall battery voltage should be filled in cell 0, with all others set to UINT16_MAX. If the voltage of the battery is greater than (UINT16_MAX - 1), then cell 0 should be set to (UINT16_MAX - 1), and cell 1 to the remaining voltage. This can be extended to multiple cells if the total voltage is greater than 2 * (UINT16_MAX - 1).
 * @param current [cA] Battery current, -1: autopilot does not measure the current
 * @param battery_remaining [%] Remaining battery energy. Values: [0-100], -1: autopilot does not estimate the remaining battery.
 * @param temperature [cdegC] Temperature of the battery. INT16_MAX for unknown temperature.
 * @param in_voltage_high  charge voltage high
 * @param in_voltage_low  charge voltage low
 * @param in_current_high  charge current high
 * @param in_temperature_high  charge temperature high
 * @param in_temperature_low  charge temperature low
 * @param out_voltage_high  out voltage high
 * @param out_voltage_low  out voltage low
 * @param out_current_high  out current high
 * @param out_temperature_high  out temperature high
 * @param out_temperature_low  out temperature low
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_spider_battery_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t id, uint8_t type, int32_t voltage, int32_t current, int16_t battery_remaining, int32_t temperature, int8_t in_voltage_high, int8_t in_voltage_low, int8_t in_current_high, int8_t in_temperature_high, int8_t in_temperature_low, int8_t out_voltage_high, int8_t out_voltage_low, int8_t out_current_high, int8_t out_temperature_high, int8_t out_temperature_low)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN];
    _mav_put_int32_t(buf, 0, voltage);
    _mav_put_int32_t(buf, 4, current);
    _mav_put_int32_t(buf, 8, temperature);
    _mav_put_int16_t(buf, 12, battery_remaining);
    _mav_put_uint8_t(buf, 14, id);
    _mav_put_uint8_t(buf, 15, type);
    _mav_put_int8_t(buf, 16, in_voltage_high);
    _mav_put_int8_t(buf, 17, in_voltage_low);
    _mav_put_int8_t(buf, 18, in_current_high);
    _mav_put_int8_t(buf, 19, in_temperature_high);
    _mav_put_int8_t(buf, 20, in_temperature_low);
    _mav_put_int8_t(buf, 21, out_voltage_high);
    _mav_put_int8_t(buf, 22, out_voltage_low);
    _mav_put_int8_t(buf, 23, out_current_high);
    _mav_put_int8_t(buf, 24, out_temperature_high);
    _mav_put_int8_t(buf, 25, out_temperature_low);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN);
#else
    mavlink_ylcx_spider_battery_t packet;
    packet.voltage = voltage;
    packet.current = current;
    packet.temperature = temperature;
    packet.battery_remaining = battery_remaining;
    packet.id = id;
    packet.type = type;
    packet.in_voltage_high = in_voltage_high;
    packet.in_voltage_low = in_voltage_low;
    packet.in_current_high = in_current_high;
    packet.in_temperature_high = in_temperature_high;
    packet.in_temperature_low = in_temperature_low;
    packet.out_voltage_high = out_voltage_high;
    packet.out_voltage_low = out_voltage_low;
    packet.out_current_high = out_current_high;
    packet.out_temperature_high = out_temperature_high;
    packet.out_temperature_low = out_temperature_low;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_CRC);
}

/**
 * @brief Pack a ylcx_spider_battery message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param id  Battery ID
 * @param type  Type (chemistry) of the battery
 * @param voltage [mV] Battery voltage of cells 1 to 10 (see voltages_ext for cells 11-14). Cells in this field above the valid cell count for this battery should have the UINT16_MAX value. If individual cell voltages are unknown or not measured for this battery, then the overall battery voltage should be filled in cell 0, with all others set to UINT16_MAX. If the voltage of the battery is greater than (UINT16_MAX - 1), then cell 0 should be set to (UINT16_MAX - 1), and cell 1 to the remaining voltage. This can be extended to multiple cells if the total voltage is greater than 2 * (UINT16_MAX - 1).
 * @param current [cA] Battery current, -1: autopilot does not measure the current
 * @param battery_remaining [%] Remaining battery energy. Values: [0-100], -1: autopilot does not estimate the remaining battery.
 * @param temperature [cdegC] Temperature of the battery. INT16_MAX for unknown temperature.
 * @param in_voltage_high  charge voltage high
 * @param in_voltage_low  charge voltage low
 * @param in_current_high  charge current high
 * @param in_temperature_high  charge temperature high
 * @param in_temperature_low  charge temperature low
 * @param out_voltage_high  out voltage high
 * @param out_voltage_low  out voltage low
 * @param out_current_high  out current high
 * @param out_temperature_high  out temperature high
 * @param out_temperature_low  out temperature low
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_spider_battery_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t id, uint8_t type, int32_t voltage, int32_t current, int16_t battery_remaining, int32_t temperature, int8_t in_voltage_high, int8_t in_voltage_low, int8_t in_current_high, int8_t in_temperature_high, int8_t in_temperature_low, int8_t out_voltage_high, int8_t out_voltage_low, int8_t out_current_high, int8_t out_temperature_high, int8_t out_temperature_low)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN];
    _mav_put_int32_t(buf, 0, voltage);
    _mav_put_int32_t(buf, 4, current);
    _mav_put_int32_t(buf, 8, temperature);
    _mav_put_int16_t(buf, 12, battery_remaining);
    _mav_put_uint8_t(buf, 14, id);
    _mav_put_uint8_t(buf, 15, type);
    _mav_put_int8_t(buf, 16, in_voltage_high);
    _mav_put_int8_t(buf, 17, in_voltage_low);
    _mav_put_int8_t(buf, 18, in_current_high);
    _mav_put_int8_t(buf, 19, in_temperature_high);
    _mav_put_int8_t(buf, 20, in_temperature_low);
    _mav_put_int8_t(buf, 21, out_voltage_high);
    _mav_put_int8_t(buf, 22, out_voltage_low);
    _mav_put_int8_t(buf, 23, out_current_high);
    _mav_put_int8_t(buf, 24, out_temperature_high);
    _mav_put_int8_t(buf, 25, out_temperature_low);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN);
#else
    mavlink_ylcx_spider_battery_t packet;
    packet.voltage = voltage;
    packet.current = current;
    packet.temperature = temperature;
    packet.battery_remaining = battery_remaining;
    packet.id = id;
    packet.type = type;
    packet.in_voltage_high = in_voltage_high;
    packet.in_voltage_low = in_voltage_low;
    packet.in_current_high = in_current_high;
    packet.in_temperature_high = in_temperature_high;
    packet.in_temperature_low = in_temperature_low;
    packet.out_voltage_high = out_voltage_high;
    packet.out_voltage_low = out_voltage_low;
    packet.out_current_high = out_current_high;
    packet.out_temperature_high = out_temperature_high;
    packet.out_temperature_low = out_temperature_low;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN);
#endif
}

/**
 * @brief Pack a ylcx_spider_battery message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param id  Battery ID
 * @param type  Type (chemistry) of the battery
 * @param voltage [mV] Battery voltage of cells 1 to 10 (see voltages_ext for cells 11-14). Cells in this field above the valid cell count for this battery should have the UINT16_MAX value. If individual cell voltages are unknown or not measured for this battery, then the overall battery voltage should be filled in cell 0, with all others set to UINT16_MAX. If the voltage of the battery is greater than (UINT16_MAX - 1), then cell 0 should be set to (UINT16_MAX - 1), and cell 1 to the remaining voltage. This can be extended to multiple cells if the total voltage is greater than 2 * (UINT16_MAX - 1).
 * @param current [cA] Battery current, -1: autopilot does not measure the current
 * @param battery_remaining [%] Remaining battery energy. Values: [0-100], -1: autopilot does not estimate the remaining battery.
 * @param temperature [cdegC] Temperature of the battery. INT16_MAX for unknown temperature.
 * @param in_voltage_high  charge voltage high
 * @param in_voltage_low  charge voltage low
 * @param in_current_high  charge current high
 * @param in_temperature_high  charge temperature high
 * @param in_temperature_low  charge temperature low
 * @param out_voltage_high  out voltage high
 * @param out_voltage_low  out voltage low
 * @param out_current_high  out current high
 * @param out_temperature_high  out temperature high
 * @param out_temperature_low  out temperature low
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_spider_battery_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t id,uint8_t type,int32_t voltage,int32_t current,int16_t battery_remaining,int32_t temperature,int8_t in_voltage_high,int8_t in_voltage_low,int8_t in_current_high,int8_t in_temperature_high,int8_t in_temperature_low,int8_t out_voltage_high,int8_t out_voltage_low,int8_t out_current_high,int8_t out_temperature_high,int8_t out_temperature_low)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN];
    _mav_put_int32_t(buf, 0, voltage);
    _mav_put_int32_t(buf, 4, current);
    _mav_put_int32_t(buf, 8, temperature);
    _mav_put_int16_t(buf, 12, battery_remaining);
    _mav_put_uint8_t(buf, 14, id);
    _mav_put_uint8_t(buf, 15, type);
    _mav_put_int8_t(buf, 16, in_voltage_high);
    _mav_put_int8_t(buf, 17, in_voltage_low);
    _mav_put_int8_t(buf, 18, in_current_high);
    _mav_put_int8_t(buf, 19, in_temperature_high);
    _mav_put_int8_t(buf, 20, in_temperature_low);
    _mav_put_int8_t(buf, 21, out_voltage_high);
    _mav_put_int8_t(buf, 22, out_voltage_low);
    _mav_put_int8_t(buf, 23, out_current_high);
    _mav_put_int8_t(buf, 24, out_temperature_high);
    _mav_put_int8_t(buf, 25, out_temperature_low);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN);
#else
    mavlink_ylcx_spider_battery_t packet;
    packet.voltage = voltage;
    packet.current = current;
    packet.temperature = temperature;
    packet.battery_remaining = battery_remaining;
    packet.id = id;
    packet.type = type;
    packet.in_voltage_high = in_voltage_high;
    packet.in_voltage_low = in_voltage_low;
    packet.in_current_high = in_current_high;
    packet.in_temperature_high = in_temperature_high;
    packet.in_temperature_low = in_temperature_low;
    packet.out_voltage_high = out_voltage_high;
    packet.out_voltage_low = out_voltage_low;
    packet.out_current_high = out_current_high;
    packet.out_temperature_high = out_temperature_high;
    packet.out_temperature_low = out_temperature_low;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_CRC);
}

/**
 * @brief Encode a ylcx_spider_battery struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_spider_battery C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_spider_battery_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_spider_battery_t* ylcx_spider_battery)
{
    return mavlink_msg_ylcx_spider_battery_pack(system_id, component_id, msg, ylcx_spider_battery->id, ylcx_spider_battery->type, ylcx_spider_battery->voltage, ylcx_spider_battery->current, ylcx_spider_battery->battery_remaining, ylcx_spider_battery->temperature, ylcx_spider_battery->in_voltage_high, ylcx_spider_battery->in_voltage_low, ylcx_spider_battery->in_current_high, ylcx_spider_battery->in_temperature_high, ylcx_spider_battery->in_temperature_low, ylcx_spider_battery->out_voltage_high, ylcx_spider_battery->out_voltage_low, ylcx_spider_battery->out_current_high, ylcx_spider_battery->out_temperature_high, ylcx_spider_battery->out_temperature_low);
}

/**
 * @brief Encode a ylcx_spider_battery struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_spider_battery C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_spider_battery_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_spider_battery_t* ylcx_spider_battery)
{
    return mavlink_msg_ylcx_spider_battery_pack_chan(system_id, component_id, chan, msg, ylcx_spider_battery->id, ylcx_spider_battery->type, ylcx_spider_battery->voltage, ylcx_spider_battery->current, ylcx_spider_battery->battery_remaining, ylcx_spider_battery->temperature, ylcx_spider_battery->in_voltage_high, ylcx_spider_battery->in_voltage_low, ylcx_spider_battery->in_current_high, ylcx_spider_battery->in_temperature_high, ylcx_spider_battery->in_temperature_low, ylcx_spider_battery->out_voltage_high, ylcx_spider_battery->out_voltage_low, ylcx_spider_battery->out_current_high, ylcx_spider_battery->out_temperature_high, ylcx_spider_battery->out_temperature_low);
}

/**
 * @brief Encode a ylcx_spider_battery struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_spider_battery C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_spider_battery_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_spider_battery_t* ylcx_spider_battery)
{
    return mavlink_msg_ylcx_spider_battery_pack_status(system_id, component_id, _status, msg,  ylcx_spider_battery->id, ylcx_spider_battery->type, ylcx_spider_battery->voltage, ylcx_spider_battery->current, ylcx_spider_battery->battery_remaining, ylcx_spider_battery->temperature, ylcx_spider_battery->in_voltage_high, ylcx_spider_battery->in_voltage_low, ylcx_spider_battery->in_current_high, ylcx_spider_battery->in_temperature_high, ylcx_spider_battery->in_temperature_low, ylcx_spider_battery->out_voltage_high, ylcx_spider_battery->out_voltage_low, ylcx_spider_battery->out_current_high, ylcx_spider_battery->out_temperature_high, ylcx_spider_battery->out_temperature_low);
}

/**
 * @brief Send a ylcx_spider_battery message
 * @param chan MAVLink channel to send the message
 *
 * @param id  Battery ID
 * @param type  Type (chemistry) of the battery
 * @param voltage [mV] Battery voltage of cells 1 to 10 (see voltages_ext for cells 11-14). Cells in this field above the valid cell count for this battery should have the UINT16_MAX value. If individual cell voltages are unknown or not measured for this battery, then the overall battery voltage should be filled in cell 0, with all others set to UINT16_MAX. If the voltage of the battery is greater than (UINT16_MAX - 1), then cell 0 should be set to (UINT16_MAX - 1), and cell 1 to the remaining voltage. This can be extended to multiple cells if the total voltage is greater than 2 * (UINT16_MAX - 1).
 * @param current [cA] Battery current, -1: autopilot does not measure the current
 * @param battery_remaining [%] Remaining battery energy. Values: [0-100], -1: autopilot does not estimate the remaining battery.
 * @param temperature [cdegC] Temperature of the battery. INT16_MAX for unknown temperature.
 * @param in_voltage_high  charge voltage high
 * @param in_voltage_low  charge voltage low
 * @param in_current_high  charge current high
 * @param in_temperature_high  charge temperature high
 * @param in_temperature_low  charge temperature low
 * @param out_voltage_high  out voltage high
 * @param out_voltage_low  out voltage low
 * @param out_current_high  out current high
 * @param out_temperature_high  out temperature high
 * @param out_temperature_low  out temperature low
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_spider_battery_send(mavlink_channel_t chan, uint8_t id, uint8_t type, int32_t voltage, int32_t current, int16_t battery_remaining, int32_t temperature, int8_t in_voltage_high, int8_t in_voltage_low, int8_t in_current_high, int8_t in_temperature_high, int8_t in_temperature_low, int8_t out_voltage_high, int8_t out_voltage_low, int8_t out_current_high, int8_t out_temperature_high, int8_t out_temperature_low)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN];
    _mav_put_int32_t(buf, 0, voltage);
    _mav_put_int32_t(buf, 4, current);
    _mav_put_int32_t(buf, 8, temperature);
    _mav_put_int16_t(buf, 12, battery_remaining);
    _mav_put_uint8_t(buf, 14, id);
    _mav_put_uint8_t(buf, 15, type);
    _mav_put_int8_t(buf, 16, in_voltage_high);
    _mav_put_int8_t(buf, 17, in_voltage_low);
    _mav_put_int8_t(buf, 18, in_current_high);
    _mav_put_int8_t(buf, 19, in_temperature_high);
    _mav_put_int8_t(buf, 20, in_temperature_low);
    _mav_put_int8_t(buf, 21, out_voltage_high);
    _mav_put_int8_t(buf, 22, out_voltage_low);
    _mav_put_int8_t(buf, 23, out_current_high);
    _mav_put_int8_t(buf, 24, out_temperature_high);
    _mav_put_int8_t(buf, 25, out_temperature_low);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY, buf, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_CRC);
#else
    mavlink_ylcx_spider_battery_t packet;
    packet.voltage = voltage;
    packet.current = current;
    packet.temperature = temperature;
    packet.battery_remaining = battery_remaining;
    packet.id = id;
    packet.type = type;
    packet.in_voltage_high = in_voltage_high;
    packet.in_voltage_low = in_voltage_low;
    packet.in_current_high = in_current_high;
    packet.in_temperature_high = in_temperature_high;
    packet.in_temperature_low = in_temperature_low;
    packet.out_voltage_high = out_voltage_high;
    packet.out_voltage_low = out_voltage_low;
    packet.out_current_high = out_current_high;
    packet.out_temperature_high = out_temperature_high;
    packet.out_temperature_low = out_temperature_low;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY, (const char *)&packet, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_CRC);
#endif
}

/**
 * @brief Send a ylcx_spider_battery message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_spider_battery_send_struct(mavlink_channel_t chan, const mavlink_ylcx_spider_battery_t* ylcx_spider_battery)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_spider_battery_send(chan, ylcx_spider_battery->id, ylcx_spider_battery->type, ylcx_spider_battery->voltage, ylcx_spider_battery->current, ylcx_spider_battery->battery_remaining, ylcx_spider_battery->temperature, ylcx_spider_battery->in_voltage_high, ylcx_spider_battery->in_voltage_low, ylcx_spider_battery->in_current_high, ylcx_spider_battery->in_temperature_high, ylcx_spider_battery->in_temperature_low, ylcx_spider_battery->out_voltage_high, ylcx_spider_battery->out_voltage_low, ylcx_spider_battery->out_current_high, ylcx_spider_battery->out_temperature_high, ylcx_spider_battery->out_temperature_low);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY, (const char *)ylcx_spider_battery, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_spider_battery_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t id, uint8_t type, int32_t voltage, int32_t current, int16_t battery_remaining, int32_t temperature, int8_t in_voltage_high, int8_t in_voltage_low, int8_t in_current_high, int8_t in_temperature_high, int8_t in_temperature_low, int8_t out_voltage_high, int8_t out_voltage_low, int8_t out_current_high, int8_t out_temperature_high, int8_t out_temperature_low)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int32_t(buf, 0, voltage);
    _mav_put_int32_t(buf, 4, current);
    _mav_put_int32_t(buf, 8, temperature);
    _mav_put_int16_t(buf, 12, battery_remaining);
    _mav_put_uint8_t(buf, 14, id);
    _mav_put_uint8_t(buf, 15, type);
    _mav_put_int8_t(buf, 16, in_voltage_high);
    _mav_put_int8_t(buf, 17, in_voltage_low);
    _mav_put_int8_t(buf, 18, in_current_high);
    _mav_put_int8_t(buf, 19, in_temperature_high);
    _mav_put_int8_t(buf, 20, in_temperature_low);
    _mav_put_int8_t(buf, 21, out_voltage_high);
    _mav_put_int8_t(buf, 22, out_voltage_low);
    _mav_put_int8_t(buf, 23, out_current_high);
    _mav_put_int8_t(buf, 24, out_temperature_high);
    _mav_put_int8_t(buf, 25, out_temperature_low);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY, buf, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_CRC);
#else
    mavlink_ylcx_spider_battery_t *packet = (mavlink_ylcx_spider_battery_t *)msgbuf;
    packet->voltage = voltage;
    packet->current = current;
    packet->temperature = temperature;
    packet->battery_remaining = battery_remaining;
    packet->id = id;
    packet->type = type;
    packet->in_voltage_high = in_voltage_high;
    packet->in_voltage_low = in_voltage_low;
    packet->in_current_high = in_current_high;
    packet->in_temperature_high = in_temperature_high;
    packet->in_temperature_low = in_temperature_low;
    packet->out_voltage_high = out_voltage_high;
    packet->out_voltage_low = out_voltage_low;
    packet->out_current_high = out_current_high;
    packet->out_temperature_high = out_temperature_high;
    packet->out_temperature_low = out_temperature_low;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY, (const char *)packet, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_MIN_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_SPIDER_BATTERY UNPACKING


/**
 * @brief Get field id from ylcx_spider_battery message
 *
 * @return  Battery ID
 */
static inline uint8_t mavlink_msg_ylcx_spider_battery_get_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  14);
}

/**
 * @brief Get field type from ylcx_spider_battery message
 *
 * @return  Type (chemistry) of the battery
 */
static inline uint8_t mavlink_msg_ylcx_spider_battery_get_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  15);
}

/**
 * @brief Get field voltage from ylcx_spider_battery message
 *
 * @return [mV] Battery voltage of cells 1 to 10 (see voltages_ext for cells 11-14). Cells in this field above the valid cell count for this battery should have the UINT16_MAX value. If individual cell voltages are unknown or not measured for this battery, then the overall battery voltage should be filled in cell 0, with all others set to UINT16_MAX. If the voltage of the battery is greater than (UINT16_MAX - 1), then cell 0 should be set to (UINT16_MAX - 1), and cell 1 to the remaining voltage. This can be extended to multiple cells if the total voltage is greater than 2 * (UINT16_MAX - 1).
 */
static inline int32_t mavlink_msg_ylcx_spider_battery_get_voltage(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  0);
}

/**
 * @brief Get field current from ylcx_spider_battery message
 *
 * @return [cA] Battery current, -1: autopilot does not measure the current
 */
static inline int32_t mavlink_msg_ylcx_spider_battery_get_current(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  4);
}

/**
 * @brief Get field battery_remaining from ylcx_spider_battery message
 *
 * @return [%] Remaining battery energy. Values: [0-100], -1: autopilot does not estimate the remaining battery.
 */
static inline int16_t mavlink_msg_ylcx_spider_battery_get_battery_remaining(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  12);
}

/**
 * @brief Get field temperature from ylcx_spider_battery message
 *
 * @return [cdegC] Temperature of the battery. INT16_MAX for unknown temperature.
 */
static inline int32_t mavlink_msg_ylcx_spider_battery_get_temperature(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  8);
}

/**
 * @brief Get field in_voltage_high from ylcx_spider_battery message
 *
 * @return  charge voltage high
 */
static inline int8_t mavlink_msg_ylcx_spider_battery_get_in_voltage_high(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  16);
}

/**
 * @brief Get field in_voltage_low from ylcx_spider_battery message
 *
 * @return  charge voltage low
 */
static inline int8_t mavlink_msg_ylcx_spider_battery_get_in_voltage_low(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  17);
}

/**
 * @brief Get field in_current_high from ylcx_spider_battery message
 *
 * @return  charge current high
 */
static inline int8_t mavlink_msg_ylcx_spider_battery_get_in_current_high(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  18);
}

/**
 * @brief Get field in_temperature_high from ylcx_spider_battery message
 *
 * @return  charge temperature high
 */
static inline int8_t mavlink_msg_ylcx_spider_battery_get_in_temperature_high(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  19);
}

/**
 * @brief Get field in_temperature_low from ylcx_spider_battery message
 *
 * @return  charge temperature low
 */
static inline int8_t mavlink_msg_ylcx_spider_battery_get_in_temperature_low(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  20);
}

/**
 * @brief Get field out_voltage_high from ylcx_spider_battery message
 *
 * @return  out voltage high
 */
static inline int8_t mavlink_msg_ylcx_spider_battery_get_out_voltage_high(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  21);
}

/**
 * @brief Get field out_voltage_low from ylcx_spider_battery message
 *
 * @return  out voltage low
 */
static inline int8_t mavlink_msg_ylcx_spider_battery_get_out_voltage_low(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  22);
}

/**
 * @brief Get field out_current_high from ylcx_spider_battery message
 *
 * @return  out current high
 */
static inline int8_t mavlink_msg_ylcx_spider_battery_get_out_current_high(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  23);
}

/**
 * @brief Get field out_temperature_high from ylcx_spider_battery message
 *
 * @return  out temperature high
 */
static inline int8_t mavlink_msg_ylcx_spider_battery_get_out_temperature_high(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  24);
}

/**
 * @brief Get field out_temperature_low from ylcx_spider_battery message
 *
 * @return  out temperature low
 */
static inline int8_t mavlink_msg_ylcx_spider_battery_get_out_temperature_low(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  25);
}

/**
 * @brief Decode a ylcx_spider_battery message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_spider_battery C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_spider_battery_decode(const mavlink_message_t* msg, mavlink_ylcx_spider_battery_t* ylcx_spider_battery)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_spider_battery->voltage = mavlink_msg_ylcx_spider_battery_get_voltage(msg);
    ylcx_spider_battery->current = mavlink_msg_ylcx_spider_battery_get_current(msg);
    ylcx_spider_battery->temperature = mavlink_msg_ylcx_spider_battery_get_temperature(msg);
    ylcx_spider_battery->battery_remaining = mavlink_msg_ylcx_spider_battery_get_battery_remaining(msg);
    ylcx_spider_battery->id = mavlink_msg_ylcx_spider_battery_get_id(msg);
    ylcx_spider_battery->type = mavlink_msg_ylcx_spider_battery_get_type(msg);
    ylcx_spider_battery->in_voltage_high = mavlink_msg_ylcx_spider_battery_get_in_voltage_high(msg);
    ylcx_spider_battery->in_voltage_low = mavlink_msg_ylcx_spider_battery_get_in_voltage_low(msg);
    ylcx_spider_battery->in_current_high = mavlink_msg_ylcx_spider_battery_get_in_current_high(msg);
    ylcx_spider_battery->in_temperature_high = mavlink_msg_ylcx_spider_battery_get_in_temperature_high(msg);
    ylcx_spider_battery->in_temperature_low = mavlink_msg_ylcx_spider_battery_get_in_temperature_low(msg);
    ylcx_spider_battery->out_voltage_high = mavlink_msg_ylcx_spider_battery_get_out_voltage_high(msg);
    ylcx_spider_battery->out_voltage_low = mavlink_msg_ylcx_spider_battery_get_out_voltage_low(msg);
    ylcx_spider_battery->out_current_high = mavlink_msg_ylcx_spider_battery_get_out_current_high(msg);
    ylcx_spider_battery->out_temperature_high = mavlink_msg_ylcx_spider_battery_get_out_temperature_high(msg);
    ylcx_spider_battery->out_temperature_low = mavlink_msg_ylcx_spider_battery_get_out_temperature_low(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN? msg->len : MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN;
        memset(ylcx_spider_battery, 0, MAVLINK_MSG_ID_YLCX_SPIDER_BATTERY_LEN);
    memcpy(ylcx_spider_battery, _MAV_PAYLOAD(msg), len);
#endif
}
