#pragma once
// MESSAGE YLCX_UWB_RAW_INT PACKING

#define MAVLINK_MSG_ID_YLCX_UWB_RAW_INT 54312


typedef struct __mavlink_ylcx_uwb_raw_int_t {
 int32_t x; /*<  */
 int32_t y; /*<  */
 uint32_t x_acc; /*<  */
 uint32_t y_acc; /*<  */
 uint32_t x_hdg_acc; /*<  */
 uint32_t y_hdg_acc; /*<  */
 int32_t lat; /*<  */
 int32_t lon; /*<  */
 uint16_t x_ep; /*<  */
 uint16_t y_ep; /*<  */
 uint16_t velo; /*<  */
 uint16_t yaw; /*<  */
 uint8_t x1_vec; /*<  m/s*/
 uint8_t y1_vec; /*<  m/s*/
} mavlink_ylcx_uwb_raw_int_t;

#define MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN 42
#define MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN 42
#define MAVLINK_MSG_ID_54312_LEN 42
#define MAVLINK_MSG_ID_54312_MIN_LEN 42

#define MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_CRC 52
#define MAVLINK_MSG_ID_54312_CRC 52



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_UWB_RAW_INT { \
    54312, \
    "YLCX_UWB_RAW_INT", \
    14, \
    {  { "x", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_ylcx_uwb_raw_int_t, x) }, \
         { "y", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_ylcx_uwb_raw_int_t, y) }, \
         { "x_ep", NULL, MAVLINK_TYPE_UINT16_T, 0, 32, offsetof(mavlink_ylcx_uwb_raw_int_t, x_ep) }, \
         { "y_ep", NULL, MAVLINK_TYPE_UINT16_T, 0, 34, offsetof(mavlink_ylcx_uwb_raw_int_t, y_ep) }, \
         { "x_acc", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_ylcx_uwb_raw_int_t, x_acc) }, \
         { "y_acc", NULL, MAVLINK_TYPE_UINT32_T, 0, 12, offsetof(mavlink_ylcx_uwb_raw_int_t, y_acc) }, \
         { "x_hdg_acc", NULL, MAVLINK_TYPE_UINT32_T, 0, 16, offsetof(mavlink_ylcx_uwb_raw_int_t, x_hdg_acc) }, \
         { "y_hdg_acc", NULL, MAVLINK_TYPE_UINT32_T, 0, 20, offsetof(mavlink_ylcx_uwb_raw_int_t, y_hdg_acc) }, \
         { "lat", NULL, MAVLINK_TYPE_INT32_T, 0, 24, offsetof(mavlink_ylcx_uwb_raw_int_t, lat) }, \
         { "lon", NULL, MAVLINK_TYPE_INT32_T, 0, 28, offsetof(mavlink_ylcx_uwb_raw_int_t, lon) }, \
         { "velo", NULL, MAVLINK_TYPE_UINT16_T, 0, 36, offsetof(mavlink_ylcx_uwb_raw_int_t, velo) }, \
         { "yaw", NULL, MAVLINK_TYPE_UINT16_T, 0, 38, offsetof(mavlink_ylcx_uwb_raw_int_t, yaw) }, \
         { "x1_vec", NULL, MAVLINK_TYPE_UINT8_T, 0, 40, offsetof(mavlink_ylcx_uwb_raw_int_t, x1_vec) }, \
         { "y1_vec", NULL, MAVLINK_TYPE_UINT8_T, 0, 41, offsetof(mavlink_ylcx_uwb_raw_int_t, y1_vec) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_UWB_RAW_INT { \
    "YLCX_UWB_RAW_INT", \
    14, \
    {  { "x", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_ylcx_uwb_raw_int_t, x) }, \
         { "y", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_ylcx_uwb_raw_int_t, y) }, \
         { "x_ep", NULL, MAVLINK_TYPE_UINT16_T, 0, 32, offsetof(mavlink_ylcx_uwb_raw_int_t, x_ep) }, \
         { "y_ep", NULL, MAVLINK_TYPE_UINT16_T, 0, 34, offsetof(mavlink_ylcx_uwb_raw_int_t, y_ep) }, \
         { "x_acc", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_ylcx_uwb_raw_int_t, x_acc) }, \
         { "y_acc", NULL, MAVLINK_TYPE_UINT32_T, 0, 12, offsetof(mavlink_ylcx_uwb_raw_int_t, y_acc) }, \
         { "x_hdg_acc", NULL, MAVLINK_TYPE_UINT32_T, 0, 16, offsetof(mavlink_ylcx_uwb_raw_int_t, x_hdg_acc) }, \
         { "y_hdg_acc", NULL, MAVLINK_TYPE_UINT32_T, 0, 20, offsetof(mavlink_ylcx_uwb_raw_int_t, y_hdg_acc) }, \
         { "lat", NULL, MAVLINK_TYPE_INT32_T, 0, 24, offsetof(mavlink_ylcx_uwb_raw_int_t, lat) }, \
         { "lon", NULL, MAVLINK_TYPE_INT32_T, 0, 28, offsetof(mavlink_ylcx_uwb_raw_int_t, lon) }, \
         { "velo", NULL, MAVLINK_TYPE_UINT16_T, 0, 36, offsetof(mavlink_ylcx_uwb_raw_int_t, velo) }, \
         { "yaw", NULL, MAVLINK_TYPE_UINT16_T, 0, 38, offsetof(mavlink_ylcx_uwb_raw_int_t, yaw) }, \
         { "x1_vec", NULL, MAVLINK_TYPE_UINT8_T, 0, 40, offsetof(mavlink_ylcx_uwb_raw_int_t, x1_vec) }, \
         { "y1_vec", NULL, MAVLINK_TYPE_UINT8_T, 0, 41, offsetof(mavlink_ylcx_uwb_raw_int_t, y1_vec) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_uwb_raw_int message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param x  
 * @param y  
 * @param x_ep  
 * @param y_ep  
 * @param x_acc  
 * @param y_acc  
 * @param x_hdg_acc  
 * @param y_hdg_acc  
 * @param lat  
 * @param lon  
 * @param velo  
 * @param yaw  
 * @param x1_vec  m/s
 * @param y1_vec  m/s
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_uwb_raw_int_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int32_t x, int32_t y, uint16_t x_ep, uint16_t y_ep, uint32_t x_acc, uint32_t y_acc, uint32_t x_hdg_acc, uint32_t y_hdg_acc, int32_t lat, int32_t lon, uint16_t velo, uint16_t yaw, uint8_t x1_vec, uint8_t y1_vec)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN];
    _mav_put_int32_t(buf, 0, x);
    _mav_put_int32_t(buf, 4, y);
    _mav_put_uint32_t(buf, 8, x_acc);
    _mav_put_uint32_t(buf, 12, y_acc);
    _mav_put_uint32_t(buf, 16, x_hdg_acc);
    _mav_put_uint32_t(buf, 20, y_hdg_acc);
    _mav_put_int32_t(buf, 24, lat);
    _mav_put_int32_t(buf, 28, lon);
    _mav_put_uint16_t(buf, 32, x_ep);
    _mav_put_uint16_t(buf, 34, y_ep);
    _mav_put_uint16_t(buf, 36, velo);
    _mav_put_uint16_t(buf, 38, yaw);
    _mav_put_uint8_t(buf, 40, x1_vec);
    _mav_put_uint8_t(buf, 41, y1_vec);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN);
#else
    mavlink_ylcx_uwb_raw_int_t packet;
    packet.x = x;
    packet.y = y;
    packet.x_acc = x_acc;
    packet.y_acc = y_acc;
    packet.x_hdg_acc = x_hdg_acc;
    packet.y_hdg_acc = y_hdg_acc;
    packet.lat = lat;
    packet.lon = lon;
    packet.x_ep = x_ep;
    packet.y_ep = y_ep;
    packet.velo = velo;
    packet.yaw = yaw;
    packet.x1_vec = x1_vec;
    packet.y1_vec = y1_vec;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_UWB_RAW_INT;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_CRC);
}

/**
 * @brief Pack a ylcx_uwb_raw_int message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param x  
 * @param y  
 * @param x_ep  
 * @param y_ep  
 * @param x_acc  
 * @param y_acc  
 * @param x_hdg_acc  
 * @param y_hdg_acc  
 * @param lat  
 * @param lon  
 * @param velo  
 * @param yaw  
 * @param x1_vec  m/s
 * @param y1_vec  m/s
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_uwb_raw_int_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               int32_t x, int32_t y, uint16_t x_ep, uint16_t y_ep, uint32_t x_acc, uint32_t y_acc, uint32_t x_hdg_acc, uint32_t y_hdg_acc, int32_t lat, int32_t lon, uint16_t velo, uint16_t yaw, uint8_t x1_vec, uint8_t y1_vec)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN];
    _mav_put_int32_t(buf, 0, x);
    _mav_put_int32_t(buf, 4, y);
    _mav_put_uint32_t(buf, 8, x_acc);
    _mav_put_uint32_t(buf, 12, y_acc);
    _mav_put_uint32_t(buf, 16, x_hdg_acc);
    _mav_put_uint32_t(buf, 20, y_hdg_acc);
    _mav_put_int32_t(buf, 24, lat);
    _mav_put_int32_t(buf, 28, lon);
    _mav_put_uint16_t(buf, 32, x_ep);
    _mav_put_uint16_t(buf, 34, y_ep);
    _mav_put_uint16_t(buf, 36, velo);
    _mav_put_uint16_t(buf, 38, yaw);
    _mav_put_uint8_t(buf, 40, x1_vec);
    _mav_put_uint8_t(buf, 41, y1_vec);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN);
#else
    mavlink_ylcx_uwb_raw_int_t packet;
    packet.x = x;
    packet.y = y;
    packet.x_acc = x_acc;
    packet.y_acc = y_acc;
    packet.x_hdg_acc = x_hdg_acc;
    packet.y_hdg_acc = y_hdg_acc;
    packet.lat = lat;
    packet.lon = lon;
    packet.x_ep = x_ep;
    packet.y_ep = y_ep;
    packet.velo = velo;
    packet.yaw = yaw;
    packet.x1_vec = x1_vec;
    packet.y1_vec = y1_vec;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_UWB_RAW_INT;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN);
#endif
}

/**
 * @brief Pack a ylcx_uwb_raw_int message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param x  
 * @param y  
 * @param x_ep  
 * @param y_ep  
 * @param x_acc  
 * @param y_acc  
 * @param x_hdg_acc  
 * @param y_hdg_acc  
 * @param lat  
 * @param lon  
 * @param velo  
 * @param yaw  
 * @param x1_vec  m/s
 * @param y1_vec  m/s
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_uwb_raw_int_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int32_t x,int32_t y,uint16_t x_ep,uint16_t y_ep,uint32_t x_acc,uint32_t y_acc,uint32_t x_hdg_acc,uint32_t y_hdg_acc,int32_t lat,int32_t lon,uint16_t velo,uint16_t yaw,uint8_t x1_vec,uint8_t y1_vec)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN];
    _mav_put_int32_t(buf, 0, x);
    _mav_put_int32_t(buf, 4, y);
    _mav_put_uint32_t(buf, 8, x_acc);
    _mav_put_uint32_t(buf, 12, y_acc);
    _mav_put_uint32_t(buf, 16, x_hdg_acc);
    _mav_put_uint32_t(buf, 20, y_hdg_acc);
    _mav_put_int32_t(buf, 24, lat);
    _mav_put_int32_t(buf, 28, lon);
    _mav_put_uint16_t(buf, 32, x_ep);
    _mav_put_uint16_t(buf, 34, y_ep);
    _mav_put_uint16_t(buf, 36, velo);
    _mav_put_uint16_t(buf, 38, yaw);
    _mav_put_uint8_t(buf, 40, x1_vec);
    _mav_put_uint8_t(buf, 41, y1_vec);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN);
#else
    mavlink_ylcx_uwb_raw_int_t packet;
    packet.x = x;
    packet.y = y;
    packet.x_acc = x_acc;
    packet.y_acc = y_acc;
    packet.x_hdg_acc = x_hdg_acc;
    packet.y_hdg_acc = y_hdg_acc;
    packet.lat = lat;
    packet.lon = lon;
    packet.x_ep = x_ep;
    packet.y_ep = y_ep;
    packet.velo = velo;
    packet.yaw = yaw;
    packet.x1_vec = x1_vec;
    packet.y1_vec = y1_vec;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_UWB_RAW_INT;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_CRC);
}

/**
 * @brief Encode a ylcx_uwb_raw_int struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_uwb_raw_int C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_uwb_raw_int_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_uwb_raw_int_t* ylcx_uwb_raw_int)
{
    return mavlink_msg_ylcx_uwb_raw_int_pack(system_id, component_id, msg, ylcx_uwb_raw_int->x, ylcx_uwb_raw_int->y, ylcx_uwb_raw_int->x_ep, ylcx_uwb_raw_int->y_ep, ylcx_uwb_raw_int->x_acc, ylcx_uwb_raw_int->y_acc, ylcx_uwb_raw_int->x_hdg_acc, ylcx_uwb_raw_int->y_hdg_acc, ylcx_uwb_raw_int->lat, ylcx_uwb_raw_int->lon, ylcx_uwb_raw_int->velo, ylcx_uwb_raw_int->yaw, ylcx_uwb_raw_int->x1_vec, ylcx_uwb_raw_int->y1_vec);
}

/**
 * @brief Encode a ylcx_uwb_raw_int struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_uwb_raw_int C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_uwb_raw_int_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_uwb_raw_int_t* ylcx_uwb_raw_int)
{
    return mavlink_msg_ylcx_uwb_raw_int_pack_chan(system_id, component_id, chan, msg, ylcx_uwb_raw_int->x, ylcx_uwb_raw_int->y, ylcx_uwb_raw_int->x_ep, ylcx_uwb_raw_int->y_ep, ylcx_uwb_raw_int->x_acc, ylcx_uwb_raw_int->y_acc, ylcx_uwb_raw_int->x_hdg_acc, ylcx_uwb_raw_int->y_hdg_acc, ylcx_uwb_raw_int->lat, ylcx_uwb_raw_int->lon, ylcx_uwb_raw_int->velo, ylcx_uwb_raw_int->yaw, ylcx_uwb_raw_int->x1_vec, ylcx_uwb_raw_int->y1_vec);
}

/**
 * @brief Encode a ylcx_uwb_raw_int struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_uwb_raw_int C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_uwb_raw_int_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_uwb_raw_int_t* ylcx_uwb_raw_int)
{
    return mavlink_msg_ylcx_uwb_raw_int_pack_status(system_id, component_id, _status, msg,  ylcx_uwb_raw_int->x, ylcx_uwb_raw_int->y, ylcx_uwb_raw_int->x_ep, ylcx_uwb_raw_int->y_ep, ylcx_uwb_raw_int->x_acc, ylcx_uwb_raw_int->y_acc, ylcx_uwb_raw_int->x_hdg_acc, ylcx_uwb_raw_int->y_hdg_acc, ylcx_uwb_raw_int->lat, ylcx_uwb_raw_int->lon, ylcx_uwb_raw_int->velo, ylcx_uwb_raw_int->yaw, ylcx_uwb_raw_int->x1_vec, ylcx_uwb_raw_int->y1_vec);
}

/**
 * @brief Send a ylcx_uwb_raw_int message
 * @param chan MAVLink channel to send the message
 *
 * @param x  
 * @param y  
 * @param x_ep  
 * @param y_ep  
 * @param x_acc  
 * @param y_acc  
 * @param x_hdg_acc  
 * @param y_hdg_acc  
 * @param lat  
 * @param lon  
 * @param velo  
 * @param yaw  
 * @param x1_vec  m/s
 * @param y1_vec  m/s
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_uwb_raw_int_send(mavlink_channel_t chan, int32_t x, int32_t y, uint16_t x_ep, uint16_t y_ep, uint32_t x_acc, uint32_t y_acc, uint32_t x_hdg_acc, uint32_t y_hdg_acc, int32_t lat, int32_t lon, uint16_t velo, uint16_t yaw, uint8_t x1_vec, uint8_t y1_vec)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN];
    _mav_put_int32_t(buf, 0, x);
    _mav_put_int32_t(buf, 4, y);
    _mav_put_uint32_t(buf, 8, x_acc);
    _mav_put_uint32_t(buf, 12, y_acc);
    _mav_put_uint32_t(buf, 16, x_hdg_acc);
    _mav_put_uint32_t(buf, 20, y_hdg_acc);
    _mav_put_int32_t(buf, 24, lat);
    _mav_put_int32_t(buf, 28, lon);
    _mav_put_uint16_t(buf, 32, x_ep);
    _mav_put_uint16_t(buf, 34, y_ep);
    _mav_put_uint16_t(buf, 36, velo);
    _mav_put_uint16_t(buf, 38, yaw);
    _mav_put_uint8_t(buf, 40, x1_vec);
    _mav_put_uint8_t(buf, 41, y1_vec);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT, buf, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_CRC);
#else
    mavlink_ylcx_uwb_raw_int_t packet;
    packet.x = x;
    packet.y = y;
    packet.x_acc = x_acc;
    packet.y_acc = y_acc;
    packet.x_hdg_acc = x_hdg_acc;
    packet.y_hdg_acc = y_hdg_acc;
    packet.lat = lat;
    packet.lon = lon;
    packet.x_ep = x_ep;
    packet.y_ep = y_ep;
    packet.velo = velo;
    packet.yaw = yaw;
    packet.x1_vec = x1_vec;
    packet.y1_vec = y1_vec;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT, (const char *)&packet, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_CRC);
#endif
}

/**
 * @brief Send a ylcx_uwb_raw_int message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_uwb_raw_int_send_struct(mavlink_channel_t chan, const mavlink_ylcx_uwb_raw_int_t* ylcx_uwb_raw_int)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_uwb_raw_int_send(chan, ylcx_uwb_raw_int->x, ylcx_uwb_raw_int->y, ylcx_uwb_raw_int->x_ep, ylcx_uwb_raw_int->y_ep, ylcx_uwb_raw_int->x_acc, ylcx_uwb_raw_int->y_acc, ylcx_uwb_raw_int->x_hdg_acc, ylcx_uwb_raw_int->y_hdg_acc, ylcx_uwb_raw_int->lat, ylcx_uwb_raw_int->lon, ylcx_uwb_raw_int->velo, ylcx_uwb_raw_int->yaw, ylcx_uwb_raw_int->x1_vec, ylcx_uwb_raw_int->y1_vec);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT, (const char *)ylcx_uwb_raw_int, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_uwb_raw_int_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int32_t x, int32_t y, uint16_t x_ep, uint16_t y_ep, uint32_t x_acc, uint32_t y_acc, uint32_t x_hdg_acc, uint32_t y_hdg_acc, int32_t lat, int32_t lon, uint16_t velo, uint16_t yaw, uint8_t x1_vec, uint8_t y1_vec)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int32_t(buf, 0, x);
    _mav_put_int32_t(buf, 4, y);
    _mav_put_uint32_t(buf, 8, x_acc);
    _mav_put_uint32_t(buf, 12, y_acc);
    _mav_put_uint32_t(buf, 16, x_hdg_acc);
    _mav_put_uint32_t(buf, 20, y_hdg_acc);
    _mav_put_int32_t(buf, 24, lat);
    _mav_put_int32_t(buf, 28, lon);
    _mav_put_uint16_t(buf, 32, x_ep);
    _mav_put_uint16_t(buf, 34, y_ep);
    _mav_put_uint16_t(buf, 36, velo);
    _mav_put_uint16_t(buf, 38, yaw);
    _mav_put_uint8_t(buf, 40, x1_vec);
    _mav_put_uint8_t(buf, 41, y1_vec);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT, buf, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_CRC);
#else
    mavlink_ylcx_uwb_raw_int_t *packet = (mavlink_ylcx_uwb_raw_int_t *)msgbuf;
    packet->x = x;
    packet->y = y;
    packet->x_acc = x_acc;
    packet->y_acc = y_acc;
    packet->x_hdg_acc = x_hdg_acc;
    packet->y_hdg_acc = y_hdg_acc;
    packet->lat = lat;
    packet->lon = lon;
    packet->x_ep = x_ep;
    packet->y_ep = y_ep;
    packet->velo = velo;
    packet->yaw = yaw;
    packet->x1_vec = x1_vec;
    packet->y1_vec = y1_vec;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT, (const char *)packet, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_MIN_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_UWB_RAW_INT UNPACKING


/**
 * @brief Get field x from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline int32_t mavlink_msg_ylcx_uwb_raw_int_get_x(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  0);
}

/**
 * @brief Get field y from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline int32_t mavlink_msg_ylcx_uwb_raw_int_get_y(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  4);
}

/**
 * @brief Get field x_ep from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline uint16_t mavlink_msg_ylcx_uwb_raw_int_get_x_ep(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  32);
}

/**
 * @brief Get field y_ep from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline uint16_t mavlink_msg_ylcx_uwb_raw_int_get_y_ep(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  34);
}

/**
 * @brief Get field x_acc from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline uint32_t mavlink_msg_ylcx_uwb_raw_int_get_x_acc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  8);
}

/**
 * @brief Get field y_acc from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline uint32_t mavlink_msg_ylcx_uwb_raw_int_get_y_acc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  12);
}

/**
 * @brief Get field x_hdg_acc from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline uint32_t mavlink_msg_ylcx_uwb_raw_int_get_x_hdg_acc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  16);
}

/**
 * @brief Get field y_hdg_acc from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline uint32_t mavlink_msg_ylcx_uwb_raw_int_get_y_hdg_acc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  20);
}

/**
 * @brief Get field lat from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline int32_t mavlink_msg_ylcx_uwb_raw_int_get_lat(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  24);
}

/**
 * @brief Get field lon from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline int32_t mavlink_msg_ylcx_uwb_raw_int_get_lon(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  28);
}

/**
 * @brief Get field velo from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline uint16_t mavlink_msg_ylcx_uwb_raw_int_get_velo(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  36);
}

/**
 * @brief Get field yaw from ylcx_uwb_raw_int message
 *
 * @return  
 */
static inline uint16_t mavlink_msg_ylcx_uwb_raw_int_get_yaw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  38);
}

/**
 * @brief Get field x1_vec from ylcx_uwb_raw_int message
 *
 * @return  m/s
 */
static inline uint8_t mavlink_msg_ylcx_uwb_raw_int_get_x1_vec(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  40);
}

/**
 * @brief Get field y1_vec from ylcx_uwb_raw_int message
 *
 * @return  m/s
 */
static inline uint8_t mavlink_msg_ylcx_uwb_raw_int_get_y1_vec(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  41);
}

/**
 * @brief Decode a ylcx_uwb_raw_int message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_uwb_raw_int C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_uwb_raw_int_decode(const mavlink_message_t* msg, mavlink_ylcx_uwb_raw_int_t* ylcx_uwb_raw_int)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_uwb_raw_int->x = mavlink_msg_ylcx_uwb_raw_int_get_x(msg);
    ylcx_uwb_raw_int->y = mavlink_msg_ylcx_uwb_raw_int_get_y(msg);
    ylcx_uwb_raw_int->x_acc = mavlink_msg_ylcx_uwb_raw_int_get_x_acc(msg);
    ylcx_uwb_raw_int->y_acc = mavlink_msg_ylcx_uwb_raw_int_get_y_acc(msg);
    ylcx_uwb_raw_int->x_hdg_acc = mavlink_msg_ylcx_uwb_raw_int_get_x_hdg_acc(msg);
    ylcx_uwb_raw_int->y_hdg_acc = mavlink_msg_ylcx_uwb_raw_int_get_y_hdg_acc(msg);
    ylcx_uwb_raw_int->lat = mavlink_msg_ylcx_uwb_raw_int_get_lat(msg);
    ylcx_uwb_raw_int->lon = mavlink_msg_ylcx_uwb_raw_int_get_lon(msg);
    ylcx_uwb_raw_int->x_ep = mavlink_msg_ylcx_uwb_raw_int_get_x_ep(msg);
    ylcx_uwb_raw_int->y_ep = mavlink_msg_ylcx_uwb_raw_int_get_y_ep(msg);
    ylcx_uwb_raw_int->velo = mavlink_msg_ylcx_uwb_raw_int_get_velo(msg);
    ylcx_uwb_raw_int->yaw = mavlink_msg_ylcx_uwb_raw_int_get_yaw(msg);
    ylcx_uwb_raw_int->x1_vec = mavlink_msg_ylcx_uwb_raw_int_get_x1_vec(msg);
    ylcx_uwb_raw_int->y1_vec = mavlink_msg_ylcx_uwb_raw_int_get_y1_vec(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN? msg->len : MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN;
        memset(ylcx_uwb_raw_int, 0, MAVLINK_MSG_ID_YLCX_UWB_RAW_INT_LEN);
    memcpy(ylcx_uwb_raw_int, _MAV_PAYLOAD(msg), len);
#endif
}
