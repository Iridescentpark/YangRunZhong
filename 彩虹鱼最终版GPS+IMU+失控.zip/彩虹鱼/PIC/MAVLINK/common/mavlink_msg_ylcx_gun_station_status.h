#pragma once
// MESSAGE YLCX_GUN_STATION_STATUS PACKING

#define MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS 54415


typedef struct __mavlink_ylcx_gun_station_status_t {
 float x_pos; /*<  left/right radius*/
 float y_pos; /*<  up/down radius*/
 float x_vel; /*<  radius/s*/
 float y_vel; /*<  radius/s*/
 float x_tor; /*<  nm*/
 float y_tor; /*<  nm*/
 float temp_mos; /*<  Degree Celsius*/
 float temp_coil; /*<  Degree Celsius*/
} mavlink_ylcx_gun_station_status_t;

#define MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN 32
#define MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN 32
#define MAVLINK_MSG_ID_54415_LEN 32
#define MAVLINK_MSG_ID_54415_MIN_LEN 32

#define MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_CRC 227
#define MAVLINK_MSG_ID_54415_CRC 227



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_YLCX_GUN_STATION_STATUS { \
    54415, \
    "YLCX_GUN_STATION_STATUS", \
    8, \
    {  { "x_pos", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ylcx_gun_station_status_t, x_pos) }, \
         { "y_pos", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_ylcx_gun_station_status_t, y_pos) }, \
         { "x_vel", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ylcx_gun_station_status_t, x_vel) }, \
         { "y_vel", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ylcx_gun_station_status_t, y_vel) }, \
         { "x_tor", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_ylcx_gun_station_status_t, x_tor) }, \
         { "y_tor", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_ylcx_gun_station_status_t, y_tor) }, \
         { "temp_mos", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_ylcx_gun_station_status_t, temp_mos) }, \
         { "temp_coil", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_ylcx_gun_station_status_t, temp_coil) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_YLCX_GUN_STATION_STATUS { \
    "YLCX_GUN_STATION_STATUS", \
    8, \
    {  { "x_pos", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_ylcx_gun_station_status_t, x_pos) }, \
         { "y_pos", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_ylcx_gun_station_status_t, y_pos) }, \
         { "x_vel", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ylcx_gun_station_status_t, x_vel) }, \
         { "y_vel", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ylcx_gun_station_status_t, y_vel) }, \
         { "x_tor", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_ylcx_gun_station_status_t, x_tor) }, \
         { "y_tor", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_ylcx_gun_station_status_t, y_tor) }, \
         { "temp_mos", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_ylcx_gun_station_status_t, temp_mos) }, \
         { "temp_coil", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_ylcx_gun_station_status_t, temp_coil) }, \
         } \
}
#endif

/**
 * @brief Pack a ylcx_gun_station_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param x_pos  left/right radius
 * @param y_pos  up/down radius
 * @param x_vel  radius/s
 * @param y_vel  radius/s
 * @param x_tor  nm
 * @param y_tor  nm
 * @param temp_mos  Degree Celsius
 * @param temp_coil  Degree Celsius
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_gun_station_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               float x_pos, float y_pos, float x_vel, float y_vel, float x_tor, float y_tor, float temp_mos, float temp_coil)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN];
    _mav_put_float(buf, 0, x_pos);
    _mav_put_float(buf, 4, y_pos);
    _mav_put_float(buf, 8, x_vel);
    _mav_put_float(buf, 12, y_vel);
    _mav_put_float(buf, 16, x_tor);
    _mav_put_float(buf, 20, y_tor);
    _mav_put_float(buf, 24, temp_mos);
    _mav_put_float(buf, 28, temp_coil);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN);
#else
    mavlink_ylcx_gun_station_status_t packet;
    packet.x_pos = x_pos;
    packet.y_pos = y_pos;
    packet.x_vel = x_vel;
    packet.y_vel = y_vel;
    packet.x_tor = x_tor;
    packet.y_tor = y_tor;
    packet.temp_mos = temp_mos;
    packet.temp_coil = temp_coil;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_CRC);
}

/**
 * @brief Pack a ylcx_gun_station_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param x_pos  left/right radius
 * @param y_pos  up/down radius
 * @param x_vel  radius/s
 * @param y_vel  radius/s
 * @param x_tor  nm
 * @param y_tor  nm
 * @param temp_mos  Degree Celsius
 * @param temp_coil  Degree Celsius
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_gun_station_status_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               float x_pos, float y_pos, float x_vel, float y_vel, float x_tor, float y_tor, float temp_mos, float temp_coil)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN];
    _mav_put_float(buf, 0, x_pos);
    _mav_put_float(buf, 4, y_pos);
    _mav_put_float(buf, 8, x_vel);
    _mav_put_float(buf, 12, y_vel);
    _mav_put_float(buf, 16, x_tor);
    _mav_put_float(buf, 20, y_tor);
    _mav_put_float(buf, 24, temp_mos);
    _mav_put_float(buf, 28, temp_coil);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN);
#else
    mavlink_ylcx_gun_station_status_t packet;
    packet.x_pos = x_pos;
    packet.y_pos = y_pos;
    packet.x_vel = x_vel;
    packet.y_vel = y_vel;
    packet.x_tor = x_tor;
    packet.y_tor = y_tor;
    packet.temp_mos = temp_mos;
    packet.temp_coil = temp_coil;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN);
#endif
}

/**
 * @brief Pack a ylcx_gun_station_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param x_pos  left/right radius
 * @param y_pos  up/down radius
 * @param x_vel  radius/s
 * @param y_vel  radius/s
 * @param x_tor  nm
 * @param y_tor  nm
 * @param temp_mos  Degree Celsius
 * @param temp_coil  Degree Celsius
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ylcx_gun_station_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   float x_pos,float y_pos,float x_vel,float y_vel,float x_tor,float y_tor,float temp_mos,float temp_coil)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN];
    _mav_put_float(buf, 0, x_pos);
    _mav_put_float(buf, 4, y_pos);
    _mav_put_float(buf, 8, x_vel);
    _mav_put_float(buf, 12, y_vel);
    _mav_put_float(buf, 16, x_tor);
    _mav_put_float(buf, 20, y_tor);
    _mav_put_float(buf, 24, temp_mos);
    _mav_put_float(buf, 28, temp_coil);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN);
#else
    mavlink_ylcx_gun_station_status_t packet;
    packet.x_pos = x_pos;
    packet.y_pos = y_pos;
    packet.x_vel = x_vel;
    packet.y_vel = y_vel;
    packet.x_tor = x_tor;
    packet.y_tor = y_tor;
    packet.temp_mos = temp_mos;
    packet.temp_coil = temp_coil;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_CRC);
}

/**
 * @brief Encode a ylcx_gun_station_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_gun_station_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_gun_station_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ylcx_gun_station_status_t* ylcx_gun_station_status)
{
    return mavlink_msg_ylcx_gun_station_status_pack(system_id, component_id, msg, ylcx_gun_station_status->x_pos, ylcx_gun_station_status->y_pos, ylcx_gun_station_status->x_vel, ylcx_gun_station_status->y_vel, ylcx_gun_station_status->x_tor, ylcx_gun_station_status->y_tor, ylcx_gun_station_status->temp_mos, ylcx_gun_station_status->temp_coil);
}

/**
 * @brief Encode a ylcx_gun_station_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_gun_station_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_gun_station_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ylcx_gun_station_status_t* ylcx_gun_station_status)
{
    return mavlink_msg_ylcx_gun_station_status_pack_chan(system_id, component_id, chan, msg, ylcx_gun_station_status->x_pos, ylcx_gun_station_status->y_pos, ylcx_gun_station_status->x_vel, ylcx_gun_station_status->y_vel, ylcx_gun_station_status->x_tor, ylcx_gun_station_status->y_tor, ylcx_gun_station_status->temp_mos, ylcx_gun_station_status->temp_coil);
}

/**
 * @brief Encode a ylcx_gun_station_status struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param ylcx_gun_station_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ylcx_gun_station_status_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_ylcx_gun_station_status_t* ylcx_gun_station_status)
{
    return mavlink_msg_ylcx_gun_station_status_pack_status(system_id, component_id, _status, msg,  ylcx_gun_station_status->x_pos, ylcx_gun_station_status->y_pos, ylcx_gun_station_status->x_vel, ylcx_gun_station_status->y_vel, ylcx_gun_station_status->x_tor, ylcx_gun_station_status->y_tor, ylcx_gun_station_status->temp_mos, ylcx_gun_station_status->temp_coil);
}

/**
 * @brief Send a ylcx_gun_station_status message
 * @param chan MAVLink channel to send the message
 *
 * @param x_pos  left/right radius
 * @param y_pos  up/down radius
 * @param x_vel  radius/s
 * @param y_vel  radius/s
 * @param x_tor  nm
 * @param y_tor  nm
 * @param temp_mos  Degree Celsius
 * @param temp_coil  Degree Celsius
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ylcx_gun_station_status_send(mavlink_channel_t chan, float x_pos, float y_pos, float x_vel, float y_vel, float x_tor, float y_tor, float temp_mos, float temp_coil)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN];
    _mav_put_float(buf, 0, x_pos);
    _mav_put_float(buf, 4, y_pos);
    _mav_put_float(buf, 8, x_vel);
    _mav_put_float(buf, 12, y_vel);
    _mav_put_float(buf, 16, x_tor);
    _mav_put_float(buf, 20, y_tor);
    _mav_put_float(buf, 24, temp_mos);
    _mav_put_float(buf, 28, temp_coil);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS, buf, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_CRC);
#else
    mavlink_ylcx_gun_station_status_t packet;
    packet.x_pos = x_pos;
    packet.y_pos = y_pos;
    packet.x_vel = x_vel;
    packet.y_vel = y_vel;
    packet.x_tor = x_tor;
    packet.y_tor = y_tor;
    packet.temp_mos = temp_mos;
    packet.temp_coil = temp_coil;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS, (const char *)&packet, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_CRC);
#endif
}

/**
 * @brief Send a ylcx_gun_station_status message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ylcx_gun_station_status_send_struct(mavlink_channel_t chan, const mavlink_ylcx_gun_station_status_t* ylcx_gun_station_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ylcx_gun_station_status_send(chan, ylcx_gun_station_status->x_pos, ylcx_gun_station_status->y_pos, ylcx_gun_station_status->x_vel, ylcx_gun_station_status->y_vel, ylcx_gun_station_status->x_tor, ylcx_gun_station_status->y_tor, ylcx_gun_station_status->temp_mos, ylcx_gun_station_status->temp_coil);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS, (const char *)ylcx_gun_station_status, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_CRC);
#endif
}

#if MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ylcx_gun_station_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  float x_pos, float y_pos, float x_vel, float y_vel, float x_tor, float y_tor, float temp_mos, float temp_coil)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_float(buf, 0, x_pos);
    _mav_put_float(buf, 4, y_pos);
    _mav_put_float(buf, 8, x_vel);
    _mav_put_float(buf, 12, y_vel);
    _mav_put_float(buf, 16, x_tor);
    _mav_put_float(buf, 20, y_tor);
    _mav_put_float(buf, 24, temp_mos);
    _mav_put_float(buf, 28, temp_coil);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS, buf, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_CRC);
#else
    mavlink_ylcx_gun_station_status_t *packet = (mavlink_ylcx_gun_station_status_t *)msgbuf;
    packet->x_pos = x_pos;
    packet->y_pos = y_pos;
    packet->x_vel = x_vel;
    packet->y_vel = y_vel;
    packet->x_tor = x_tor;
    packet->y_tor = y_tor;
    packet->temp_mos = temp_mos;
    packet->temp_coil = temp_coil;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS, (const char *)packet, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_MIN_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_CRC);
#endif
}
#endif

#endif

// MESSAGE YLCX_GUN_STATION_STATUS UNPACKING


/**
 * @brief Get field x_pos from ylcx_gun_station_status message
 *
 * @return  left/right radius
 */
static inline float mavlink_msg_ylcx_gun_station_status_get_x_pos(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Get field y_pos from ylcx_gun_station_status message
 *
 * @return  up/down radius
 */
static inline float mavlink_msg_ylcx_gun_station_status_get_y_pos(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field x_vel from ylcx_gun_station_status message
 *
 * @return  radius/s
 */
static inline float mavlink_msg_ylcx_gun_station_status_get_x_vel(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field y_vel from ylcx_gun_station_status message
 *
 * @return  radius/s
 */
static inline float mavlink_msg_ylcx_gun_station_status_get_y_vel(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Get field x_tor from ylcx_gun_station_status message
 *
 * @return  nm
 */
static inline float mavlink_msg_ylcx_gun_station_status_get_x_tor(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  16);
}

/**
 * @brief Get field y_tor from ylcx_gun_station_status message
 *
 * @return  nm
 */
static inline float mavlink_msg_ylcx_gun_station_status_get_y_tor(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  20);
}

/**
 * @brief Get field temp_mos from ylcx_gun_station_status message
 *
 * @return  Degree Celsius
 */
static inline float mavlink_msg_ylcx_gun_station_status_get_temp_mos(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  24);
}

/**
 * @brief Get field temp_coil from ylcx_gun_station_status message
 *
 * @return  Degree Celsius
 */
static inline float mavlink_msg_ylcx_gun_station_status_get_temp_coil(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  28);
}

/**
 * @brief Decode a ylcx_gun_station_status message into a struct
 *
 * @param msg The message to decode
 * @param ylcx_gun_station_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_ylcx_gun_station_status_decode(const mavlink_message_t* msg, mavlink_ylcx_gun_station_status_t* ylcx_gun_station_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ylcx_gun_station_status->x_pos = mavlink_msg_ylcx_gun_station_status_get_x_pos(msg);
    ylcx_gun_station_status->y_pos = mavlink_msg_ylcx_gun_station_status_get_y_pos(msg);
    ylcx_gun_station_status->x_vel = mavlink_msg_ylcx_gun_station_status_get_x_vel(msg);
    ylcx_gun_station_status->y_vel = mavlink_msg_ylcx_gun_station_status_get_y_vel(msg);
    ylcx_gun_station_status->x_tor = mavlink_msg_ylcx_gun_station_status_get_x_tor(msg);
    ylcx_gun_station_status->y_tor = mavlink_msg_ylcx_gun_station_status_get_y_tor(msg);
    ylcx_gun_station_status->temp_mos = mavlink_msg_ylcx_gun_station_status_get_temp_mos(msg);
    ylcx_gun_station_status->temp_coil = mavlink_msg_ylcx_gun_station_status_get_temp_coil(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN? msg->len : MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN;
        memset(ylcx_gun_station_status, 0, MAVLINK_MSG_ID_YLCX_GUN_STATION_STATUS_LEN);
    memcpy(ylcx_gun_station_status, _MAV_PAYLOAD(msg), len);
#endif
}
