#include "mavlinkconnect.h"
#include "stm32f10x.h"
#include "delay.h"
#include "Timer.h"
#include "COM3RS2321.h"	
#include "COM5RS2323.h"	
#include "GPS.h"
#include "FreeRTOS.h"
#include "task.h"
#include "RapidityControl.h"
#include "mavlink_e.h"
#include "math.h"
#include "Temperature.h"
#include "stmflash.h"
#include "COM2RS4852.h"	
#include "COM1RS4851.h"
#include "propeller.h"
#include "rudder.h"
#include "math.h"
#include <stdarg.h> 
#include <stdlib.h>
#include "COM4RS2322.h"	
#include "Trace.h"
#include "COM6CAN.h"
#include "shipstate.h"
#include "rtl.h"
//���ͺ������� MSG ID 44;����HOME�� MSG ID 75;д�뺽�� MSG  ID 73;�����ȡ���� MSG ID 51;
//�����ȡ�б� MSG ID 43;ȷ�����̽��� MSG ID 47
u32 latx,longx;
extern u16 MavBuf[];
GPS_YAW_INT gpsyaw;
TYPES sys_type;
MISSION mission;
REQUST datarequst;
CONTROL control;
PARAM param;
u16 P = 0;
u16 i;
u8 b_id = 1;
uint16_t voltages1[1];
uint16_t voltages2[1];
unsigned int Check;
unsigned int ReceiveTime;
mavlink_message_t r_msg;//���յ������� 
mavlink_status_t b;//״̬	
mavlink_mission_request_list_t mission_request_list;//�����б���ѯ 43
mavlink_mission_count_t mission_count_t;//��ѯ������� 44
mavlink_mission_request_int_t mission_request_int;//���󺽵����� 51
mavlink_mission_item_int_t mission_item_int;//���ͺ������� 73
mavlink_mission_ack_t mission_ack;//�������Ӧ�� 47	
mavlink_set_mode_t set_mode;//ģʽ�л� 11
mavlink_heartbeat_t heartbeat;//������ 0
mavlink_ylcx_vehicle_parameter_t ylcx_vehicle_parameter;//����д�뷢�� 54310
mavlink_ylcx_rc_channels_raw_t rc_channels_raw;//�ݿ�̨ң�� 54307
mavlink_ylcx_ros_channels_raw_t ros_channels_raw;//ROS���� 54313
mavlink_ylcx_execute_algo_t execute_algo;//ʵ��ģʽ
mavlink_ylcx_rpm_speed_raw_t rpm_speed_raw;
mavlink_command_long_t command_long;
mavlink_manual_control_t manual_control;
mavlink_param_set_t param_set;
mavlink_param_request_list_t param_request_list;
mavlink_param_request_read_t request_read;
mavlink_raw_rpm_t raw_rpm;
mavlink_ylcx_vehicle_status_t vehicle_status;
/*******************����������*****************************************************ͨ��*/
void mavlink_heartbeats()//����������
{
	if(control.arm == 1.0)		
	{		
		sys_type.base_mode |= MAV_MODE_FLAG_SAFETY_ARMED;
		sys_type.base_mode |= MAV_MODE_FLAG_CUSTOM_MODE_ENABLED;
	}
							
	if(control.arm == 0)		
	{		
		sys_type.base_mode = 1;		
	}
	mavlink_msg_heartbeat_send(MAVLINK_COMM_1 ,MAV_TYPE_YLCX_1300 ,21 ,sys_type.base_mode,sys_type.cus_mode,MAV_STATE_ACTIVE );	
}
/*******************GPS���ݷ���*****************************************************ͨ��*/
void mavlink_gpsdata_send(void)
{
	mavlink_msg_gps_raw_int_send(
	MAVLINK_COMM_1,
	gpsx.utc.hour*10000+gpsx.utc.min*100+gpsx.utc.sec,GPS_FIX_TYPE_3D_FIX,//UTCʱ��//��λģʽ
	(u32)gpsx.latitude,//����
	(u32)gpsx.longitude,//γ��
	(u32)gpsx.altitude,//����
	(u16)gpsx.hdop,//�߶Ⱦ���
	(u16)gpsx.vdop,//�ٶȾ���
	(u16)gpsx.speed,//����
	(u16)gpsx.yaw,//����
	(u8)(gpsx.svnum+gpsx.posslnum+gpsx.rusnum),//��������
	(u32)gpsx.slmsg,//��������
	0,
	0,
	0,
	0,
	0
	);
	
}
/*******************��̬���ݷ���*****************************************************ͨ��*/
void attitude_send(void)
{
	mavlink_msg_attitude_send(MAVLINK_COMM_1,1,yaw_roll,yaw_pitch,yaw_imu,0,0,0);//������̬����
}
/*******************������ݷ���*****************************************************ͨ��*/
void mavlink_bettery_send()
{
	//1300��ط���
//	mavlink_msg_battery_status_send(MAVLINK_COMM_1,1,MAV_YLCX_TYPE_BATTERY,MAV_BATTERY_TYPE_LIPO,temper*10,0,Current1300,-1,-1,Soc1300,0,0,0,0,0);
	//2400��أ�485������
	mavlink_msg_battery_status_send(MAVLINK_COMM_1,1,MAV_YLCX_TYPE_BATTERY,MAV_BATTERY_TYPE_LIPO,temper*10,voltages1,(int16_t)Current1,-1,-1,(int8_t)Soc1,0,0,0,0,0);
	mavlink_msg_battery_status_send(MAVLINK_COMM_1,2,MAV_YLCX_TYPE_BATTERY,MAV_BATTERY_TYPE_LIPO,temper*10,voltages2,(int16_t)Current2,-1,-1,(int8_t)Soc2,0,0,0,0,0);
	//2400��أ�CAN������
//	mavlink_msg_battery_status_send(MAVLINK_COMM_1,1,MAV_YLCX_TYPE_BATTERY,MAV_BATTERY_TYPE_LIPO,temper*10,0,(int16_t)current1,-1,-1,(int8_t)remaining2,0,0,0,0,0);
//	mavlink_msg_battery_status_send(MAVLINK_COMM_1,2,MAV_YLCX_TYPE_BATTERY,MAV_BATTERY_TYPE_LIPO,temper*10,0,(int16_t)current2,-1,-1,(int8_t)remaining2,0,0,0,0,0);
	
}

/*******************״̬���ݷ���*****************************************************ͨ��*/
void mavlink_status_send()
{
	mavlink_msg_ylcx_vehicle_status_send(MAVLINK_COMM_1,leak,0,temper/10);
}
/*******************ѭ�����ݷ���*****************************************************ͨ��*/
void l1_distance_send(void)
{
	mavlink_msg_ylcx_l1_info_send(MAVLINK_COMM_1,real_dis,Angle_next,0,0);
}
/*******************�����������ݷ���*****************************************************ͨ��*/
void mission_current_send(void)
{
	if(set_mode.custom_mode == 15)
	{
		if(jug == 1)
		{
			mavlink_msg_mission_item_reached_send(MAVLINK_COMM_1,R/8);
		}
			mavlink_msg_mission_current_send(MAVLINK_COMM_1,R/8,ar2[0],0,0);
	}
		
}

/*******************��λ����������*****************************************************ͨ��*/
void mavlink_connect()
{	
	if( COM5_RX_STA_packet == 1 )//COM5�ɼ�������
	{
	for(i=0;i<COM5_RX_CNT;i++)
	{
		if(MAVLINK_FRAMING_OK==mavlink_parse_char(MAVLINK_COMM_1,COM5_RX_BUF[i],&r_msg, &b))
		{
			switch(r_msg.msgid)
			{
				/*******************�յ�ID 76�����л�*******************************/
				
//				case MAVLINK_MSG_ID_COMMAND_LONG:					
//					mavlink_msg_command_long_decode(&r_msg,&command_long);				
//					control.arm = command_long.param1;						
//					mavlink_msg_command_ack_send(MAVLINK_COMM_1,MAV_MODE_FLAG_SAFETY_ARMED,MAV_RESULT_ACCEPTED,100,0,1,1);//�ظ�ACK					
//				break;
//					
				/*******************�յ�ID 11ģʽ�л�*******************************/
					
				case MAVLINK_MSG_ID_SET_MODE:					
					mavlink_msg_set_mode_decode(&r_msg,&set_mode);//���ձ��Ľ���
					switch(set_mode.custom_mode)
					{
						case 0:sys_type.base_mode |= MAV_MODE_MANUAL_DISARMED;break;//��ȡģʽ�л��ź�
						case 15:sys_type.base_mode |= MAV_MODE_GUIDED_DISARMED;break;
						case 10:sys_type.base_mode |= MAV_MODE_AUTO_DISARMED;break;						
					}
					sys_type.cus_mode = set_mode.custom_mode;
					mavlink_msg_mission_ack_send(MAVLINK_COMM_1,1,1,MAV_MISSION_ACCEPTED,MAV_MISSION_TYPE_MISSION);//����Ӧ���ź�				
				break;
				
				/*******************�յ�ID 43�����б���ѯ���� ����ID 44�������****************************/			
//				case MAVLINK_MSG_ID_MISSION_REQUEST_LIST:				
//					Read_StmFlash_Data(0x01A0,8,ar2);//��ȡeeprom��Ĵ洢����				
//					mavlink_msg_mission_count_send(MAVLINK_COMM_1,01,01,ar2[0],MAV_MISSION_TYPE_MISSION);				
//				break;	
//				
//				/*******************�յ�ID 51���󺽵����� ����ID 73��������*******************************/
//				
//				case MAVLINK_MSG_ID_MISSION_REQUEST_INT:					
//					mavlink_msg_mission_request_int_decode(&r_msg,&mission_request_int);//���ձ��Ľ���				
//					datarequst.seqr = mission_request_int.seq;//��ȡ��Ҫ��ѯ��������							
//					Read_StmFlash_Data(0x00+datarequst.seqr*8,8,ar);//��ȡeeprom��Ĵ洢����				
//					datarequst.lat_r = (u32)((ar[0]>>4)*pow(16,7)+(ar[0]&0x0F)*pow(16,6)+(ar[1]>>4)*pow(16,5)+(ar[1]&0x0F)*pow(16,4)+
//									(ar[2]>>4)*pow(16,3)+(ar[2]&0x0F)*pow(16,2)+(ar[3]>>4)*16+(ar[3]&0x0F));				
//					datarequst.lon_r = (u32)((ar[4]>>4)*pow(16,7)+(ar[4]&0x0F)*pow(16,6)+(ar[5]>>4)*pow(16,5)+(ar[5]&0x0F)*pow(16,4)+
//									(ar[6]>>4)*pow(16,3)+(ar[6]&0x0F)*pow(16,2)+(ar[7]>>4)*16+(ar[7]&0x0F));				
//					mavlink_msg_mission_item_int_send(
//					MAVLINK_COMM_1,
//					01,
//					01,
//					datarequst.seqr,
//					MAV_FRAME_GLOBAL,
//					MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,
//					1,
//					1,
//					0,
//					0,
//					0,
//					0,
//					datarequst.lat_r,
//					datarequst.lon_r,
//					0,
//					MAV_MISSION_TYPE_MISSION);				
//				break;	
//				
//				/*******************�յ�ID 44����д�뺽������ ����ID 51���󺽵�����*******************************/
//				case MAVLINK_MSG_ID_MISSION_COUNT:					
//					mavlink_msg_mission_count_decode(&r_msg,&mission_count_t);//��������				
//					mission.count = mission_count_t.count;//��ȡ��������							
//					if(mission.count<50)//����������С��120����д�룬���򱨾�
//					{					
//						eeprom_changecount();					
//						mavlink_msg_mission_request_int_send(MAVLINK_COMM_1,01,01,P,MAV_MISSION_TYPE_MISSION);					
//					}				
//					else					
//					{
//						mavlink_msg_mission_ack_send(MAVLINK_COMM_1,1,1,MAV_MISSION_NO_SPACE,MAV_MISSION_TYPE_MISSION);
//					}				
//				break;
//				
//				/*******************�յ�ID 73�����յ��ĺ���������Ϣ*******************************/
//				case MAVLINK_MSG_ID_MISSION_ITEM_INT:					
//					mavlink_msg_mission_item_int_decode(&r_msg,&mission_item_int);//��������				
//					mission.lat_x = mission_item_int.x;//��ȡγ��				
//					mission.lon_y = mission_item_int.y;//��ȡ����								
//					mission.Sequence = mission_item_int.seq;//��ȡ�������
//					if(mission.Sequence == 0)
//					{
//						mission.lat_home = mission.lat_x;
//						mission.long_home = mission.lon_y;
//					}
//					else
//					{
//						MavBuf[0] = mission.lat_x>>16;
//						MavBuf[1] = mission.lat_x&0x0000ffff;
//						MavBuf[2] = mission.lon_y>>16;
//						MavBuf[3] = mission.lon_y&0x0000ffff;
//						eeprom_changepoint((mission.Sequence-1)*8);
//					}						
//									
//					P=mission.Sequence+1;//������ż�һ				
//					if(mission.Sequence<(mission.count-1))//����������С�ں���������������󣬷��������Ӧ��
//					{					
//						mavlink_msg_mission_request_int_send(MAVLINK_COMM_1,01,01,P,MAV_MISSION_TYPE_MISSION);//��������					
//					}
//					else
//					{					
//						mavlink_msg_mission_ack_send(MAVLINK_COMM_1,1,1,MAV_MISSION_ACCEPTED,MAV_MISSION_TYPE_MISSION);//���Ӧ��
//						P = 0;
//						R = 0;						
//					}				
//				break;
				
				/*******************�յ�ID 69�����յ��Ŀ�����Ϣ*******************************/
				case MAVLINK_MSG_ID_MANUAL_CONTROL:					
					mavlink_msg_manual_control_decode(&r_msg,&manual_control);	// ң�ر���
					Check = Timer5;
				break;
				/*******************�յ�ID 54313�����յ��Ŀ�����Ϣ*******************************/
//				case MAVLINK_MSG_ID_YLCX_ROS_CHANNELS_RAW:					
//					mavlink_msg_ylcx_ros_channels_raw_decode(&r_msg,&ros_channels_raw);				
//				break;
//				case MAVLINK_MSG_ID_RAW_RPM:
//					mavlink_msg_raw_rpm_decode(&r_msg,&raw_rpm);
//					if(raw_rpm.index == 0x00)
//					{
//						control.rpm1 = raw_rpm.frequency;
//					}
//					if(raw_rpm.index == 0x01)
//					{
//						control.rpm2 = raw_rpm.frequency;
//					}
//				break;
				/*******************�յ�ID 23 �����յ������ݲ���****************************************/					
//				case MAVLINK_MSG_ID_PARAM_SET:				
//					mavlink_msg_param_set_decode(&r_msg,&param_set);			
//					if((!strncmp(param_set.param_id,"WRC_DIST_P",sizeof(param_set.param_id))))
//					{
//						param.dist_p = param_set.param_value;
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_dist_p,param.dist_p,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if((!strncmp(param_set.param_id,"WRC_DIST_I",sizeof(param_set.param_id))))
//					{
//						param.dist_i = param_set.param_value;
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_dist_i,param.dist_i,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if((!strncmp(param_set.param_id,"WRC_DIST_D",sizeof(param_set.param_id))))
//					{
//						param.dist_d = param_set.param_value;
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_dist_d,param.dist_d,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if((!strncmp(param_set.param_id,"WRC_SPEED_P",sizeof(param_set.param_id))))
//					{
//						param.speed_p = param_set.param_value;
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_speed_p,param.speed_p,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if((!strncmp(param_set.param_id,"WRC_SPEED_I",sizeof(param_set.param_id))))
//					{
//						param.speed_i = param_set.param_value;
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_speed_i,param.speed_i,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if((!strncmp(param_set.param_id,"WRC_SPEED_D",sizeof(param_set.param_id))))
//					{
//						param.speed_d = param_set.param_value;
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_speed_d,param.speed_d,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if((!strncmp(param_set.param_id,"WRC_L1_P",sizeof(param_set.param_id))))
//					{
//						param.l1_p = param_set.param_value;
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_l1_p,param.l1_p,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if((!strncmp(param_set.param_id,"WRC_L1_I",sizeof(param_set.param_id))))
//					{
//						param.l1_i = param_set.param_value;						
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_l1_i,param.l1_i,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if((!strncmp(param_set.param_id,"WRC_L1_D",sizeof(param_set.param_id))))
//					{
//						param.l1_d = param_set.param_value;						
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_l1_d,param.l1_d,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					
//					if((!strncmp(param_set.param_id,"WP_RADIUS",sizeof(param_set.param_id))))
//					{
//						param.wp_radius = param_set.param_value;						
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wp_radius,param.wp_radius,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if((!strncmp(param_set.param_id,"WP_SPEED",sizeof(param_set.param_id))))
//					{
//						param.wp_speed = param_set.param_value;						
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wp_speed,param.wp_speed,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					
//					if((!strncmp(param_set.param_id,"WP_SPEED_MIN",sizeof(param_set.param_id))))
//					{
//						param.wp_min_speed = param_set.param_value;						
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wp_speed_min,param.wp_min_speed,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					
//					if((!strncmp(param_set.param_id,"CRUISE_SPEED",sizeof(param_set.param_id))))
//					{
//						param.cruise_speed = param_set.param_value;						
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,curise_speed,param.cruise_speed,MAV_PARAM_TYPE_REAL32,24,1);
//					}					
//					
//					if((!strncmp(param_set.param_id,"Steer_cog",sizeof(param_set.param_id))))
//					{
//						param.steer_cog = param_set.param_value;						
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,steer_cog,param.steer_cog,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					eeprom_changepar();
//					
//				break;
//				case MAVLINK_MSG_ID_PARAM_REQUEST_READ:
//					Read_StmFlash_Data(0x0190,8,ar4);//��ַ������ż��
//					Read_StmFlash_Data(0x0198,8,ar5);//��ַ������ż��
//					mavlink_msg_param_request_read_decode(&r_msg,&request_read);
//										
//					if(!strncmp(request_read.param_id,"WRC_DIST_P",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_dist_p,(float)ar4[0]/100,MAV_PARAM_TYPE_REAL32,24,1);
//						
//					}
//					if(!strncmp(request_read.param_id,"WRC_DIST_I",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_dist_i,(float)ar4[1]/100,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if(!strncmp(request_read.param_id,"WRC_DIST_D",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_dist_d,(float)ar4[2]/100,MAV_PARAM_TYPE_REAL32,24,1);
//						
//					}
//					if(!strncmp(request_read.param_id,"WRC_SPEED_P",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_speed_p,(float)ar4[3]/100,MAV_PARAM_TYPE_REAL32,24,1);
//						
//					}
//					if(!strncmp(request_read.param_id,"WRC_SPEED_I",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_speed_i,(float)ar4[4]/100,MAV_PARAM_TYPE_REAL32,24,1);
//						
//					}
//					if(!strncmp(request_read.param_id,"WRC_SPEED_D",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_speed_d,(float)ar4[5]/100,MAV_PARAM_TYPE_REAL32,24,1);
//						
//					}
//					if(!strncmp(request_read.param_id,"WRC_L1_P",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_l1_p,(float)ar4[6]/100,MAV_PARAM_TYPE_REAL32,24,1);
//						
//					}
//					if(!strncmp(request_read.param_id,"WRC_L1_I",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_l1_i,(float)ar4[7]/100,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if(!strncmp(request_read.param_id,"WRC_L1_D",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_l1_d,(float)ar5[0]/100,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					
//					if(!strncmp(request_read.param_id,"WP_RADIUS",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wp_radius,(float)ar5[1]/10,MAV_PARAM_TYPE_REAL32,24,1);
//						
//					}		
//					if(!strncmp(request_read.param_id,"WP_SPEED",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wp_speed,(float)ar5[2]/10,MAV_PARAM_TYPE_REAL32,24,1);
//						
//					}
//					if(!strncmp(request_read.param_id,"WP_SPEED_MIN",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,wp_speed_min,(float)ar5[3]/10,MAV_PARAM_TYPE_REAL32,24,1);
//						
//					}
//					if(!strncmp(request_read.param_id,"CRUISE_SPEED",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,curise_speed,(float)ar5[4]/10,MAV_PARAM_TYPE_REAL32,24,1);
//					}
//					if(!strncmp(request_read.param_id,"Steer_cog",sizeof(param_set.param_id)))
//					{
//						mavlink_msg_param_value_send(MAVLINK_COMM_1,steer_cog,(float)((ar5[5]<<8)+ar5[6]),MAV_PARAM_TYPE_REAL32,24,1);
//					}
//				break;
///*******************�յ�ID 21 ���Ͳ���****************************************/				
//				case MAVLINK_MSG_ID_PARAM_REQUEST_LIST:					
//						mavlink_msg_param_request_list_decode(&r_msg,&param_request_list);
//						if(param_request_list.target_system == 0x01)
//						{
//							Read_StmFlash_Data(0x0190,8,ar4);//��ַ������ż��
//							Read_StmFlash_Data(0x0198,8,ar5);//��ַ������ż��
//							
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_dist_p,(float)ar4[0]/100,MAV_PARAM_TYPE_REAL32,24,16);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_dist_i,(float)ar4[1]/100,MAV_PARAM_TYPE_REAL32,24,17);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_dist_d,(float)ar4[2]/100,MAV_PARAM_TYPE_REAL32,24,18);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_speed_p,(float)ar4[3]/100,MAV_PARAM_TYPE_REAL32,24,19);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_speed_i,(float)ar4[4]/100,MAV_PARAM_TYPE_REAL32,24,20);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_speed_d,(float)ar4[5]/100,MAV_PARAM_TYPE_REAL32,24,21);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_l1_p,(float)ar4[6]/100,MAV_PARAM_TYPE_REAL32,24,22);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_l1_i,(float)ar4[7]/100,MAV_PARAM_TYPE_REAL32,24,23);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wrc_l1_d,(float)ar5[0]/100,MAV_PARAM_TYPE_REAL32,24,24);
//							
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wp_radius,(float)ar5[1]/10,MAV_PARAM_TYPE_REAL32,24,14);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wp_speed,(float)ar5[2]/10,MAV_PARAM_TYPE_REAL32,24,13);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,wp_speed_min,(float)ar5[3]/10,MAV_PARAM_TYPE_REAL32,24,15);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,curise_speed,(float)ar5[4]/10,MAV_PARAM_TYPE_REAL32,24,3);
//							mavlink_msg_param_value_send(MAVLINK_COMM_1,steer_cog,(float)((ar5[5]<<8)+ar5[6]),MAV_PARAM_TYPE_REAL32,24,1);

//						}
//					
//					break;
				
				
			}  
		}   
	}  
	if(sys_type.cus_mode == 0)//ң��ģʽ��ȡ����
			{
				control.propeller1 = manual_control.y;//�������Ų���
				control.propeller2 = manual_control.z;//�������Ų���
			}
//			if(sys_type.cus_mode == 10)//�����״�ģʽ��ȡ����
//			{
//				control.propeller1 = ros_channels_raw.chan1_raw;//�������Ų���
//				control.propeller2 = ros_channels_raw.chan2_raw;//�������Ų���
//			}
			//���洬��ȡ����
//			control.propeller1 = manual_control.y;//�������Ų���
//			control.propeller2 = manual_control.r;//�������Ų���
			
			COM5_RX_STA = 0;	//�����´ν���
			COM5_RX_CNT = 0;	//�ں������㣻
			
		}//�������ݽ���
	ReceiveTime = Timer5 - Check;
}
//ѭ�����ݷ�������
void vTask_l1datasend(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			l1_distance_send();
			vTaskDelayUntil( &xLastWakeTime, ( 500 / portTICK_RATE_MS ) ); 
		}
}
//����״̬��������
void vTask_statussend(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			mavlink_status_send();
			vTaskDelayUntil( &xLastWakeTime, ( 500 / portTICK_RATE_MS ) ); 
		}
}
//���񺽵���ŷ�������
void vTask_missionsend(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			mission_current_send();
			vTaskDelayUntil( &xLastWakeTime, ( 1000 / portTICK_RATE_MS ) ); 
		}
}
//������ݷ�������
void vTask_betdatasend(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			mavlink_bettery_send();
			vTaskDelayUntil( &xLastWakeTime, ( 1000 / portTICK_RATE_MS ) ); 
		}
}
//��������������
void vTask_heartbeats(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			mavlink_heartbeats();
			vTaskDelayUntil( &xLastWakeTime, ( 1000 / portTICK_RATE_MS ) ); 
		}
}
//��λ��Ϣ��������
void vTask_gpsdatasend(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			mavlink_gpsdata_send();
			vTaskDelayUntil( &xLastWakeTime, ( 200 / portTICK_RATE_MS ) ); 	
		}
}
//��̬���ݷ�������
void vTask_attsend(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			attitude_send();
			vTaskDelayUntil( &xLastWakeTime, ( 200 / portTICK_RATE_MS ) ); 	
		}
}
//����λ����������
void vTask_pointget(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			mavlink_connect();
			vTaskDelayUntil( &xLastWakeTime, ( 100 / portTICK_RATE_MS ) ); 
		}
}
