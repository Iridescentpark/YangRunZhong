/************************************************************************/
//Ԫ������
//�������ذ��ͺţ�YLPICV2.1
//�������ݣ�
//          1������DS18B20��
//          2����������DS18B20��
/************************************************************************/
#include "Temperature.h"
#include "delay.h"
//void delay_us(u32 nus)
//{
//  volatile unsigned int num;
//  volatile unsigned int t; 
//  for (num = 0; num < nus; num++)
//  {
//    t = 11;
//    while (t != 0)
//    {
//      t--;
//    }
//  }
//}
//��λDS18B20
void DS18B20_Rst(unsigned char CHx)	   
{
	switch(CHx){
		case 1: { DS18B20_IO1_OUT(); DS18B20_DQ1_OUT = 0; delay_us(750); DS18B20_DQ1_OUT = 1; delay_us(15);}; break; //�����¶ȴ�����
		case 2: { DS18B20_IO2_OUT(); DS18B20_DQ2_OUT = 0; delay_us(750); DS18B20_DQ2_OUT = 1; delay_us(15);}; break; //�����¶ȴ�����DQ2
		case 3: { DS18B20_IO3_OUT(); DS18B20_DQ3_OUT = 0; delay_us(750); DS18B20_DQ3_OUT = 1; delay_us(15);}; break; //�����¶ȴ�����DQ3
		case 4: { DS18B20_IO4_OUT(); DS18B20_DQ4_OUT = 0; delay_us(750); DS18B20_DQ4_OUT = 1; delay_us(15);}; break; //�����¶ȴ�����DQ4
		default: break;
	}
}
//�ȴ�DS18B20�Ļ�Ӧ
//����1:δ��⵽DS18B20�Ĵ���
//����0:����
unsigned char DS18B20_Check(unsigned char CHx) 	   
{
	unsigned char retry=0;
	switch(CHx){
		case 1: { DS18B20_IO1_IN();	 while(DS18B20_DQ1_IN && retry<200) {retry++;delay_us(5);} }; break;//�����¶ȴ�����
		case 2: { DS18B20_IO2_IN();	 while(DS18B20_DQ2_IN && retry<200) {retry++;delay_us(5);} }; break;//�¶ȼ�2
		case 3: { DS18B20_IO3_IN();	 while(DS18B20_DQ3_IN && retry<200) {retry++;delay_us(5);} }; break;//�¶ȼ�3
		case 4: { DS18B20_IO4_IN();	 while(DS18B20_DQ4_IN && retry<200) {retry++;delay_us(5);} }; break;//�¶ȼ�4
		default: break;
	}
	if(retry>=200) return 1;
	else retry=0;
	switch(CHx){
		case 1: { while(!DS18B20_DQ1_IN && retry<240) {retry++;delay_us(1);} } break; //�����¶ȴ�����
		case 2: { while(!DS18B20_DQ2_IN && retry<240) {retry++;delay_us(1);} } break; //�¶ȼ�2
		case 3: { while(!DS18B20_DQ3_IN && retry<240) {retry++;delay_us(1);} } break; //�¶ȼ�3
		case 4: { while(!DS18B20_DQ4_IN && retry<240) {retry++;delay_us(1);} } break; //�¶ȼ�4
		default: break;
	}
	if(retry >= 240) return 1;    
	return 0;
}
//��DS18B20��ȡһ��λ
//����ֵ��1/0
unsigned char DS18B20_Read_Bit(unsigned char CHx) 	 
{
    unsigned char data;
	switch(CHx){
		case 1: { DS18B20_IO1_OUT(); DS18B20_DQ1_OUT=0; delay_us(2); DS18B20_DQ1_OUT=1; DS18B20_IO1_IN(); delay_us(12);
			      if(DS18B20_DQ1_IN)data=1; else data=0; delay_us(50); return data;} break; //�����¶ȴ���
		
		case 2: { DS18B20_IO2_OUT(); DS18B20_DQ2_OUT=0; delay_us(2); DS18B20_DQ2_OUT=1; DS18B20_IO2_IN(); delay_us(12);
			      if(DS18B20_DQ2_IN)data=1; else data=0; delay_us(50); return data; } break; 
		
		case 3: { DS18B20_IO3_OUT(); DS18B20_DQ3_OUT=0; delay_us(2); DS18B20_DQ3_OUT=1; DS18B20_IO3_IN(); delay_us(12);
			      if(DS18B20_DQ3_IN)data=1; else data=0; delay_us(50); return data; } break; //�����¶ȴ���

		case 4: { DS18B20_IO4_OUT(); DS18B20_DQ4_OUT=0; delay_us(2); DS18B20_DQ4_OUT=1; DS18B20_IO4_IN(); delay_us(12);
			      if(DS18B20_DQ4_IN)data=1; else data=0; delay_us(50); return data; } break; //�����¶ȴ���
		default: break;
	}
	
}
//��DS18B20��ȡһ���ֽ�
//����ֵ������������
unsigned char DS18B20_Read_Byte(unsigned char CHx)     
{        
    unsigned char i,j,dat;
    dat=0;
	for (i=1;i<=8;i++) 
	{
        j=DS18B20_Read_Bit(CHx);
        dat=(j<<7)|(dat>>1);
    }						    
    return dat;
}
//дһ���ֽڵ�DS18B20
//dat��Ҫд����ֽ�
void DS18B20_Write_Byte(unsigned char CHx, unsigned char dat)     
{             
	unsigned char j,testb;
	switch(CHx){
		case 1: {
			DS18B20_IO1_OUT();
			for (j=1;j<=8;j++) 
			{
				testb=dat&0x01;
				dat=dat>>1;
				if (testb) 
				{
					DS18B20_DQ1_OUT = 0;	// Write 1
					delay_us(2);                            
					DS18B20_DQ1_OUT = 1;
					delay_us(60);             
				}
				else 
				{
					DS18B20_DQ1_OUT = 0;	// Write 0
					delay_us(60);              
					DS18B20_DQ1_OUT = 1;
					delay_us(2);                          
				}
			}
		}; break; //�����¶ȴ���
		
		case 2: {
			DS18B20_IO2_OUT();
			for (j=1;j<=8;j++) 
			{
				testb=dat&0x01;
				dat=dat>>1;
				if (testb) 
				{
					DS18B20_DQ2_OUT = 0;	// Write 1
					delay_us(2);                            
					DS18B20_DQ2_OUT = 1;
					delay_us(60);             
				}
				else 
				{
					DS18B20_DQ2_OUT = 0;	// Write 0
					delay_us(60);              
					DS18B20_DQ2_OUT = 1;
					delay_us(2);                          
				}
			}
		}; break; //�����¶ȴ���
		
		case 3: {
			DS18B20_IO3_OUT();
			for (j=1;j<=8;j++) 
			{
				testb=dat&0x01;
				dat=dat>>1;
				if (testb) 
				{
					DS18B20_DQ3_OUT = 0;	// Write 1
					delay_us(2);                            
					DS18B20_DQ3_OUT = 1;
					delay_us(60);             
				}
				else 
				{
					DS18B20_DQ3_OUT = 0;	// Write 0
					delay_us(60);              
					DS18B20_DQ3_OUT = 1;
					delay_us(2);                          
				}
			}
		}; break; //�����¶ȴ���
		
		case 4: {
			DS18B20_IO4_OUT();
			for (j=1;j<=8;j++) 
			{
				testb=dat&0x01;
				dat=dat>>1;
				if (testb) 
				{
					DS18B20_DQ4_OUT = 0;	// Write 1
					delay_us(2);                            
					DS18B20_DQ4_OUT = 1;
					delay_us(60);             
				}
				else 
				{
					DS18B20_DQ4_OUT = 0;	// Write 0
					delay_us(60);              
					DS18B20_DQ4_OUT = 1;
					delay_us(2);                          
				}
			}
		}; break; //�����¶ȴ���
		
		default: break;
	}
}
 
//��ʼ�¶�ת��
void DS18B20_Start(unsigned char CHx) 
{   						               
    DS18B20_Rst(CHx);	   
	DS18B20_Check(CHx);	 
    DS18B20_Write_Byte(CHx, 0xcc);	// skip rom
    DS18B20_Write_Byte(CHx, 0x44);	// convert
} 

//��ʼ��DS18B20��IO�� DQ ͬʱ���DS�Ĵ���
//����1:������
//����0:����    	 
unsigned char DS18B20_Init(void)
{
	unsigned char check = 0;
 	GPIO_InitTypeDef  GPIO_InitStructure;
 	
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	 //ʹ��PORTG��ʱ�� 
	
 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		  
 	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);

 	GPIO_SetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15);    //���1

	DS18B20_Rst(1);DS18B20_Rst(2);DS18B20_Rst(3);DS18B20_Rst(4);

	if(DS18B20_Check(1) == 1) check = (check & 0x0E) ;      else check = (check & 0x0E)+ 1;
	if(DS18B20_Check(2) == 1) check = (check & 0x0D) + 2;   else check = (check & 0x0D);
	if(DS18B20_Check(3) == 1) check = (check & 0x0B) + 4;   else check = (check & 0x0B);
	if(DS18B20_Check(4) == 1) check = (check & 0x07) + 8;   else check = (check & 0x07);

	return check;//����4���¶ȴ������Ƿ�����
}  
//��ds18b20�õ��¶�ֵ
//���ȣ�0.1C
//����ֵ���¶�ֵ ��-55.0~125.0�� 
//chx 1~4
short DS18B20_Get_Temp(unsigned char CHx)
{
    unsigned char TL,TH;
	short tem,PorN = 0;	
    DS18B20_Start(CHx);
    DS18B20_Rst(CHx);
    DS18B20_Check(CHx);
    DS18B20_Write_Byte(CHx, 0xcc);	// skip rom
    DS18B20_Write_Byte(CHx, 0xbe);	// convert	    
    TL=DS18B20_Read_Byte(CHx); 	// LSB   
    TH=DS18B20_Read_Byte(CHx); 	// MSB  	    	  
    if(TH>7)
    {
        TH=~TH;
        TL=~TL; 
        PorN = -1;					//�¶�Ϊ��  
    }
    else
    {
        PorN = 1;				//�¶�Ϊ��	 
    }        
    tem=TH; 					//��ø߰�λ
    tem<<=8;    
    tem+=TL;					//��õװ�λ
    tem=(float)tem * 0.625 * PorN;		//ת��,�Ŵ�10������ȷ��С�����һλ��ԭϵ����0.0625          	
	return tem;
}















































