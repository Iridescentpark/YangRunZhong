#ifndef __MixConRelay_H
#define __MixConRelay_H

//#define	K1	PEout(0)//
//#define	K2	PEout(1)//
//#define	K3	PEout(2)//
//#define	K4	PEout(3)//
void MixControl(void);
void vTaskMix(void * pvParameters);	 				    
#endif

