#ifndef __Timer_H
#define __Timer_H
#include "stm32f10x.h"
#include "sys.h"
extern volatile unsigned long long FreeRTOSRunTimeTicks;
extern unsigned char Time1Count;    //Tim1����������־λ
extern unsigned char Time1Flag;      //��ֹ��ѭ�����ִ�еı�־λ
extern int vole_flag;
extern int vole2_flag;
extern int tick6_count;
extern int tick5_count;
extern int tick6_time;
extern int tick5_time;
extern unsigned int Timer5;
void TIM1_Init(u16 arr,u16 psc);

void TIM5_Init(u16 arr,u16 psc);
void TIM5_Set(void);

void TIM6_Init(u16 arr,u16 psc);
void TIM6_Set(void);

void TIM7_Init(u16 arr,u16 psc);
void TIM7_Set(unsigned char sta);

#endif

