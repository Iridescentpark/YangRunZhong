#ifndef __COM4RS2322_H
#define __COM4RS2322_H			

#include "stm32f10x.h"
#include <stdio.h>
#define USART3_MAX_RECV_LEN	22	//�����ջ����ֽ���
#define USART3_MAX_SEND_LEN	22	//����ͻ����ֽ���
extern unsigned char  COM4_TX_BUF[USART3_MAX_SEND_LEN];
extern unsigned char  COM4_RX_BUF[USART3_MAX_RECV_LEN];
extern unsigned int COM4_RX_CNT;//����
extern unsigned char COM4_RX_STA;//״̬
void COM4_Init(unsigned int bound);
void COM4_Send_Data(unsigned char *buf,unsigned char len);
void COM4_Receive_Data(unsigned char *buf);
void vTask_imu_get(void * pvParameters);
#endif




























