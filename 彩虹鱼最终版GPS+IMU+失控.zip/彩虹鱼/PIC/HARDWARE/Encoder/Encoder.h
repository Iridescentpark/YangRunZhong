//#ifndef __Encoder_H
//#define __Encoder_H

//int Read_Encoder(unsigned char TIMX);


//#endif
