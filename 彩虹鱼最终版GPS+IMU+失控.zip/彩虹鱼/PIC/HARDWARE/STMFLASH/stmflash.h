#ifndef _STMFLASH_H
#define _STMFLASH_H

#include<stm32f10x.h>
#include<delay.h>


#define uchar unsigned char
#define uint unsigned int
	

#define STMFLASH_KEY1               ((uint32_t)0x45670123)
#define STMFLASH_KEY2               ((uint32_t)0xCDEF89AB)

#define stmflash_save_address 0x08019000
extern u8 aw1[8];
extern u8 aw2[8];
extern u8 aw3[8];
extern u8 aw4[8];
extern u8 aw5[8];
extern u8 aw6[8];
extern u8 aw7[8];
extern u8 aw8[8];
extern u8 aw9[8];
extern u8 aw10[8];
extern u8 aw11[8];
extern u8 aw12[8];
extern u8 aw13[8];
extern u8 aw14[8];
extern u8 aw15[8];
extern u8 aw16[8];
extern u8 aw17[8];
extern u8 aw18[8];
extern u8 aw19[8];
extern u8 aw20[8];
extern u8 aw21[8];
extern u8 aw22[8];
extern u8 aw23[8];
extern u8 aw24[8];
extern u8 aw25[8];

extern u8 ar[8];
extern u8 ar1[8];
extern u8 ar2[8];
extern u8 ar3[8];
extern u8 ar4[8];
extern u8 ar5[8];
extern u8 ar6[8];
extern u8 ar7[8];
u8 Erase_Entire_Page(u32 address,u16 num,u8 *p);
void Write_StmFlash_Data(u32 address,u16 num,u8 *p);//д��
void Read_StmFlash_Data(u32 address,u16 num,u8 *p);//��ȡ

void eeprom_get1(void);//����
void eeprom_get2(void);//����
void eeprom_get3(void);//�������
void eeprom_get4(void);//����
void eeprom_get5(void);//�뾶

void eeprom_changepoint(unsigned int e);//д�뺽������
void eeprom_changerad(void);//д��뾶
void eeprom_changepar(void);//�޸Ĳ���
void eeprom_changecount(void);//�������
void eeprom_changeex(void);//�ض�����
void eeprom_get_default(void);
#endif