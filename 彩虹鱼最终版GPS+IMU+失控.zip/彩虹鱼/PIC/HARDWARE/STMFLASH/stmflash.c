#include "stmflash.h"
#include "port.h"
#include "mb.h"
#include "FreeRTOS.h"
#include "task.h"
#include "mavlinkconnect.h"

vu16 buff[1024];
u8 aw1[8];
u8 aw2[8];
u8 aw3[8];
u8 aw4[8];
u8 aw5[8];
u8 aw6[8];
u8 aw7[8];
u8 aw8[8];
u8 aw9[8];
u8 aw10[8];
u8 aw11[8];
u8 aw12[8];
u8 aw13[8];
u8 aw14[8];
u8 aw15[8];
u8 aw16[8];
u8 aw17[8];
u8 aw18[8];
u8 aw19[8];
u8 aw20[8];
u8 aw21[8];
u8 aw22[8];
u8 aw23[8];
u8 aw24[8];
u8 aw25[8];

u8 ar[8];
u8 ar1[8];
u8 ar2[8];
u8 ar3[8];
u8 ar4[8];
u8 ar5[8];
u8 ar6[8];
u8 ar7[8];
extern  u16   MavBuf[];
u8 Erase_Entire_Page(u32 address,u16 num,u8 *p)
{
	vu16 i,j;
	
	for(i=0;i<1024;i++)
	{
		buff[i]=*(vu16*)(stmflash_save_address+i*2);
//	  delay_us(2);
	}	
	if(FLASH->CR&0x80)
	{
		FLASH->KEYR=STMFLASH_KEY1;
		FLASH->KEYR=STMFLASH_KEY2;
	}
	while(FLASH->CR&0x80);
	while(FLASH->SR&0x01);
	FLASH->CR|=0x02;
	FLASH->AR=stmflash_save_address;
	FLASH->CR|=0x40;
  while(FLASH->SR&0x01);
	while(!(FLASH->SR&0x20));
	FLASH->SR|=0x20;
	FLASH->CR&=0xFFFD;
	for(i=0;i<1024;i+=2)
	{
		if(*(vu16*)(stmflash_save_address+i)!=0xffff)
		return 1;//ʧ��
	}
  i=j=address-stmflash_save_address;
  for(;((i-j)/2)<num;i+=2)
  buff[i/2]=p[(i-j)]+(vu16)(p[(i-j)+1]<<8);	
}

void Write_StmFlash_Data(u32 address,u16 num,u8 *p)
{
	
	u16 i;
	vu16 *temp;
	
	address+=stmflash_save_address;
	num/=2;
	temp=(vu16 *)p;
	
	
	for(i=0;i<num;i++)
	{
		if(*(vu16*)(address+i)!=0xFFFF)		
		{
		 Erase_Entire_Page(address,num,p);
	   break;
		}
	}
	if(i<num)
	{
		address=stmflash_save_address;
		num=1024;
		temp=buff;
	}

		
	
	if(FLASH->CR&0x80)
	{
		FLASH->KEYR=STMFLASH_KEY1;
		FLASH->KEYR=STMFLASH_KEY2;
	}
	while(FLASH->CR&0x80);
	while(FLASH->SR&0x01);
	FLASH->CR|=0x01;
	
	for(i=0;i<num;i++)
	{
	*(vu16*)(address+2*i)=temp[i];
		while(FLASH->SR&0x01);
	}
  FLASH->CR&=0xfffe;
}


void Read_StmFlash_Data(u32 address,u16 num,u8 *p)
{
	u16 i;
	
	address+=stmflash_save_address;
	
	for(i=0;i<num;i++)
		*(p+i)=*(vu8*)(address+i);
}

/******************����Ĵ���***************************/
void eeprom_get1()
{
	aw1[0]= MavBuf[0]>>8;
	aw1[1]= MavBuf[0]&0x00FF;
	aw1[2]= MavBuf[1]>>8;
	aw1[3]= MavBuf[1]&0x00FF;//lat
	aw1[4]= MavBuf[2]>>8;
	aw1[5]= MavBuf[2]&0x00FF;
	aw1[6]= MavBuf[3]>>8;
	aw1[7]= MavBuf[3]&0x00FF;//lng
}
///******************paramд��***************************/
void eeprom_get2()
{
	aw2[0]= (u8)(param.dist_p*100);//d_KP(float)
	aw2[1]= (u8)(param.dist_i*100);//d_KI(float)
	aw2[2]= (u8)(param.dist_d*100);//d_KD(float)
	
	aw2[3]= (u8)(param.speed_p*100);//v_KP(float)
	aw2[4]= (u8)(param.speed_i*100);//v_KI(float)
	aw2[5]= (u8)(param.speed_d*100);//v_KD(float)
	
	aw2[6]= (u8)(param.l1_p*100);//l1_KP(float)
	aw2[7]= (u8)(param.l1_i*100);//l1_KI(float)
	aw3[0]= (u8)(param.l1_d*100);//l1_KD(float)

}
void eeprom_get3()
{	
	aw3[1]= (u8)(param.wp_radius*10);	
	aw3[2]= (u8)(param.wp_speed*10);	
	aw3[3]= (u8)(param.wp_min_speed*10);
	aw3[4]= (u8)(param.cruise_speed*10);	
	aw3[5]= (u16)(param.steer_cog)>>8;
	aw3[6]= (u16)(param.steer_cog)&0x00FF;
	aw4[0]= mission.count-1;
}


void eeprom_changepoint(unsigned int e)
{
		eeprom_get1();
		Write_StmFlash_Data(0x00+e,8,aw1);//��ַ������ż��
}
void eeprom_changepar()//�޸Ĳ���
{
		eeprom_get2();
		eeprom_get3();
		Write_StmFlash_Data(0x0190,8,aw2);//��ַ������ż��
		Write_StmFlash_Data(0x0198,8,aw3);//��ַ������ż��
}

void eeprom_changecount()//�������д��
{
		eeprom_get3();
		Write_StmFlash_Data(0x01A0,8,aw4);//��ַ������ż��
	
}