#ifndef __rudder_H
#define __rudder_H

#include "stm32f10x.h"

#define RUDDERRESTART 1
#define RUDDERRESTOP 0

extern float R_Angle;
extern u8 E_f;
void vTaskrudcontrol(void * pvParameters);
void vTaskRuderrorcheeck(void * pvParameters);
void vTaskRuderrorclear(void * pvParameters);
void vTaskRudangleget(void * pvParameters);


#endif




























