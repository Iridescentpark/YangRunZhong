#include "rudder.h"
#include "IO.h"
#include "ModbusMaster.h"
#include "COM2RS4852.h"
#include "delay.h"
#include "port.h"
#include "mb.h"
#include "ADC.h"
#include "COM4RS2322.h"	
#include "COM3RS2321.h"	
#include "FreeRTOS.h"
#include "task.h"
#include "DATA.h"
#include "GPS.h"
#include "mavlinkconnect.h"
#include "stmflash.h"
#include "math.h"
extern u16 MavBuf[];
unsigned char anglebuff[20]; 
int a,c;
u8 RUDANG[14];
unsigned char RUDERO[13];
float R_Angle;
//u8 ruer_send[1][3];
//u8 ruer_Angle[1][3];
unsigned int ANGH,ANGL;
unsigned char START[1][5]={{0x3E,0x88,0x01,0x00,0xC7}};//ʹ��ָ��
unsigned char CLEAR[1][5]={{0x3E,0x9B,0x01,0x00,0xDA}};//���������ָ��
unsigned char CHECK[1][5]={{0x3E,0x9A,0x01,0x00,0xD9}};//��ѯ������ָ��
unsigned char ANGLE[1][5]={{0x3E,0x92,0x01,0x00,0xD1}};//��ѯʵʱ�Ƕ�ָ��

void ANGLE_GET(void)
{
	
	COM4_Send_Data(ANGLE[0],5);
	vTaskDelay(10);
	COM4_Receive_Data(RUDANG);
	R_Angle=(float)((RUDANG[8]>>4)*pow(16,7)+(RUDANG[8]&0x0F)*pow(16,6)+
	(RUDANG[7]>>4)*pow(16,5)+(RUDANG[7]&0x0F)*pow(16,4)+
	(RUDANG[6]>>4)*pow(16,3)+(RUDANG[6]&0x0F)*pow(16,2)+
	(RUDANG[5]>>4)*pow(16,1)+(RUDANG[5]&0x0F)*pow(16,0));
	COM4_RX_CNT=0x0000;
	COM4_RX_STA=0x0000;	
}

void Rudder_compute(u8 rud_head,u8 rud_command,u8 rud_id, u8 lenth)
{
	int angle;
	u32 speed = 60000;
	anglebuff[0]= rud_head;
	anglebuff[1]=rud_command;
	anglebuff[2]=rud_id;
	anglebuff[3]=lenth;
	anglebuff[4]=(u8)(rud_head+rud_command+rud_id+lenth);
	if((control.rudder&0xF000)==0xF000)		
	{
		a= ~(control.rudder-1);
		if((a&0x0000FFFF)>0x00000064){a=0x00000064;}else{;}
		 angle = ~ ( ( a & 0x0000FFFF )  *350 );		
		anglebuff[5] = (angle&0x0000FFFF)&0x00FF;
		anglebuff[6] = (angle&0x0000FFFF)>>8;
		anglebuff[7] = (angle>>16)&0x00FF;
		anglebuff[8] = (angle>>16)>>8;
		anglebuff[9] = 0xFF;
		anglebuff[10] = 0xFF;
		anglebuff[11] = 0xFF;
		anglebuff[12] = 0xFF;
}
	else
	{
		c=control.rudder;
		if(c>100){c=100;}else{;}
		angle = c * 350;
		anglebuff[5] = (angle&0x0000FFFF)&0x00FF;
		anglebuff[6] = (angle&0x0000FFFF)>>8;
		anglebuff[7] = (angle>>16)&0x00FF;
		anglebuff[8] = (angle>>16)>>8;
		anglebuff[9] = 0x00;
		anglebuff[10] = 0x00;
		anglebuff[11] = 0x00;
		anglebuff[12] = 0x00;
	}
		anglebuff[13] = (speed&0x0000FFFF)&0x00FF;
		anglebuff[14] = (speed&0x0000FFFF)>>8;
		anglebuff[15] = (speed>>16)&0x00FF;
		anglebuff[16] = (speed>>16)>>8;
		anglebuff[17]= (anglebuff[5]+anglebuff[6]+anglebuff[7]+anglebuff[8]+anglebuff[9]+anglebuff[10]+anglebuff[11]+
		anglebuff[12]+anglebuff[13]+anglebuff[14]+anglebuff[15]+anglebuff[16])&0x00FF;			
}
u16 flag_Rudder = 0;
void Rudder_control()//�����λ��û�иı������ִ��
{
	u16 num=0;
	num = control.rudder;
	if(num != flag_Rudder)//�����λ��û�иı������ţ���ִ��ָ��
	{
		Rudder_compute(62,164,1,12);
		COM4_Send_Data(anglebuff,18);
	}  
		flag_Rudder = num;  
}

void vTaskrudcontrol(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			Rudder_control();
			vTaskDelayUntil( &xLastWakeTime, ( 200 / portTICK_RATE_MS ) ); 
		}
}


void vTaskRudangleget(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			ANGLE_GET();
			vTaskDelayUntil( &xLastWakeTime, ( 500 / portTICK_RATE_MS ) ); 
		}
}















