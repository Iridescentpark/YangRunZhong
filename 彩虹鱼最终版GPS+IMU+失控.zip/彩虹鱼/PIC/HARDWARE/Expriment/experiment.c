//#include "rudder.h"
#include "IO.h"
#include "ModbusMaster.h"
#include "COM2RS4852.h"
#include "delay.h"
#include "port.h"
#include "mb.h"
#include "ADC.h"
#include "COM4RS2322.h"	
#include "COM3RS2321.h"	
#include "FreeRTOS.h"
#include "task.h"
#include "DATA.h"
#include "GPS.h"
#include "mavlinkconnect.h"
#include "Experiment.h"
#include "math.h"
#include "PID.h"
#include "stmflash.h"
#include "Timer.h"
unsigned char anglebuff_E[20]; 
int Z_YawL,Z_YawR;
int Ration_Yaw1,Ration_Yaw2,Ration_YawL,Ration_YawR;
int Return_Yaw1,Return_Yaw2,Return_YawL,Return_YawR;
int Z_flag ,Z_num,Z_check,Z_RT;
int Ration_flag,Ration_num,Ration_check;
int Return_flag,Return_num,Return_check;
u8 Z_f;
u8 experiment_type;
u32 speed;
unsigned int angle;
unsigned char move[1][8]={{0x01, 0x06 ,0x01 ,0x44 ,0xFA ,0x24 ,0x8A ,0x98}};
unsigned char ANGLE0[1][18]={{0x3E,0xA4,0x01,0x0C,0xEF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xA0,0x86,0x01,0x00,0x27}};
void E_Rudder_compute(u8 rud_head,u8 rud_command,u8 rud_id, u8 lenth,u8 rud_lr)
{
	 
	if(angle >= 35000){angle = 35000;}else{;}
	anglebuff_E[0]= rud_head;
	anglebuff_E[1]=rud_command;
	anglebuff_E[2]=rud_id;
	anglebuff_E[3]=lenth;
	anglebuff_E[4]=(u8)(rud_head+rud_command+rud_id+lenth);
	if(rud_lr == 1)
	{
		anglebuff_E[5] = (angle&0x0000FFFF)&0x00FF;
		anglebuff_E[6] = (angle&0x0000FFFF)>>8;
		anglebuff_E[7] = (angle>>16)&0x00FF;
		anglebuff_E[8] = (angle>>16)>>8;
		anglebuff_E[9] = 0x00;
		anglebuff_E[10] = 0x00;
		anglebuff_E[11] = 0x00;
		anglebuff_E[12] = 0x00;
	}
	else if(rud_lr == 2)
	{
		angle=(-1)*angle;
		anglebuff_E[5] = (angle&0x0000FFFF)&0x00FF;
		anglebuff_E[6] = (angle&0x0000FFFF)>>8;
		anglebuff_E[7] = (angle>>16)&0x00FF;
		anglebuff_E[8] = (angle>>16)>>8;
		anglebuff_E[9] = 0xFF;
		anglebuff_E[10] = 0xFF;
		anglebuff_E[11] = 0xFF;
		anglebuff_E[12] = 0xFF;
	}
	else{;}
		anglebuff_E[13] = (speed&0x0000FFFF)&0x00FF;
		anglebuff_E[14] = (speed&0x0000FFFF)>>8;
		anglebuff_E[15] = (speed>>16)&0x00FF;
		anglebuff_E[16] = (speed>>16)>>8;
		anglebuff_E[17]= (anglebuff_E[5]+anglebuff_E[6]+anglebuff_E[7]+anglebuff_E[8]+anglebuff_E[9]+anglebuff_E[10]+anglebuff_E[11]+anglebuff_E[12]+anglebuff_E[13]+anglebuff_E[14]+anglebuff_E[15]+anglebuff_E[16])&0x00FF;	
}
unsigned int E ;
void E_Experiment()
{
	if((gpsx.yaw/100)>180){Z_RT = (gpsx.yaw/100)-360;}else{Z_RT = gpsx.yaw/100;}
	if(E==0)
	{
		Read_StmFlash_Data(0xA8,8,ar1);//��ȡeeprom��Ĵ洢����
		Read_StmFlash_Data(0xB0,8,ar2);//��ȡeeprom��Ĵ洢����
		Read_StmFlash_Data(0xB8,8,ar3);//��ȡeeprom��Ĵ洢����
		Z_check=Z_RT;
		Ration_check = (gpsx.yaw/100);
		Return_check = (gpsx.yaw/100);
		Z_YawL = Z_check+(-1)*(int)(((u16)ar1[2]<<8)+ar1[3]);
		Z_YawR = Z_check+(int)(((u16)ar1[2]<<8)+ar1[3]);
		if(Z_YawR>180){Z_YawR=Z_YawR-360;}else{;}if(Z_YawL>180){Z_YawL=Z_YawL-360;}else{;}
	//Z�Ͳ���Ŀ��Ƕ�
		Ration_Yaw1 = Ration_check+183;Ration_Yaw2 = Ration_check+177;
		if(Ration_Yaw1>=360){Ration_YawR = Ration_Yaw1-360;}else{Ration_YawR = Ration_Yaw1;}
		if(Ration_Yaw2>=360){Ration_YawL = Ration_Yaw2-360;}else{Ration_YawL = Ration_Yaw2;}
	//��תʵ��Ŀ��Ƕ�
		Return_Yaw1 = Return_check+183;Return_Yaw2 = Return_check+177;
		if(Return_Yaw1>=360){Return_YawR = Return_Yaw1-360;}else{Return_YawR = Return_Yaw1;}
		if(Return_Yaw2>=360){Return_YawL = Return_Yaw2-360;}else{Return_YawL = Return_Yaw2;}
	//�ض�����Ŀ��Ƕ�
	}
	if(sys_type.cus_mode== 8)
	{
		PID_mission();//ѭ��	
	}
	if(mission.mission_type == 0)//Z�Ͳ���
	{		
		if((control.rudder ==0)&&(control.propeller ==0))
		{
			experiment_type = 0;			
			E=1;
			speed = (u32)(ar1[6]);
			angle = (((u16)ar1[0]<<8)+ar1[1])*1000;
			Master_06_Slove(01,324,-1500); 
			COM2_Send_Data(MBMaster_TX_BUFF,8);
			if((datarequst.vole>=(ar1[7]*100-300))&&(datarequst.vole<=(ar1[7]*100+300)))
			{
				sys_type.vole_type=1;
			}
			if(vole_flag == 1)
			{
				E_Rudder_compute(62,164,1,12,1);
				COM4_Send_Data(anglebuff_E,18);		
				Z_num = Z_num+2;
				if((Z_RT<=Z_YawL)&&((Z_num %2) == 0))
				{
					E_Rudder_compute(62,164,1,12,2);
					COM4_Send_Data(anglebuff_E,18);
					Z_num = Z_num+1;
				}
				if((Z_RT>=Z_YawR)&&((Z_num %2) == 1))
				{
					E_Rudder_compute(62,164,1,12,1);
					COM4_Send_Data(anglebuff_E,18);
					Z_num = Z_num+1;
				}
				if(Z_num>(ar1[5]+2))
				{
					Master_06_Slove(01,324,0); 
					COM2_Send_Data(MBMaster_TX_BUFF,8);
					COM4_Send_Data(ANGLE0[0],18);
					E=0;Z_num = 0;mission.mission_type=6;Z_flag =0;vole_flag=0;tick6_time=0;experiment_type = 1;sys_type.vole_type=0;
					
				}
			}		
		}
		else
		{
			experiment_type = 2;
		}
	}		
	if(mission.mission_type == 2)//��תʵ��
	{
		if((control.rudder ==0)&&(control.propeller ==0))
		{
			experiment_type = 0;
			E=1;
			speed = (u32)(ar2[3]);
			angle = (((u16)ar2[0]<<8)+ar2[1])*1000;
			Master_06_Slove(01,324,-1500);
			COM2_Send_Data(MBMaster_TX_BUFF,8);
			if((datarequst.vole>=(ar2[5]*100-300))&&(datarequst.vole<=(ar2[5]*100+300)))
			{
				sys_type.vole_type=1;
			}
			if(vole_flag == 1)
			{
					E_Rudder_compute(62,164,1,12,control.rotation_direction);
					COM4_Send_Data(anglebuff_E,18);	
					if(((gpsx.yaw/100)<=Ration_YawL)&&((gpsx.yaw/100)>=Ration_YawR))
					Ration_num = Ration_num+1;
			}
				if(Ration_num == 3)
				{	
					COM4_Send_Data(ANGLE0[0],18);
					Master_06_Slove(01,324,0); 
					COM2_Send_Data(MBMaster_TX_BUFF,8);
					E=0;Ration_num = 0;mission.mission_type=6;vole_flag=0;
					tick6_time=0;experiment_type = 1;sys_type.vole_type=0;
				}
		}
		else
		{
			experiment_type = 2;
		}
	}
	if( mission.mission_type== 5)//����ͣ������
	{
		Master_06_Slove(01,324,-1500); 
		COM2_Send_Data(MBMaster_TX_BUFF,8);
		if((datarequst.vole>=(ar3[7]*100-300))&&(datarequst.vole<=(ar3[7]*100+300)))
			{
				sys_type.vole_type=1;
			}
		if(vole_flag == 1)
		{
			Master_06_Slove(01,324,0); 
			COM2_Send_Data(MBMaster_TX_BUFF,8);
			vole_flag=0;tick6_time=0;
		}
		if(datarequst.vole<=500)
		{
			experiment_type = 1;mission.mission_type=6;sys_type.vole_type=0;
		}
	}
	if( mission.mission_type== 3)//����ͣ������
	{
		int g_s;
		Master_06_Slove(01,324,-1500); 
		COM2_Send_Data(MBMaster_TX_BUFF,8);
		if((datarequst.vole>=(ar2[7]*100-300))&&(datarequst.vole<=(ar2[7]*100+300)))
			{
				sys_type.vole_type=1;
			}
		if(vole_flag == 1)
		{
			Master_06_Slove(01,324,0); 
			COM2_Send_Data(MBMaster_TX_BUFF,8);
			tick6_time=0;
		}
		if(vole2_flag == 1)
		{
			Master_06_Slove(01,324,1500); 
			COM2_Send_Data(MBMaster_TX_BUFF,8);
			g_s=g_s+1;
			if(g_s==12500)
			{
				Master_06_Slove(01,324,0); 
				COM2_Send_Data(MBMaster_TX_BUFF,8);
				vole_flag=0;vole2_flag = 0;tick5_time=0;g_s = 0;
				mission.mission_type=6;experiment_type = 1;sys_type.vole_type=0;
			}
			
			
		}
	}
	if(mission.mission_type == 4)//�ض�ʵ��
	{
		int rr;
		if((control.rudder ==0)&&(control.propeller ==0))
		{
			experiment_type = 0;
			E=1;
			speed = (u32)(ar3[3]);
			angle = (((u16)ar3[0]<<8)+ar3[1])*1000;
			Master_06_Slove(01,324,-1500);
			COM2_Send_Data(MBMaster_TX_BUFF,8);
			if(vole_flag == 1)
			{
					E_Rudder_compute(62,164,1,12,control.return_rudder_direction);
					COM4_Send_Data(anglebuff_E,18);	
					if(((gpsx.yaw/100)<=Return_YawL)&&((gpsx.yaw/100)>=Return_YawR))
					Return_num = Return_num+1;
			}
				if(Return_num == 3)
				{	
					COM4_Send_Data(ANGLE0[0],18);
					rr=rr+1;
					if(rr==12500)
					{
						Master_06_Slove(01,324,0); 
						COM2_Send_Data(MBMaster_TX_BUFF,8);
						E=0;Ration_num = 0;mission.mission_type=6;rr=0;vole_flag=0;tick6_time=0;experiment_type = 1;
					}
				}
			}
		else
		{
			experiment_type = 2;
		}
	}
	
}

void vTaskrudZ_Test(void * pvParameters)
{
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			E_Experiment();
			vTaskDelayUntil( &xLastWakeTime, ( 200 / portTICK_RATE_MS ) ); 
		}
}