#ifndef __IO_H
#define __IO_H	

#define ON  1
#define OFF 0

#include "sys.h"
void SWD_Init(void);//SWD��д�ڳ�ʼ��

/***************************************************/
//�ⲿ�ߵ͵�ƽ�ź�����ɼ�
//ʹ�÷����� 
//       #define Ifinwater  ID1
//       if(Ifinwater == 1){		}
//
void Input_IO_Init(void);
void Read_Input_IO(void);
#define	ID1		PDin(0)
#define	ID2		PDin(1)
#define	ID3		PGin(10)
#define	ID4		PDin(3)
#define	ID5		PDin(4)
#define	ID6		PDin(5)
#define	ID7		PDin(6)
#define	ID8		PDin(7)
#define	ID9		PDin(8)
#define	ID10	PDin(9)
#define	ID11	PDin(10)
#define	ID12	PDin(11)
#define	ID13	PDin(12)
#define	ID14	PDin(13)
#define	ID15	PDin(14)
#define	ID16	PDin(15)
#define	ID17	PGin(4)
#define	ID18	PGin(5)
#define	ID19	PGin(6)
#define	ID20	PGin(7)
extern unsigned int Input_Data1,Input_Data2;


/***************************************************/
//�̵������ƿ���
//ʹ�÷����� 
//       #define SwitchLED  OD1
//       SwitchLED = 1;  
//
#define	K1	PEout(0)//
#define	K2	PEout(1)//
#define	K3	PEout(2)//
#define	K4	PEout(3)//
#define	K5	PEout(4)//
#define	K6	PEout(5)//
#define	K7	PEout(6)//
#define	K8	PEout(7)//
#define	K9	PEout(8)//
#define	K10	PEout(9)//
#define	K11	PEout(10)//
#define	K12	PEout(11)//
//�����ű����ƶ�Ӧ
#define	OD1	  K1
#define	OD2	  K2
#define	OD3	  K3
#define	OD4	  K4
#define	OD5	  K5
#define	OD6	  K6
#define	OD7	  K7
#define	OD8	  K8
#define	OD9	  K9
#define	OD10 `K10
#define	OD11  K11
#define	OD12  K12

void Output_IO_Init(void);
unsigned char SET_Output_IO(unsigned int Output);//���Ƶ�ƽ��������Ƽ̵������أ�

#endif 






