#include "COM6CAN.h"
#include "radar.h"
#include "COM3RS2321.h"    
#include "COM5RS2323.h"    
#include "string.h"
#include "DAC.h"
#include "stdarg.h"         
#include "stdio.h"            
#include "delay.h"
#include "port.h"
#include "mb.h"
#include "math.h"
#include "Timer.h"
#include "FreeRTOS.h"
#include "task.h"
#include "RapidityControl.h"
#include "mavlinkconnect.h"

ringBuffer_t canrx_buff; // ����һ�����λ������ṹ��

// ��ʼ�����λ�����
void RingBuffer_Init(ringBuffer_t *rb) 
{
    rb->headPosition = 0;
    rb->tailPositon = 0;
    rb->count = 0;
}

// ��黷�λ������Ƿ�����
uint8_t RingBuffer_IsFull(ringBuffer_t *rb) 
{
    return rb->count == BUFFER_SIZE;
}

// ��黷�λ������Ƿ�Ϊ��
uint8_t RingBuffer_IsEmpty(ringBuffer_t *rb) 
{
    return rb->count == 0;
}

// ���λ�����д������
void RingBuffer_Write(ringBuffer_t *rb, char *data) 
{
    if (RingBuffer_IsFull(rb)) 
    {
        // ���������������������ɵ�����
        rb->headPosition = (rb->headPosition + 1) % BUFFER_SIZE;
    } 
    else
    {
        rb->count++;
    }
    strncpy(rb->buffer[rb->tailPositon], data, CODE_SIZE - 1);
    rb->buffer[rb->tailPositon][CODE_SIZE - 1] = '\0'; 
    rb->tailPositon = (rb->tailPositon + 1) % BUFFER_SIZE;
}

// �ӻ��λ�������ȡ����
void RingBuffer_Read(ringBuffer_t *rb, char *data) 
{
    if (RingBuffer_IsEmpty(rb)) 
    {
        // ���������Ϊ�գ����ؿ��ַ���
        data[0] = '\0';
    } 
    else 
    {
        strncpy(data, rb->buffer[rb->headPosition], CODE_SIZE);
        rb->headPosition = (rb->headPosition + 1) % BUFFER_SIZE;
        rb->count--;
    }
}

extern int target_num;
typedef struct {
    int target_id;
    float R;
    float V;
    float angle;
    int rec[1][2]; 
} Millimeter;
Millimeter wave[64];
int p_flag;
double lengthways_distance, crosswise_distance, lengthways_speed, crosswise_speed;
char wavedata[12];
// �����״����ݲ���ӡ����Ŀ�������
void Radar_analyse(void)
{    
    
    for (int z = 0; z < target_num&&!RingBuffer_IsEmpty(&canrx_buff); z++)
    {   
		RingBuffer_Read(&canrx_buff, wavedata);
		
		lengthways_distance = (((canrx_buff.buffer[z][1] & 0x0F) + (canrx_buff.buffer[z][1] >> 4) * 16) * 32 + (((canrx_buff.buffer[z][2] & 0x0F) + (canrx_buff.buffer[z][2] >> 4) * 16) >> 3)) * 0.2 - 500; 
		
		if(lengthways_distance<8)
		{
			crosswise_distance  = ((((canrx_buff.buffer[z][2] & 0x0F) + (canrx_buff.buffer[z][2] >> 4) * 16) & 0x07) * 256 + ((canrx_buff.buffer[z][3] & 0x0F) + (canrx_buff.buffer[0+z][3] >> 4) * 16)) * 0.2 - 204.6;
			if(crosswise_distance<2&&crosswise_distance>-2)
			{
				L_rate=0;
				R_rate=0;
				sys_type.cus_mode = 0;
				break;
			}
			else 
			{	
				L_rate=control.propeller1;
				R_rate=control.propeller2;
			}
			break;
		}			
						
    }
}

void obstacle_avoidance()
{

}
void vTaskRadar(void *pvParameters)
{ 
    portTickType xLastWakeTime; 
    xLastWakeTime = xTaskGetTickCount(); 
    while (1)
    {
        Radar_analyse();
        vTaskDelayUntil(&xLastWakeTime, (50 / portTICK_RATE_MS)); 
    }
}
