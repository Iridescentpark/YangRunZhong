#ifndef TRACE_H_
#define TRACE_H_

#include "sys.h"
#define SPEED_PATH 100

#define LOIT_STATMENT 0
#define PID_STATMENT 0
#define MISSION_PID_STOP 0
#define MISSION_PID_STATMENT 1
#define MISSION_RTL_STATMENT 2
#define MISSION_LOIT_STOP 0
#define TRUE 1
#define FAIL 0
#define EARTH_RADIUS  6378.137
#define PI  3.141592657

extern int L_rate,R_rate;
extern float dRotateAngle1;//目标航向
extern float dRotateAngleH;//HOME点目标航向
extern float dRotateDistance1;//目标点间隔距离
extern float dRotateDistanceH;//HOME点间隔距离
extern float PD_DISTANCE;//偏离航线的距离

extern float Angle_road;//两航点之间路径航向
extern float real_dis;//实际误差距离
extern float Angle_next;//当前坐标到目标点航向

extern unsigned int R;
extern int jug;//判断到点中间变量
typedef struct Trace
{
//*********************************************************定向参数	
 	 float d_Kp;//Kp
 	 float d_Ki;//Ki
 	 float d_Kd;//Kd
	
	 float d_Sv;//计算得出的目标角度（度）	
	 float d_Pv;//实际测量目标角度
 	 float d_ek;//本次偏差	
	 float d_ek1;//上次偏差
	 float d_DelEk;//两次偏差之差
	 float d_sek;//历史偏差之和
	
     int d_Pout;//
	 int d_Iout;//
	 int d_Dout;//
//*********************************************************定速参数	
	 float v_Kp;//Kp
 	 float v_Ki;//Ki
 	 float v_Kd;//Kd
	
	 float v_Sv;//用户设定航速（米/秒）
	 float v_Pv;//实际测量航速
 	 float v_ek;  //本次偏差
	 float v_ek1;//上次偏差
	 float v_DelEk;//两次偏差之差
	 float v_sek; //历史偏差之和
	 
     int v_Iout;//
	 int v_Pout;//
	 int v_Dout;//

	 u8 count;//航点个数
	 u8 rad;//航点半径
	 u8 speedmax;//最高航速
	 
	 u8 steer_cog;
	 u8 steer_speed;
//*********************************************************循迹参数	
	 float s_Kp;//Kp
 	 float s_Ki;//Ki
 	 float s_Kd;//Kd
	 float Side_angle;
	 float s_Sv;//用户设定航线偏距
	 float s_Pv;//实际计算航线偏距
 	 float s_ek;//本次偏差
	 float s_ek1;//上次偏差
	 float s_DelEk;//两次偏差之差
	 float s_sek; //历史偏差之和
	 
	 int s_Iout;//
	 int s_Pout;//
	 int s_Dout;//
	 
}TRACE;
extern TRACE trace;

extern int d_out;
extern int v_out; 
extern int steerd_out;
extern int steerv_out; 
extern int Angle_ek;

void Param_Init(void);
void PID_direction(void);

void Trace_eeprom(unsigned int L);
void Check_eeprom(unsigned int L);

void GetDistanceAP(double lat1, double lng1, double lat2, double lng2);
void GetDistanceAB(double lat1, double lng1, double lat2, double lng2);
void GetDistanceBP(double lat1, double lng1, double lat2, double lng2);
void GetDistancePA(double lat1, double lng1, double lat2, double lng2);

void getAngleAB(double lat1, double lng1, double lat2, double lng2);
void getAnglePA(double lat1, double lng1, double lat2, double lng2);
void getAnglePB(double lat1, double lng1, double lat2, double lng2);

void Trace_math(void);

void GetPoint_compute(void);
void TraceAngle_compute(void);
void Angle_propeller_compute(void);

void speed_compute(void);
void JUDGMENT(void);
void trace_mission(void);
void Steer_mission(void);

//2025.2.18修改
#endif
