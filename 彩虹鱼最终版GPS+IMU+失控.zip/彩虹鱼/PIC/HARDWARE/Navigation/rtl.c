//����ʽPID����ö�ٴ���
//����������ǰ�Ƕȣ��������˫�ƽ�������
//��Ŀ��Ƕ��뵱ǰ�ǶȵĲ���Ϊ���ڻ���
#include "rtl.h"
#include "sys.h"
#include <math.h>
#include <stdio.h>	 
#include <stdarg.h> 
#include <string.h>	
#include "FreeRTOS.h"
#include "task.h"
#include <stdlib.h>
#include "stmflash.h"
#include "GPS.h"
#include "COM4RS2322.h"
#include "mavlinkconnect.h"
#include "trace.h"
//������γ�Ȳ���
double latitudeH1,longitudeH1;//startpoint
double latitudeH2,longitudeH2;//endpoint
double latitudeH3,longitudeH3;//radius check point

float dRotateAngleH1;//flightpath course
float dRotateAngleH2;//startpoint course
float dRotateAngleH3;//endpoint course

float dRotateDistanceH1;//startpoint distance
float dRotateDistanceH2;//endpoint distance
float dRotateDistanceH3;//flightpath distance
float dRotateDistanceH4;//radius check distance

int RTL_DelEk;
u8 arrival;
unsigned int G;//�жϵ����м����
float rtl_deviate;
float rtl_coursenext;

int RTLside_ek;
int rtlcourse_out;

float COSR;
float RTDISTANCE;

RTLmission  rtl;
//TRACE trace;
u8 arH1[8];
u8 arH2[8];
u8 arH3[8];

/***Read the coordinates of the points of the flight path*****/
void RTL_nextpoint(unsigned int L)
{	
	Read_StmFlash_Data((R-8)-(L-8),8,arH2);
	Read_StmFlash_Data((R-8)-L,8,arH3);	
	latitudeH2=(double)((arH2[0]>>4)*pow(16,7)+(arH2[0]&0x0F)*pow(16,6)+(arH2[1]>>4)*pow(16,5)+(arH2[1]&0x0F)*pow(16,4)+(arH2[2]>>4)*pow(16,3)+(arH2[2]&0x0F)*pow(16,2)+(arH2[3]>>4)*pow(16,1)+(arH2[3]&0x0F)*pow(16,0))/10000000;	
	longitudeH2=(double)((arH2[4]>>4)*pow(16,7)+(arH2[4]&0x0F)*pow(16,6)+(arH2[5]>>4)*pow(16,5)+(arH2[5]&0x0F)*pow(16,4)+(arH2[6]>>4)*pow(16,3)+(arH2[6]&0x0F)*pow(16,2)+(arH2[7]>>4)*pow(16,1)+(arH2[7]&0x0F)*pow(16,0))/10000000;	
	latitudeH3=(double)((arH3[0]>>4)*pow(16,7)+(arH3[0]&0x0F)*pow(16,6)+(arH3[1]>>4)*pow(16,5)+(arH3[1]&0x0F)*pow(16,4)+(arH3[2]>>4)*pow(16,3)+(arH3[2]&0x0F)*pow(16,2)+(arH3[3]>>4)*16+(arH3[3]&0x0F))/10000000;	
	longitudeH3=(double)((arH3[4]>>4)*pow(16,7)+(arH3[4]&0x0F)*pow(16,6)+(arH3[5]>>4)*pow(16,5)+(arH3[5]&0x0F)*pow(16,4)+(arH3[6]>>4)*pow(16,3)+(arH3[6]&0x0F)*pow(16,2)+(arH3[7]>>4)*16+(arH3[7]&0x0F))/10000000;		
}
/***Read the coordinates of the first return point*****/
void RTL_firstpoint()
{	
	Read_StmFlash_Data((R-8)-G,8,arH1);	
	latitudeH1 =(double)((arH1[0]>>4)*pow(16,7)+(arH1[0]&0x0F)*pow(16,6)+(arH1[1]>>4)*pow(16,5)+(arH1[1]&0x0F)*pow(16,4)+(arH1[2]>>4)*pow(16,3)+(arH1[2]&0x0F)*pow(16,2)+(arH1[3]>>4)*16+(arH1[3]&0x0F))/10000000;
	longitudeH1 =(double)((arH1[4]>>4)*pow(16,7)+(arH1[4]&0x0F)*pow(16,6)+(arH1[5]>>4)*pow(16,5)+(arH1[5]&0x0F)*pow(16,4)+(arH1[6]>>4)*pow(16,3)+(arH1[6]&0x0F)*pow(16,2)+(arH1[7]>>4)*16+(arH1[7]&0x0F))/10000000;	
} 
/***Calculate the distance from the current point to the first waypoint*****AtoP*/
void RTL_Distance_startpoint(double lat1, double lng1, double lat2, double lng2) 
{	
		double radLat1 = (lat1)* PI / 180.0;	
		double radLat2 = (lat2)* PI / 180.0;	
		double radLng1 =(lng1)* PI / 180.0;	
		double radLng2 =(lng2)* PI / 180.0;	
		double a = radLat1 - radLat2;
		double b = radLng1 - radLng2;	
		dRotateDistanceH1 = 2*asin(sqrt(pow(sin(a/2),2)+cos(radLat1)*cos(radLat2)*pow(sin(b/2),2)));	
		dRotateDistanceH1 = dRotateDistanceH1 * EARTH_RADIUS;	
		dRotateDistanceH1 = dRotateDistanceH1 * 1000;	
}
/***Calculate the distance from the current point to the end waypoint of the flight path*****BtoP*/
void RTL_Distance_endpoint(double lat1, double lng1, double lat2, double lng2)
{	
		double radLat1 = (lat1)* PI / 180.0;	
		double radLat2 = (lat2)* PI / 180.0;	
		double radLng1 =(lng1)* PI / 180.0;	
		double radLng2 =(lng2)* PI / 180.0;	
		double a = radLat1 - radLat2;
		double b = radLng1 - radLng2;	
		dRotateDistanceH2 = 2 * asin(sqrt(pow(sin(a/2),2)+cos(radLat1)*cos(radLat2)*pow(sin(b/2),2)));	
		dRotateDistanceH2 = dRotateDistanceH2 * EARTH_RADIUS;	
		dRotateDistanceH2 = dRotateDistanceH2 * 1000;	
}

/***Calculate the distance of the flight path*****BtoA*/
void RTL_Distance_flightpath(double lat1, double lng1, double lat2, double lng2)
{	
		double radLat1 = (lat1)* PI / 180.0;	
		double radLat2 = (lat2)* PI / 180.0;	
		double radLng1 =(lng1)* PI / 180.0;	
		double radLng2 =(lng2)* PI / 180.0;	
		double a = radLat1 - radLat2;
		double b = radLng1 - radLng2;	
		dRotateDistanceH3 = 2 * asin(sqrt(pow(sin(a/2),2)+cos(radLat1)*cos(radLat2)*pow(sin(b/2),2)));	
		dRotateDistanceH3 = dRotateDistanceH3 * EARTH_RADIUS;	
		dRotateDistanceH3 = dRotateDistanceH3 * 1000;	
}
/***Calculate the distance of the mission check*****AtoP*/
void RTL_Distance_radius(double lat1, double lng1, double lat2, double lng2)
{	
		double radLat1 = (lat1)* PI / 180.0;	
		double radLat2 = (lat2)* PI / 180.0;	
		double radLng1 =(lng1)* PI / 180.0;	
		double radLng2 =(lng2)* PI / 180.0;	
		double a = radLat1 - radLat2;
		double b = radLng1 - radLng2;	
		dRotateDistanceH4 = 2 * asin(sqrt(pow(sin(a/2),2)+cos(radLat1)*cos(radLat2)*pow(sin(b/2),2)));	
		dRotateDistanceH4 = dRotateDistanceH4 * EARTH_RADIUS;	
		dRotateDistanceH4 = dRotateDistanceH4 * 1000;	
}
/***Calculate the course of the flight path*****BtoA*/
void RTL_Angle_flightpath(double lat1, double lng1, double lat2, double lng2)
{	
		dRotateAngleH1 = atan2(fabs(lng1 - lng2),fabs(lat1 - lat2));	
		if (lng2 >= lng1) 			
		{if (lat2 >= lat1) {;} else {dRotateAngleH1 = PI - dRotateAngleH1;}} 	
		else {if (lat2 >= lat1) {dRotateAngleH1 = 2 * PI - dRotateAngleH1;} else {dRotateAngleH1 = PI + dRotateAngleH1;}}	
		dRotateAngleH1 = dRotateAngleH1 * 180 / PI;		
}
/***Calculate the course of the first point*****AtoP*/
void RTL_Angle_startpoint(double lat1, double lng1, double lat2, double lng2)
{	
		dRotateAngleH2 = atan2(fabs(lng1 - lng2),fabs(lat1 - lat2));	
		if (lng2 >= lng1) 			
		{if (lat2 >= lat1) {;} else {dRotateAngleH2 = PI - dRotateAngleH2;}} 	
		else {if (lat2 >= lat1) {dRotateAngleH2 = 2 * PI - dRotateAngleH2;} else {dRotateAngleH2 = PI + dRotateAngleH2;}}	
		dRotateAngleH2 = dRotateAngleH2 * 180 / PI;		
}
/***Calculate the course of the second point*****AtoP*/
void RTL_Angle_endpoint(double lat1, double lng1, double lat2, double lng2)
{	
		dRotateAngleH3 = atan2(fabs(lng1 - lng2),fabs(lat1 - lat2));	
		if (lng2 >= lng1) 			
		{if (lat2 >= lat1) {;} else {dRotateAngleH3 = PI - dRotateAngleH3;}} 	
		else {if (lat2 >= lat1) {dRotateAngleH3 = 2 * PI - dRotateAngleH3;} else {dRotateAngleH3 = PI + dRotateAngleH3;}}	
		dRotateAngleH3 = dRotateAngleH3 * 180 / PI;		
}
void RTL_trace_compute()//Ŀ��Ƕȼ���
{ 
//�����صĲ�����AP,AB,PB����
	RTL_nextpoint(G);
	RTL_Angle_flightpath(latitudeH2,longitudeH2,latitudeH3,longitudeH3); //�Ƕ��㷨 �����Ƕ�	
	RTL_Distance_startpoint(latitudeH2,longitudeH2,(double)(gpsx.latitude)/10000000,(double)(gpsx.longitude)/10000000);//��1�����	
	RTL_Distance_flightpath(latitudeH2,longitudeH2,latitudeH3,longitudeH3);//������֮��·������	
	RTL_Distance_endpoint(latitudeH3,longitudeH3,(double)(gpsx.latitude)/10000000,(double)(gpsx.longitude)/10000000);//·������	
	COSR = (pow(dRotateDistanceH1,2)+pow(dRotateDistanceH3,2)-pow(dRotateDistanceH2,2))/(2*dRotateDistanceH1*dRotateDistanceH3);		
	RTDISTANCE = dRotateDistanceH1*sin(acos(COSR));//�����ƫ������	
}

void checkradius_compute()
{
	RTL_firstpoint();	
	RTL_Distance_radius(latitudeH1,longitudeH1,(double)(gpsx.latitude)/10000000,(double)(gpsx.longitude)/10000000);
	RTL_Angle_startpoint((double)(gpsx.latitude)/10000000,(double)(gpsx.longitude)/10000000,latitudeH1,longitudeH1);
}

//****************ѭ��Ŀ��Ƕ�����������*****************************
void rtlcourse_compute(void)
{
		RTL_trace_compute();	
//�жϺ����ڵ�ǰ�������໹���Ҳ�
		rtl.Side_angle = dRotateAngleH1-dRotateAngleH3;		
		if(rtl.Side_angle<= -180.0){rtl.Side_angle = 360.0+rtl.Side_angle;}//ö��		
		if(rtl.Side_angle> 180.0){rtl.Side_angle = (-1)*(360.0-rtl.Side_angle);}//ö��		
//�趨Ŀ�꣬ƫ�뺽����Ԥ��ֵ����Ϊ����Ѳ��			
		rtl.s_Sv=0.1;		
		rtl.s_Pv = RTDISTANCE;		
        rtl.s_ek=(rtl.s_Pv-rtl.s_Sv)*10;     //Ŀ��ֵ��ȥʵ��ֵ�õ���ǰ��ƫ��ֵ			
        rtl.s_Pout=trace.s_Kp*rtl.s_ek;      //�������		
        rtl.s_sek+=rtl.s_ek;        //��ʷƫ���ܺ�		
        rtl.s_DelEk=rtl.s_ek-rtl.s_ek1;  //�������ƫ��֮��		
        rtl.s_Iout=trace.s_Ki*rtl.s_sek;  //������� 		
        rtl.s_Dout=trace.s_Kd*rtl.s_DelEk;    //΢�����		
        RTLside_ek= rtl.s_Pout+ rtl.s_Iout+ rtl.s_Dout;//PID�������		
		if(RTLside_ek>50){RTLside_ek = 50 ;}else if(RTLside_ek<0){RTLside_ek = 0 ;}else{;}//������ֵ50��30			
//����ʵ��Ŀ��Ƕȣ����ݺ����ж�����ջ����ҹ�		
		if(rtl.Side_angle>-180.0&&rtl.Side_angle<=0.0)		
		{			
			rtl_coursenext = dRotateAngleH1+RTLside_ek;
			rtl_deviate = RTDISTANCE;			
		}		
		if(rtl.Side_angle< 180.0&&rtl.Side_angle>0.0)		
		{			
			rtl_coursenext = dRotateAngleH1-RTLside_ek;
			rtl_deviate = (-1)*RTDISTANCE;			
		}			
		if(rtl_coursenext<= 0){rtl_coursenext = 360.0+rtl_coursenext;}//���ƽǶȷ�Χ		
		if(rtl_coursenext> 360){rtl_coursenext = rtl_coursenext-360;}//			
}	

//****************����������*****************************************
void RTL_propeller_compute()
{				
		if(G == 0){checkradius_compute();rtl.d_Sv=dRotateAngleH2;}else{rtlcourse_compute();rtl.d_Sv=rtl_coursenext;}
		rtl.d_Pv = gpsx.yaw_2400;	
        rtl.d_ek=(rtl.d_Sv-rtl.d_Pv)*2;     //Ŀ��ֵ��ȥʵ��ֵ�õ���ǰ��ƫ��ֵ	
        if((rtl.d_Sv-rtl.d_Pv)<= -180.0){rtl.d_ek = 360.0+(rtl.d_Sv-rtl.d_Pv);}//�ڳ�ʼ����������ǰö��	
        if((rtl.d_Sv-rtl.d_Pv)> 180.0){rtl.d_ek = (-1)*(360.0-(rtl.d_Sv-rtl.d_Pv));}//�ڳ�ʼ����������ǰö��	
        rtl.d_Pout=trace.d_Kp*rtl.d_ek;      //�������	
        rtl.d_sek+=rtl.d_ek;        //��ʷƫ���ܺ�		
        rtl.d_DelEk=rtl.d_ek-rtl.d_ek1;  //�������ƫ��֮��	
        rtl.d_Iout=trace.d_Ki*rtl.d_sek;  //������� 		
        rtl.d_Dout=trace.d_Kd*rtl.d_DelEk;    //΢�����		
        rtlcourse_out= rtl.d_Pout+ rtl.d_Iout+ rtl.d_Dout;//rtl�������			
		if(rtlcourse_out>500){rtlcourse_out = 500 ;}else if(rtlcourse_out<-500){rtlcourse_out = -500 ;}else{;}//������ֵ500��300			
}

void  rtl_control()//2025.2.17�޸�
{	
	RTL_propeller_compute();
	while(fabs(rtl.d_ek)>30.0)//���÷�Χ�����Ƕ����С��15��ʱ ��ʼǰ��		
	{		
		if(rtl.d_ek>-180.0&&rtl.d_ek<0.0)			
		{		
			RTL_propeller_compute();
			L_rate=rtlcourse_out;
			R_rate=rtlcourse_out*(-1);	
		}
		if(rtl.d_ek< 180.0&&rtl.d_ek>0.0)
		{
			RTL_propeller_compute();
			L_rate=rtlcourse_out;
			R_rate=(-1)*rtlcourse_out;
		} 
		return;
	}
	while(fabs(rtl.d_ek)<=30.0)//�����С��15ʱ����ʼǰ��	
	{		
		if(rtl.d_ek>-180.0&&rtl.d_ek<0.0)		
		{	
			rtlcourse_compute();//PID����
            speed_compute();
			L_rate=10*rtlcourse_out+v_out;
			R_rate=v_out;		
		}
		if(rtl.d_ek< 180.0&&rtl.d_ek>0.0)
		{			
			rtlcourse_compute();//PID����          
            speed_compute();			
			L_rate=v_out;
			R_rate=10*rtlcourse_out+v_out;			
		} 	
    return;
	}	
	trace.v_ek1=trace.v_ek;
	rtl.d_ek1=rtl.d_ek;
}
void rtl_radiuscheck(void)
{
	checkradius_compute();
	if(dRotateDistanceH4<=trace.rad){arrival = TRUE; }else{arrival = FAIL;}	
}

void RTL_mission(void)
{
if(R !=0)
{		
	if(G == 0)	
	{	
		rtl_radiuscheck();	
		rtl_control();//ǰ���㷨	
		while(arrival == TRUE)		
		{		
			G=G+8; 	
			arrival = FAIL;				
			trace.v_sek = 0;			
		}		
	}	
	if((G > 0)&&(G<R))		
	{
		rtl_radiuscheck();						
		rtl_control();//ǰ���㷨		
		while(arrival == TRUE)		
		{			
			G=G+8; 				
			arrival = FAIL;
			trace.v_sek = 0;						
		}		
	}		
	if(G==R)		
	{			
			arrival = FAIL; 
			sys_type.cus_mode = 0;
			G = 0;
			R = 0;
			L_rate=0;
			R_rate=0;		
	}  
}
else
{
	sys_type.cus_mode = 0;
}
	
}