#ifndef __BPK_RTC_H
#define __BPK_RTC_H	
#include "sys.h"

#define BKP_DATA1 BKP_ReadBackupRegister(BKP_DR1)
#define BKP_DATA2 BKP_ReadBackupRegister(BKP_DR2)
#define BKP_DATA3 BKP_ReadBackupRegister(BKP_DR3)
#define BKP_DATA4 BKP_ReadBackupRegister(BKP_DR4)

//ʱ��ṹ��
typedef struct 
{
	unsigned short work_day;
	unsigned char work_hour;
	unsigned char work_min;
	unsigned char work_sec;				 
} Work_time;					 

extern Work_time Time_ALL;

unsigned char RTC_Init(void);	//��ʼ��RTC,����0,ʧ��;1,�ɹ�;
void RTC_Get(void);				//����ʱ�� 
void RTC_Set(unsigned char i);	//���ؼ�ʱ

#endif 













