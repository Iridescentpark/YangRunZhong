#ifndef __PWM_H
#define __PWM_H
#include "sys.h"

void PWM_TIM2_Init(unsigned int arr,unsigned int Frequency);
void PWM_TIM3_Init(unsigned int arr,unsigned int Frequency);
void PWM_TIM8_Init(unsigned int arr, unsigned int Frequency);
void PWM_TIM4_Init(unsigned short arr, unsigned int Frequency);
void Set_PWM_ALL(unsigned char CH, unsigned int num);


#endif















