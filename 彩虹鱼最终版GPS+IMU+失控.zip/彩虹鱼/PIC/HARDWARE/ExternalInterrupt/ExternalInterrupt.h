#ifndef __ExternalInterrupt_H
#define __ExternalInterrupt_H	 
#include "sys.h"
 	 
void External_Interrupt_Init(void);//�ⲿ�жϳ�ʼ��	

#endif
