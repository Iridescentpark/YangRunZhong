/*-------------------------------------------------------------*/
//���ƽ����������
/*-------------------------------------------------------------*/
#include "propeller.h"
#include "ModbusMaster.h"
#include "COM2RS4852.h"
#include "COM3RS2321.h"
#include "mbcrc.h"
#include "delay.h"
#include "port.h"
#include "mb.h"
#include "FreeRTOS.h"
#include "task.h"
#include "IO.h"
#include "stmflash.h"
#include "mavlinkconnect.h"
extern u16 MavBuf[];
__packed typedef struct  
{										    
	int wrong;	//�������
}ERROR_DATA;
ERROR_DATA ERO_DATA;
//���ʹ�ܳ�ʼ��ָ��
void Propeller_Init(void)
{

	Master_06_Slove(01,282,1);//ʹ�ܳ�ʼ��
	COM2_Send_Data(MBMaster_TX_BUFF,8);
	delay_ms(300);
	Master_06_Slove(01,113,1000);//���ٳ�ʼ��
	COM2_Send_Data(MBMaster_TX_BUFF,8);
	delay_ms(300);
	Master_06_Slove(01,114,1000);//���ٳ�ʼ��
    COM2_Send_Data(MBMaster_TX_BUFF,8);
}

//������ƴ���
void propeller(void)
{	
		Master_16_Slove(01,324,1); 
		COM2_Send_Data(MBMaster_TX_BUFF,11);
		COM2_RX_CNT=0;
		COM2_RX_STA=0;
}

void vTaskprocontrol(void * pvParameters)
	{
		portTickType xLastWakeTime; 
		xLastWakeTime = xTaskGetTickCount(); 
		while(1)
		{
			propeller();
			vTaskDelayUntil( &xLastWakeTime, ( 200 / portTICK_RATE_MS ) ); 
		}
	}
