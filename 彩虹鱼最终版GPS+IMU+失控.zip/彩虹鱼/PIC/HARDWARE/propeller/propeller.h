#ifndef __propeller_H
#define __propeller_H	


#define EROCHECK 1
#define EROSTOP 0


#define RESCHECK 1
#define RESSTOP 0


#define CONSTART 1
#define CONSTOP 0


void Propeller_Init(void);
void propeller(void);
void propeller_restart(void);
void propeller_errorget(void);
void propeller_errorcheck(void);
void vTaskprocontrol(void * pvParameters);
void vTaskerrorcheeck(void * pvParameters);
#endif








