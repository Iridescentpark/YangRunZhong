#ifndef __LED_H
#define __LED_H

#define LED PAout(8)

void LED_Init(void);
void vTaskLED(void * pvParameters);	 				    
#endif
