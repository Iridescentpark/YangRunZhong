#ifndef __COM5RS2323_H
#define __COM5RS2323_H			

#include "stm32f10x.h"

void COM5_Init(unsigned int bound);
void COM5_Send_Data(unsigned char *buf);
void COM5_Receive_Data(void);
void COM5_printf(char const* fmt,...);
void vTaskDATA_SEND(void * pvParameters);
#endif
































