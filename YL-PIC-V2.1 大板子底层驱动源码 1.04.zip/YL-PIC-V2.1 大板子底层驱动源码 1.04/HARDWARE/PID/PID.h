#ifndef PID_H_
#define PID_H_

typedef struct Pid
{
 	unsigned int Sv;//用户设定值
 	unsigned int Pv;//实际测量值
 
 	unsigned int Kp;//比例系数
 	unsigned int T;  //PID计算周期--采样周期
 	unsigned int Ti;
 	unsigned int Td; 
	
 	 int Ek;  //本次偏差
	 int Ek_1;//上次偏差
	 int SEk; //历史偏差之和
	
	 int Iout;
	 int Pout;
	 int Dout;
	
 	unsigned int OUT0;

 	unsigned int  OUT;

 	int C1ms;
	
 	int pwmcycle;//pwm周期
 
 	int times;
}PID;

extern PID pid;

void PID_Init(void);
void PID_Calc(void);

#endif

