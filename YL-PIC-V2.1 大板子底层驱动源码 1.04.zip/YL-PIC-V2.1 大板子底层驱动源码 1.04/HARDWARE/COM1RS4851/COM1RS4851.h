#ifndef __COM1RS4851_H
#define __COM1RS4851_H			 

#define RS485_TX_EN		PGout(9)

#include "mb.h"
#include "mbconfig.h"
#include "mbproto.h"
#include "mbfunc.h"

extern u16 UART5_RX_STA;
extern unsigned char UART5_RX_BUF[];//���ý����ֽ���  255����
extern unsigned int  UART5_RX_CNT;//����

void COM1_Init( ULONG ulBaudRate, UCHAR ucDataBits, eMBParity eParity);
void COM1_Send_Data(unsigned char *buf,unsigned char len);
void COM1_Receive_Data(unsigned char *buf);//,unsigned char *len);

#endif

