#ifndef __Timer_H
#define __Timer_H
#include "stm32f10x.h"
#include "sys.h"

extern unsigned char Time1Count;    //Tim1����������־λ
extern unsigned char Time1Flag;      //��ֹ��ѭ�����ִ�еı�־λ

void TIM1_Init(u16 arr,u16 psc);

void TIM5_Init(u16 arr,u16 psc);
void TIM5_Set(u8 sta);

void TIM6_Init(u16 arr,u16 psc);
void TIM6_Set(u8 sta);

void TIM7_Init(u16 arr,u16 psc);
void TIM7_Set(unsigned char sta);

#endif

