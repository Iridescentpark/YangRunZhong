#include "MixConRelay.h"
#include "sys.h"
#include "IO.h"
#include "port.h"
#include "mb.h"
#include "delay.h"
#include "ADC.h"
#include "FreeRTOS.h"
#include "task.h"
extern  USHORT   usRegHoldingBuf[];
void MixControl()   
{
	switch (usRegHoldingBuf[5]&0xF000)
	{
		case 1: K1 = 0;break;
		case 2: K2 = 0;break;
		case 3: K3 = 0;break;
		case 4: K4 = 0;break;
		case 5: K5 = 0;break;
		case 6: K6 = 0;break;
		case 7: K7 = 0;break;
		case 8: K8 = 0;break;
		case 9: K9 = 0;break;
		case 10: K10 = 0;break;
		case 11: K11 = 0;break;
		case 12: K12 = 0;break;	
	}
}

void vTaskMix(void * pvParameters)
{ 
	portTickType xLastWakeTime; 
	xLastWakeTime = xTaskGetTickCount(); 
	while(1)
	{
		MixControl();
		vTaskDelayUntil( &xLastWakeTime, ( 100 / portTICK_RATE_MS ) ); 
	}
} 
