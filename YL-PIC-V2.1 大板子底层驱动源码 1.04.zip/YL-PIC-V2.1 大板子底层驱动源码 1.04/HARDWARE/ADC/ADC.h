#ifndef __ADC_H
#define __ADC_H	
#include "sys.h" 

extern float ADC_Val[21];

#define A1 PFout(0)
#define B1 PFout(1)
#define C1 PFout(2)
#define A2 PFout(3)
#define B2 PFout(4)
#define C2 PFout(5)

void ADC1_Init(void);
void Get_ADC_Val(void);

#endif 
