#ifndef __COM2RS4852_H
#define __COM2RS4852_H			 

#define RS4852_TX_EN	PGout(14)

extern unsigned char  COM2_RX_BUF[];
extern unsigned short COM2_RX_STA;

void COM2_Init(unsigned int ulBaudRate);
void COM2_Send_Data(unsigned char buf[]);
void COM2_Receive_Data(void);
void COM2_printf(char* fmt,...);
#endif

