#ifndef _MB_RTU_H
#define _MB_RTU_H

//#ifdef __cplusplus
//PR_BEGIN_EXTERN_C
//#endif

#if MB_RTU_ENABLED > 0
eMBErrorCode    eMBRTUInit( UCHAR slaveAddress, UCHAR ucPort, ULONG ulBaudRate, eMBParity eParity );
void            eMBRTUStart( void );
void            eMBRTUStop( void );
eMBErrorCode    eMBRTUReceive( UCHAR * pucRcvAddress, UCHAR ** pucFrame, USHORT * pusLength );
eMBErrorCode    eMBRTUSend( UCHAR slaveAddress, const UCHAR * pucFrame, USHORT usLength );
BOOL            xMBRTUReceiveFSM( void );
BOOL            xMBRTUTransmitFSM( void );
BOOL            xMBRTUTimerT35Expired( void );
#endif

//#ifdef __cplusplus
//PR_END_EXTERN_C
//#endif

#endif
