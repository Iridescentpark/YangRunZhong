/* --------------------------------------------------------------------------*/
//�����ˣ��¼�ö�ٱ�����У��ö�ٱ�����
//        �¼������������ƣ�
//        ���ڡ���ʱ�����ص�������ͷ�ļ�
/* --------------------------------------------------------------------------*/
#ifndef _MB_PORT_H
#define _MB_PORT_H

typedef enum
{
    EV_READY,                   /*!< Startup finished. */
    EV_FRAME_RECEIVED,          /*!< Frame received. */
    EV_EXECUTE,                 /*!< Execute function. */
    EV_FRAME_SENT               /*!< Frame sent. */
} eMBEventType;

typedef enum
{
    MB_PAR_NONE,                /*!< No parity. */
    MB_PAR_ODD,                 /*!< Odd parity. */
    MB_PAR_EVEN                 /*!< Even parity. */
} eMBParity;

BOOL            xMBPortEventInit( void );
BOOL            xMBPortEventPost( eMBEventType eEvent );
BOOL            xMBPortEventGet(  /*@out@ */ eMBEventType * eEvent );

/* ----------------------- ���ں��� ----------------------------*/
BOOL            xMBPortSerialInit( UCHAR ucPort, ULONG ulBaudRate, UCHAR ucDataBits, eMBParity eParity );
void            vMBPortClose( void );
void            xMBPortSerialClose( void );
void            vMBPortSerialEnable( BOOL xRxEnable, BOOL xTxEnable );
INLINE BOOL     xMBPortSerialGetByte( CHAR * pucByte );
INLINE BOOL     xMBPortSerialPutByte( CHAR ucByte );

/* ----------------------- ��ʱ������ ---------------------------------*/
BOOL            xMBPortTimersInit( USHORT usTimeOut50us );
void            xMBPortTimersClose( void );
INLINE void     vMBPortTimersEnable( void );
INLINE void     vMBPortTimersDisable( void );

/* ----------------------- Э��ջ�Ļص����� ------------------*/
extern          BOOL( *pxMBFrameCBByteReceived ) ( void );      //����״̬��
extern          BOOL( *pxMBFrameCBTransmitterEmpty ) ( void );  //����״̬��
extern          BOOL( *pxMBPortCBTimerExpired ) ( void );       //��ʱ��״̬��

/* ----------------------- TCP���ں��� -------------------------------*/
BOOL            xMBTCPPortInit( USHORT usTCPPort );
void            vMBTCPPortClose( void );
void            vMBTCPPortDisable( void );
BOOL            xMBTCPPortGetRequest( UCHAR **ppucMBTCPFrame, USHORT * usTCPLength );
BOOL            xMBTCPPortSendResponse( const UCHAR *pucMBTCPFrame, USHORT usTCPLength );

#endif






