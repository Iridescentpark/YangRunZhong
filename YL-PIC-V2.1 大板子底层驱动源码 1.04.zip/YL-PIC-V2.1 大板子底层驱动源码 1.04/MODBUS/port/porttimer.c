/* --------------------------------------------------------------------------*/
//ʹ�ö�ʱ��2����RTU֮֡���ʱ;         RTUģʽ�ر���
//
/* --------------------------------------------------------------------------*/
#include "port.h"
#include "mb.h"
#include "mbport.h"

BOOL xMBPortTimersInit( USHORT usTim1Timerout50us ) //��ʱ��2��ʼ��
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef        NVIC_InitStructure;
    
    uint16_t PrescalerValue = 0;
    
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  
     TIM_DeInit(TIM2);//����TIM2
    
    //HCLKΪ72MHz
	//ʱ��Ƶ��72 / ��1 + Prescaler) = 20KHz
	PrescalerValue = (uint16_t)((SystemCoreClock / 20000) - 1);
    
    //��ʼ����ʱ������
	TIM_TimeBaseStructure.TIM_Period = (uint16_t)usTim1Timerout50us;
	TIM_TimeBaseStructure.TIM_Prescaler = PrescalerValue;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

	TIM_ARRPreloadConfig(TIM2, ENABLE);
	
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 2;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	TIM_ITConfig(TIM2, TIM_IT_Update, DISABLE);
	TIM_Cmd(TIM2, DISABLE);

	return TRUE;
}

void vMBPortTimersEnable( )  //ʹ�ܶ�ʱ��
{	
	TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	TIM_SetCounter(TIM2, 0x00000000);
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
    TIM_Cmd(TIM2, ENABLE);
}

void vMBPortTimersDisable( ) //ʧ�ܶ�ʱ��
{
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	TIM_ITConfig(TIM2, TIM_IT_Update, DISABLE);
	TIM_SetCounter(TIM2, 0x00000000);
	TIM_Cmd(TIM2, DISABLE);
}

void prvvTIMERExpiredISR( void )    //��ʱ��2�жϴ���
{
    ( void )pxMBPortCBTimerExpired( );  //�ص���ʱ���ж�ִ�к���
}

void TIM2_IRQHandler(void)
{
        if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
        {
                TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
                prvvTIMERExpiredISR();
        }
}

