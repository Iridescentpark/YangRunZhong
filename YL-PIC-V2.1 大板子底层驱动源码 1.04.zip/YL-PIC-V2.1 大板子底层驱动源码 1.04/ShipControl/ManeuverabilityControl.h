#ifndef __ManeuverabilityControl_H
#define __ManeuverabilityControl_H

#include "port.h"
#include "mb.h"
extern  USHORT   usRegHoldingBuf[];


	 				    
#endif


















