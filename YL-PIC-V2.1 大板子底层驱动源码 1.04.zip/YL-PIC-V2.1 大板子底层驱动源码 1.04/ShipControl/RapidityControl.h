#ifndef __RapidityControl_H
#define __RapidityControl_H

#include "port.h"
#include "mb.h"
extern  USHORT   usRegHoldingBuf[];

void Propeller_Stop(void);
void Propeller_Con56(int L_rate, int R_rate);
void Propeller_Con78(int L_rate, int R_rate);
	 				    
#endif












