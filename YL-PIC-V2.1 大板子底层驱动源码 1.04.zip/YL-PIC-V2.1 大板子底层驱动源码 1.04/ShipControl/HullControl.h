#ifndef __HullControl_H
#define __HullControl_H	 

#include "port.h"
#include "mb.h"
extern  USHORT   usRegHoldingBuf[];


void ShipControl(unsigned char i);
unsigned char HullPowerCon(unsigned char i);
unsigned char ControlledPower(unsigned char i);	    
unsigned char WorkLED(unsigned char Yellow, unsigned char White);
unsigned char LightingGroup(void);

#endif

























