#ifndef __RemoteControl_H
#define __RemoteControl_H	 

#include "port.h"
#include "mb.h"
extern  USHORT   usRegHoldingBuf[];

void MixControl(void);



#endif

























