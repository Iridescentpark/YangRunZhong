/* --------------------------------------------------------------------------*/
//
//
/* --------------------------------------------------------------------------*/
#ifndef _ModbusMaster_H
#define _ModbusMaster_H

#include "mb.h"
#include "sys.h"

extern u16  Master_ReadReg[];
extern unsigned char MBMaster_RX_BUFF[];//���ջ�����

#define READ_COIL     01
#define READ_DI       02
#define READ_HLD_REG  03
#define READ_AI       04
#define SET_COIL      05
#define SET_HLD_REG   06
#define WRITE_COIL    15
#define WRITE_HLD_REG 16

#define HI(n) ((n)>>8)
#define LOW(n) ((n)&0xff)

void Modbus_RegMap(void);
void ModbusMaster_Init(unsigned long ulBaudRate, unsigned char ucDataBits, eMBParity eParity);

void Modbus_01_Solve(void);
void Modbus_02_Solve(void);
void Modbus_03_Solve(void);
void Modbus_05_Solve(void);
void Modbus_06_Solve(void);
void Modbus_15_Solve(void);
void Modbus_16_Solve(void);

void ModBus_Master_TX(u8 SlaverAddr,u8 Fuction,u16 StartAddr,u16 ValueOrLenth);
void ModBus_Master_RX(u8 SlaverAddr);
//void modbus_rtu(u8 SlaverAddr,u8 Fuction,u16 StartAddr,u16 ValueOrLenth);


#endif
